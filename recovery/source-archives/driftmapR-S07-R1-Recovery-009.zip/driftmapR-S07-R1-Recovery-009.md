# driftmapR S07-R1 Recovery009

The 361-panel recovery chain is verified and ready for owned launch finalization.

| Dependencies restored in Recovery009 | Archives | Status |
|---|---:|---|
| Original checkpoints | 25 | Verified |
| Recovered R1 checkpoints | 22 | Verified |
| Missing raw-prefix dependencies | 81 | Verified |

All **128 dependency archives required for this recovery** passed identity, member-coverage and completed catalog/prefix checks: 25 original checkpoint archives, 22 R1 checkpoint archives and 81 missing raw-prefix dependency archives. This count does not describe the entire historical published raw chain. Before the missing raw dependencies were restored, 9,598 prefix files were already available; the 81 archives covered the remaining 153,494 missing logical files. All **163,092 prefix files** passed MD5, size and exact-grid verification, and all **111 historical publication catalogs** passed their bindings.

The saved collection boundary is **361 / 6,480 panels (5.6%)**, through chunk **198537**. Journaled chunk **198538**, the first draw export for panel 362, is retained for verified reuse. The checkpoint contains 362 compact caches and 6,480 saved input-verification receipts.

Independent current-state verification checked 35,446 incremental raw files (1,947,238,905 bytes), all 368 journaled JSON files, caches, receipts, provenance and bindings. The older prefix contains 163,092 raw files (12,848,037,331 bytes).

The checkpoint source archive is `driftmapR-S07-R1-progress-20260922-007a.zip`: 569,351,915 bytes; SHA256 `6a77c721e26ccf794169f19e0db0fa0da8ba0b33f1710284bedbb4e37987024d`. Its saved multipart transport requires **part002 version 1**; version 0 was truncated. Fresh downloads of all three saved parts passed individual hashes and reconstructed the exact source archive; part002 version 1 was verified.

Recovery preserves frozen methods, checkpoints, seeds, runtime and exact draw vectors. This continuation generated **zero new measurement panels, fits or draw vectors**. Collection, frozen analysis, final audits and final preservation coverage remain unfinished. Scientific completion is not claimed.

Launch009 uses byte-identical launch007 controls and unchanged driver006. The driver retains its **launch006 review gate**, which is part of its persisted binding. Root must review and retain stale process metadata before launch, start through the owned wrapper, and confirm the new child. Saved PIDs must never be signaled. This consolidation script does not launch anything.

The 119 remaining full panels have an empirical workspace-growth allowance of 1.863 GB excluding registration, or 4.010 GB including the retained disk floor. This uses observed component maxima and a larger-m proxy for unobserved sparse panels; it is not a guaranteed bound. Storage for the 6,000 normal panels remains unknown because no normal prefix has been serialized. Reassess exact capacity at the 480-full-panel boundary.

Capacity controls retain a 2 GiB disk floor, 5 GiB launch/raw-copy memory reserve, 2 GiB emergency margin and 10 GiB registration-spill cap. The fresh capacity and ownership snapshot passed the consolidation checks. Capacity for all remaining collection, compression and audits is not guaranteed; capacity failures pause the same owned child for inspection.




Prior source and runtime restoration evidence remains available in `recovery-004/evidence/frozen_sources-restoration.json` and `recovery-004/evidence/pinned_runtime-restoration.json`. Their receipt hashes and durable archive identities are listed in `chain-scope-clarification.json`. The current unchanged frozen verifier passed again in `recovery-009/launch-review/frozen-source-verification.json`.

## Finalized restart point

The stale prior process record was retained under an exclusive execution lock; no saved PID was signaled. Launch009 controls and its review are finalized. The unchanged driver still uses the launch006 review binding. The final prelaunch check found 6,016,790,528 bytes (6.02 GB) of available disk space and 361 verified registration links. The same guards remain in effect; this is permission to resume deterministic collection, not a claim of scientific completion.

The 128 archives count describes dependencies restored during this recovery: 25 original, 22 R1 and 81 previously missing raw archives. The full raw-prefix check covers all 163,092 prefix files, including the 9,598 already available files, and the existing 111 publication catalogs retain their checked bindings.

Only exact redundant transport copies were retired after recorded hash or compressed-prefix checks. The complete 007a checkpoint archive remains locally intact; all three durable saved parts were freshly downloaded and verified. The redundant local split copies were subsequently retired, so restore from the retained full ZIP or the recorded saved parts.

This report and evidence bundle capture the verified state immediately before launch. A running process or further collection progress is not claimed by this saved record.

Next — Me: Nothing | ChatGPT: Start the owned launch009 wrapper, verify its fresh process identity, and confirm collection advances beyond panel 361.
