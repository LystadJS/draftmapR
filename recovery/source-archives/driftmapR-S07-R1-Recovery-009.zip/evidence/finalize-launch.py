from pathlib import Path
import fcntl, hashlib, importlib.util, json, os, shutil, time

E = Path('/workspace/scratch/1e9a01af2c37/recovery-009')
OPS = Path('/workspace/scratch/837e4400dd1d/study07-r1-operations')
O = OPS / 'launch-009'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def write(p, value):
    with Path(p).open('x') as f:
        json.dump(value, f, indent=2)
        f.flush()
        os.fsync(f.fileno())

gate = json.loads((E / 'launch-review/launch009-review-ready.json').read_text())
assert gate['status'] == 'passed' and gate['reserved_launch_authorized']
chain = Path(gate['complete_chain_review'])
assert sha(chain) == gate['complete_chain_review_sha256']
assert json.loads(chain.read_text())['status'] == 'VERIFIED_COMPLETE_RESTART_CHAIN'
for p, h in gate['code_hashes'].items():
    assert sha(p) == h, p
for p, h in gate['independent_evidence'].items():
    assert sha(p) == h, p
assert not (O / 'launch-review.json').exists()
assert not (O / 'owned-launch.json').exists()
lock = (OPS / 'execution.lock').open('a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
old = OPS / 'execution-process.json'
old_hash = sha(old)
prior = json.loads(old.read_text())
assert prior['supervisor_token'] == 'dfdd23e52abf4d4384e984c620dafd18'
assert prior['child_state'] == 'paused_by_request'
assert time.time() - prior['updated_at_unix'] > 300
spec = importlib.util.spec_from_file_location('launch009_base', OPS / 'execute-resume.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
memory_before = base.raw_allocation_guard(0, reserve_bytes=5 * base.GIB)
assert not Path('/root/.codex/tmp/s07r1-compression-006').exists()
assert not list((OPS.parent / 'study07-results/S07-R1/tables').glob('*.csv.gz'))
assert not list((OPS.parent / 'study07-results/S07-R1/tables').glob('*.committing'))
spill = base.make_spill_action(OPS, OPS.parent / 'study07-results/S07-R1', audit_headroom_bytes=5 * base.GIB)()
capacity = {'time': time.time(), 'disk': shutil.disk_usage(OPS)._asdict(),
            'memory': base.raw_allocation_guard(0, reserve_bytes=5 * base.GIB),
            'compression_filesystem': shutil.disk_usage('/root/.codex/tmp')._asdict(),
            'spill': spill}
assert capacity['disk']['free'] >= 4100000000, 'Empirical full-panel phase headroom not met'
assert capacity['compression_filesystem']['free'] >= 5 * base.GIB
assert spill['owned_links'] == 361
assert sha(old) == old_hash, 'Prior process metadata changed during review'
archive = OPS / 'execution-process-before-launch009.json'
assert not archive.exists()
record = {'status': 'REVIEWED_STALE_PROCESS_ARCHIVE_INTENT', 'time': time.time(),
          'old_path': str(old), 'retained_path': str(archive), 'sha256': old_hash,
          'prior_supervisor_token': prior['supervisor_token'],
          'prior_updated_at_unix': prior['updated_at_unix'],
          'execution_lock_exclusive': True, 'foreign_pids_signaled': False,
          'new_collection_started': False, 'capacity': capacity}
write(E / 'launch-finalization-intent.json', record)
os.rename(old, archive)
assert sha(archive) == old_hash and not old.exists()
gate.update(time=time.time(), lock_available=True, final_storage_snapshot=capacity,
            prior_process_state_retained=str(archive), prior_process_state_sha256=old_hash,
            root_launch_finalization_actions=['Save reviewed controls and recovery evidence',
                                              'Start owned wrapper and verify fresh process state'])
gate['independent_evidence'][str(E / 'launch-finalization-intent.json')] = sha(E / 'launch-finalization-intent.json')
write(O / 'launch-review.json', gate)
record.update(status='LAUNCH009_READY_AND_STALE_STATE_RETAINED',
              launch_review_sha256=sha(O / 'launch-review.json'))
write(E / 'launch-finalization-complete.json', record)
print(json.dumps(record), flush=True)
