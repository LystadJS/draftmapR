from pathlib import Path
import json,csv,hashlib,zipfile,bisect,os,time,traceback
ROOT=Path('/workspace/scratch/837e4400dd1d'); CUR=Path('/workspace/scratch/1e9a01af2c37');OPS=ROOT/'study07-r1-operations';ST=OPS/'resumable-collection-state';RUN=ROOT/'study07-results/S07-R1';EV=CUR/'recovery-009/launch-review'
started=time.time();out={'status':'RUNNING','started':started,'scientific_execution':False,'scope':'Current361-panel state; raw163093:198538; all journaled JSON, compact caches and verification receipts; raw1:163092 and original input payloads deferred to restoration audits.'}
def dig(p,name='sha256'):
 with p.open('rb') as f:return hashlib.file_digest(f,name).hexdigest()
def check(condition,detail):
 if not condition:raise AssertionError(detail)
def records(p):
 b=p.read_bytes();check(b.endswith(b'\n'),'Unterminated journal '+str(p));return [json.loads(s) for s in b.splitlines()]
try:
 arc=CUR/'driftmapR-S07-R1-progress-20260922-007a.zip';receipt=json.loads((CUR/'driftmapR-S07-R1-progress-20260922-007a.json').read_text());check(arc.stat().st_size==receipt['bytes'] and dig(arc)==receipt['sha256'],'Archive identity')
 with zipfile.ZipFile(arc) as z:
  manifest=json.loads(z.read('SNAPSHOT-MANIFEST.json'));check(manifest['collection_panels']==361 and manifest['through_chunk']==198537 and manifest['journaled_chunks']==198538,'Snapshot boundary')
  members={r['member']:r for r in manifest['members']};check(len(members)==len(manifest['members']),'Duplicate snapshot names')
 out['archive_sha256']=receipt['sha256'];out['archive_bytes']=receipt['bytes']
 journals=['panel-journal.jsonl','chunk-journal.jsonl','json-journal.jsonl','compact-cache-005.jsonl'];bindings=['binding.rds','driver-binding.rds','driver-binding-006.rds'];before={name:dig(ST/name) for name in journals+bindings}
 for name,h in before.items():check(members['pinned-workspace/study07-r1-operations/resumable-collection-state/'+name]['sha256']==h,'Snapshot state identity '+name)
 panels=records(ST/'panel-journal.jsonl');chunks=records(ST/'chunk-journal.jsonl');js=records(ST/'json-journal.jsonl');caches=records(ST/'compact-cache-005.jsonl');cat={r['path']:r for r in csv.DictReader((ROOT/'study07-r1-checkpoints/checkpoint-03/checkpoint-03-cumulative-immutable-catalog.csv').open())}
 check(len(panels)==361 and [p['panel_index'] for p in panels]==list(range(1,362)),'Panel sequence');check(panels[-1]['through_chunk']==198537,'Panel boundary');check(len(chunks)==198538 and [r['serial'] for r in chunks]==list(range(1,198539)),'Chunk sequence')
 check(len(caches)==362 and len({r['key'] for r in caches})==362,'Compact cache grid')
 for p in panels:check(p['checkpoint_md5']==cat['checkpoints/'+p['key']+'.rds']['md5'],'Panel checkpoint '+p['key'])
 ends=[p['through_chunk'] for p in panels];check(sorted(set(ends))==ends,'Monotonic boundaries')
 for r in chunks:
  ix=bisect.bisect_left(ends,r['serial']);key=panels[ix]['key'] if ix<len(panels) else caches[-1]['key']
  check(r['panel']==key and r['checkpoint_md5']==cat['checkpoints/'+key+'.rds']['md5'],'Chunk source identity '+str(r['serial']));check(r['chunk']==f'csv-chunks-20260921192657143845-45-1/{r["serial"]:07d}.csv','Chunk path '+str(r['serial']))
 intents={r['source']:r for r in records(OPS/'spill-events.jsonl') if r.get('event')=='verified_intent'}
 counts={'new_raw_files':0,'new_raw_bytes':0,'raw_symlinks_verified':0,'journaled_json_files':0,'journaled_json_bytes':0,'compact_cache_files':0,'verification_receipt_files':0,'snapshot_sha_verified_files':0};seen=set()
 def member_verify(p,md5=None,size=None):
  member='pinned-workspace/'+str(p.relative_to(ROOT));rec=members.get(member);check(rec is not None,'Missing snapshot member '+member)
  hs=hashlib.sha256();hm=hashlib.md5();n=0
  with p.open('rb') as f:
   while b:=f.read(1024*1024):hs.update(b);hm.update(b);n+=len(b)
  check(n==rec['bytes'] and hs.hexdigest()==rec['sha256'],'Current snapshot bytes '+str(p))
  if md5 is not None:check(hm.hexdigest()==md5,'Current journal MD5 '+str(p))
  if size is not None:check(n==size,'Current journal size '+str(p))
  counts['snapshot_sha_verified_files']+=1;seen.add(member);return n
 for r in chunks[163092:]:
  p=RUN/r['chunk'];check(p.is_file(),'Missing delta raw '+str(p))
  if p.is_symlink():
   dest=Path('/dev/shm/s07r1-registration')/Path(r['chunk']);intent=intents.get(str(p));check(os.readlink(p)==str(dest) and dest.is_file() and not dest.is_symlink(),'Invalid owned raw link '+str(p));check(intent and intent['destination']==str(dest) and intent['md5']==r['md5'] and intent['bytes']==r['bytes'],'Invalid raw ownership intent '+str(p));counts['raw_symlinks_verified']+=1
  counts['new_raw_bytes']+=member_verify(p,r['md5'],r['bytes']);counts['new_raw_files']+=1
 check(counts['new_raw_files']==35446,'Delta count')
 check(len({r['path'] for r in js})==len(js),'Duplicate JSON paths')
 for r in js:
  p=RUN/'tables'/r['path'];check(p.is_file(),'Missing journaled JSON '+str(p));check(p.stat().st_size==r['bytes'] and dig(p,'md5')==r['md5'],'Journaled JSON bytes '+str(p));counts['journaled_json_files']+=1;counts['journaled_json_bytes']+=r['bytes']
  if r['path'].startswith('panels/'):check(r['checkpoint_md5']==cat['checkpoints/'+r['key']+'.rds']['md5'],'JSON source checkpoint '+r['key'])
  member='pinned-workspace/'+str(p.relative_to(ROOT))
  if member in members:member_verify(p,r['md5'],r['bytes'])
 for r in caches:
  p=ST/'compact-cache-005'/(r['key']+'.rds');check(dig(p)==r['sha256'] and r['checkpoint_md5']==cat['checkpoints/'+r['key']+'.rds']['md5'],'Compact cache binding '+r['key']);member_verify(p);counts['compact_cache_files']+=1
 for p in sorted((ST/'verification-006').glob('*.rds')):member_verify(p);counts['verification_receipt_files']+=1
 check(counts['verification_receipt_files']==6480,'Receipt count')
 new_json_members=[n for n in members if n.startswith('pinned-workspace/study07-results/S07-R1/tables/') and n.endswith('.json')]
 for member in new_json_members:
  if member not in seen:member_verify(ROOT/member.removeprefix('pinned-workspace/'))
 check(len(new_json_members)==87,'New JSON member count');counts['new_json_members_verified']=len(new_json_members)
 provenance=RUN/'recovery-provenance.json';check(provenance.stat().st_size==6073492 and dig(provenance)=='599aa268dc4a0e82a39366effac7bb21e6d0c6cbc8686c048761b5d1f1c8331b','Recovery provenance identity')
 check(before=={n:dig(ST/n) for n in before},'Bound state changed during audit')
 out.update(status='PASSED',counts=counts,committed_panels=len(panels),through_chunk=panels[-1]['through_chunk'],journaled_chunks=len(chunks),retained_tail=chunks[-1],bound_state_sha256=before,provenance_sha256=dig(provenance),finished=time.time(),elapsed=time.time()-started)
except BaseException as e:
 out.update(status='FAILED',error=str(e),traceback=traceback.format_exc(),finished=time.time());(EV/'current-state-audit.json').write_text(json.dumps(out,indent=2));raise
(EV/'current-state-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
