root <- "/workspace/scratch/837e4400dd1d"
ops <- file.path(root,"study07-r1-operations"); state <- file.path(ops,"resumable-collection-state")
out <- file.path(root,"study07-results/S07-R1"); original <- file.path(root,"study07-results/S07-D1")
source(file.path(root,"study07-recovery/R/load.R"));s07r1_load(file.path(root,"study07-recovery"))
source(file.path(ops,"resumable-collect.R"))
main <- function() {
identity <- s07r1_identity(FALSE);ancestor <- s07i_verify_implementation(); jobs <- s07i_jobs()
stopifnot(length(jobs)==6480L,sum(vapply(jobs,`[[`,integer(1),"B_planned"))==1313520L,
 identical(readRDS(file.path(out,"execution-identity.rds")),identity), identical(readRDS(file.path(out,"seed-plan.rds")),jobs))
stopifnot(s07ops_sha(file.path(out,"source-binding.rds"))=="6e345a02b8fd2660205ea22ed4dbc69b1c65b3d599361842e7d215a6a3ba0d7c")
sb <- readRDS(file.path(out,"source-binding.rds"));stopifnot(identical(sb$source_out,original),identical(sb$original_identity,ancestor),nrow(sb$preflight)==6480L)
stopifnot(identical(sb$preflight$case_id,vapply(jobs,`[[`,character(1),"case_id")),identical(as.integer(sb$preflight$dataset_id),vapply(jobs,`[[`,integer(1),"dataset_id")),identical(as.integer(sb$preflight$B),vapply(jobs,`[[`,integer(1),"B_planned")),identical(as.integer(sb$preflight$m),vapply(jobs,`[[`,integer(1),"m")))
publication <- jsonlite::read_json(file.path(ops,"PUBLICATION-INDEX.json"),simplifyVector=FALSE);metadata <- "/workspace/scratch/1e9a01af2c37/final-preservation"; available <- character()
for(inc in publication$increments) if(startsWith(inc$tag,"r1-final-raw")) for(a in inc$artifacts) if(endsWith(a$filename,"-products-catalog.csv")) {
  stopifnot(basename(a$filename)==a$filename,basename(inc$tag)==inc$tag)
  p <- normalizePath(file.path(metadata,inc$tag,a$filename),mustWork=TRUE)
  stopifnot(file.info(p)$size==a$bytes,s07ops_sha(p)==a$sha256);available <- c(available,p)
}
b <- readRDS(file.path(state,"binding.rds"));stopifnot(all(b$published_catalogs %in% available))
paths <- file.path(out,"checkpoints",paste0(vapply(jobs,s07i_key,character(1)),".rds"))
cat <- read.csv(file.path(root,"study07-r1-checkpoints/checkpoint-03/checkpoint-03-cumulative-immutable-catalog.csv"),stringsAsFactors=FALSE)
cm <- unname(cat$md5[match(file.path("checkpoints",basename(paths)),cat$path)]);stopifnot(!anyNA(cm),all(file.exists(paths)))
expected <- list(schema="S07-R1-operational-collection-v1",paths=normalizePath(paths),jobs=jobs,identity=identity,checkpoint_md5=cm,out=normalizePath(file.path(out,"tables")),chunk_dir=normalizePath(file.path(out,"csv-chunks-20260921192657143845-45-1")),published_catalogs=normalizePath(b$published_catalogs,mustWork=TRUE),catalog_sha256=setNames(s07ops_sha(b$published_catalogs),b$published_catalogs),guard=s07ops_guard(),no_measurements_generated=TRUE,no_draws_generated=TRUE,no_fits_generated=TRUE)
stopifnot(identical(b,expected))
db <- readRDS(file.path(state,"driver-binding-006.rds"))
expected_driver <- list(adapter_sha256=s07ops_sha(file.path(ops,"resumable-collect-prefix-005.R")),driver_sha256=s07ops_sha(file.path(ops,"resume-collection-prefix-006.R")),identity=identity,source_out=original,out=out,state_dir=state,chunk_dir=expected$chunk_dir,review_gate_sha256=s07ops_sha(file.path(ops,"launch-006/launch-review.json")))
stopifnot(identical(db,expected_driver))
cat(jsonlite::toJSON(list(status="PASSED",frozen_identity=identity$freeze_sha256,planned_panels=length(jobs),planned_draws=sum(vapply(jobs,`[[`,integer(1),"B_planned")),publication_catalogs_available=length(available),publication_catalogs_bound=length(b$published_catalogs),full_collection_binding=TRUE,driver006_binding=TRUE,source_binding=TRUE,current_original_payloads_deferred=TRUE,current_r1_payload_catalog_audit_delegated=TRUE,scientific_execution=FALSE),pretty=TRUE,auto_unbox=TRUE),"\n")
}
tryCatch(main(),finally=s07ops_worker(close=TRUE))
