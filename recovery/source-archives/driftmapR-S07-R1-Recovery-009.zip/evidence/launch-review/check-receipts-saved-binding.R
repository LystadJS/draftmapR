root <- "/workspace/scratch/837e4400dd1d"
ops <- file.path(root,"study07-r1-operations")
state <- file.path(ops,"resumable-collection-state")
source(file.path(root,"study07-recovery/R/load.R")); s07r1_load(file.path(root,"study07-recovery"))
binding <- readRDS(file.path(state,"driver-binding-006.rds"))
ancestor <- binding$identity$original_identity
jobs <- readRDS(file.path(state,"binding.rds"))$jobs
stopifnot(length(jobs)==6480L,identical(jobs,s07i_jobs()))
original <- read.csv(file.path(root,"study07-recovery/evidence/original-checkpoint-catalog.csv"),stringsAsFactors=FALSE)
recovery <- read.csv(file.path(root,"study07-r1-checkpoints/checkpoint-03/checkpoint-03-cumulative-immutable-catalog.csv"),stringsAsFactors=FALSE)
digest_by_path <- setNames(c(original$md5,recovery$md5), c(file.path(binding$source_out,original$path),file.path(binding$out,recovery$path)))
for (j in jobs) {
  key <- s07i_key(j)
  vf <- c(file.path(binding$source_out,"draw-plans",paste0(key,".rds")), file.path(binding$out,"draw-plans",paste0(key,".rds")),file.path(binding$out,"checkpoints",paste0(key,".rds")))
  if(j$pipeline=="full_estimator") vf <- c(vf,file.path(binding$source_out,"population",paste0(j$case_id,".rds")),file.path(binding$out,"population",paste0(j$case_id,".rds")))
  vf <- c(vf,paste0(vf,".manifest.rds"))
  md5 <- unname(digest_by_path[vf]);stopifnot(!anyNA(md5))
  expected <- list(job=j,identity=binding$identity,ancestor=ancestor,files=vf,md5=md5,driver_sha256=binding$driver_sha256)
  stopifnot(identical(readRDS(file.path(state,"verification-006",paste0(key,".rds"))),expected))
}
cat(jsonlite::toJSON(list(status="PASSED_RECEIPT_CATALOG_BINDINGS",receipts=length(jobs),current_payload_byte_checks=FALSE,scientific_execution=FALSE),auto_unbox=TRUE),"\n")
