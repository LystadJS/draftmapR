#!/usr/bin/env python3
"""Consolidate completed restore proofs without downloading, mutating science, or launching.

Run once after original/catalog-audit.json and raw/verified-prefix.json exist.
Missing prerequisites produce a pending evidence/report and exit2. No polling,
retry, stale-state removal, process signaling, or scientific execution occurs.
All writes stay in recovery-009/launch-review. Available execution.lock is held
only during final read-only storage checks; original control files are untouched.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv, fcntl, hashlib, json, os, shutil, sys, time, traceback

ROOT=Path('/workspace/scratch/837e4400dd1d')
CUR=Path('/workspace/scratch/1e9a01af2c37')
BASE=CUR/'recovery-009'; EV=BASE/'launch-review'
OPS=ROOT/'study07-r1-operations'; ST=OPS/'resumable-collection-state'
RUN=ROOT/'study07-results/S07-R1'; RAW=RUN/'csv-chunks-20260921192657143845-45-1'
GIB=1024**3
ORIGINAL_SHA='64e7b5d059ef95141e1784c39038b46540f59d7c647a3308dc8c10bf3c70960f'
R1_SHA='9ad0c789ab581bb0acf009c7a5a1226b27d2f5ee274563397b22a987cad88fd8'
ARCHIVE_SHA='6a77c721e26ccf794169f19e0db0fa0da8ba0b33f1710284bedbb4e37987024d'
STATE_SHA='fada1dd421cce09e15d7d00275fa1a27a101246d4b95064946cf81d185257cd2'
BINDING_LOG_SHA='7b247ceb4f817048100e9fa62526474c3b2fdef1b0f2094ab9b52abea2105bc7'
EVIDENCE={}

def sha(p, kind='sha256'):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,kind).hexdigest()

def need(ok, message):
    if not ok:raise AssertionError(message)

def read(p):
    p=Path(p);b=p.read_bytes();EVIDENCE[str(p)]=hashlib.sha256(b).hexdigest();return json.loads(b)

def save(name, data):
    p=EV/name;tmp=EV/(name+'.writing')
    need(not tmp.exists(),'Uncertain prior evidence write requires review: '+str(tmp))
    with tmp.open('x') as f:json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)

def catalog(path, expected_sha):
    need(sha(path)==expected_sha,'Catalog identity: '+str(path))
    with path.open() as f:rows=list(csv.DictReader(f))
    need(len(rows)==len({x['path'] for x in rows}),'Duplicate catalog path')
    return {x['path']:{'md5':x['md5'],'bytes':int(x['bytes'])} for x in rows}

def report(result):
    passed=result['status']=='VERIFIED_COMPLETE_RESTART_CHAIN'
    headline=('The 361-panel recovery chain is verified and ready for owned launch finalization.'
              if passed else 'The 361-panel checkpoint is preserved; complete-chain consolidation is pending.')
    rows=[]
    for label,n,key in [('Original checkpoints',25,'original/catalog-audit.json'),('Recovered R1 checkpoints',22,'r1/r1-restore-complete.json'),('Older raw prefix',81,'raw/verified-prefix.json')]:
        p=BASE/key;value=json.loads(p.read_text()) if p.exists() else {}
        good=value.get('status') in ('PASS','RAW_PREFIX_FULLY_VERIFIED')
        rows.append(f'| {label} | {n} | {"Verified" if good else "Pending final receipt"} |')
    dependency_status=('All 128 archive identities, member coverage and completed catalog/prefix audits passed consolidation.'
                       if passed else 'The chain has 128 recorded dependency archives. Full verification awaits the final receipts listed below.')
    capacity_status=('The fresh capacity and ownership snapshot passed the consolidation checks.'
                     if passed else 'Fresh capacity and ownership checks remain required after restoration finishes.')
    pending='\n'.join('- '+s for s in result.get('missing_prerequisites',[]))
    fp=EV/'remaining-disk-forecast.json'
    if fp.exists():
        f=json.loads(fp.read_text());maximum=f['estimates']['maximum_observed_proxy']['total_incremental_workspace_bytes']
        forecast_note=f'The 119 remaining full panels have an empirical workspace-growth allowance of {maximum/1e9:.3f} GB excluding registration, or {(maximum+2*GIB)/1e9:.3f} GB including the retained disk floor. This uses observed component maxima and a larger-m proxy for unobserved sparse panels; it is not a guaranteed bound. Storage for the 6,000 normal panels remains unknown because no normal prefix has been serialized. Reassess exact capacity at the 480-full-panel boundary.'
    else:forecast_note='Remaining full-panel and normal-phase storage requirements have not been quantified.'
    pending_section=('## Pending prerequisites\n\n'+pending) if pending else ''
    next_action=('Finalize and save the reviewed launch009 controls, retain stale process metadata, then start and verify the owned collector.'
                 if passed else 'Finish dependency restoration, consolidate the complete chain and capacity proofs, then prepare the owned restart.')
    s=f'''# driftmapR S07-R1 Recovery009

{headline}

| Dependency group | Archives | Status |
|---|---:|---|
{chr(10).join(rows)}

{dependency_status}

The saved collection boundary is **361 / 6,480 panels (5.6%)**, through chunk **198537**. Journaled chunk **198538**, the first draw export for panel 362, is retained for verified reuse. The checkpoint contains 362 compact caches and 6,480 saved input-verification receipts.

Independent current-state verification checked 35,446 incremental raw files (1,947,238,905 bytes), all 368 journaled JSON files, caches, receipts, provenance and bindings. The older prefix contains 163,092 raw files (12,848,037,331 bytes).

The checkpoint source archive is `driftmapR-S07-R1-progress-20260922-007a.zip`: 569,351,915 bytes; SHA256 `{ARCHIVE_SHA}`. Its saved multipart transport requires **part002 version 1**; version 0 was truncated. Fresh downloads of all three saved parts passed individual hashes and reconstructed the exact source archive; part002 version 1 was verified.

Recovery preserves frozen methods, checkpoints, seeds, runtime and exact draw vectors. This continuation generated **zero new measurement panels, fits or draw vectors**. Collection, frozen analysis, final audits and final preservation coverage remain unfinished. Scientific completion is not claimed.

Launch009 uses byte-identical launch007 controls and unchanged driver006. The driver retains its **launch006 review gate**, which is part of its persisted binding. Root must review and retain stale process metadata before launch, start through the owned wrapper, and confirm the new child. Saved PIDs must never be signaled. This consolidation script does not launch anything.

{forecast_note}

Capacity controls retain a 2 GiB disk floor, 5 GiB launch/raw-copy memory reserve, 2 GiB emergency margin and 10 GiB registration-spill cap. {capacity_status} Capacity for all remaining collection, compression and audits is not guaranteed; capacity failures pause the same owned child for inspection.

{pending_section}

Next — Me: Nothing | ChatGPT: {next_action}
'''
    (EV/'Recovery-009-operational-report-draft.md').write_text(s)

def main():
    started=time.time()
    required=[BASE/'original/catalog-audit.json',BASE/'r1/r1-restore-complete.json',BASE/'r1/final-catalog-audit.json',BASE/'raw/verified-prefix.json',BASE/'spill-relink-result.json',BASE/'checkpoint361-roundtrip-proof.json',EV/'current-state-audit.json',EV/'check-current-bindings.log',EV/'frozen-source-verification.json',EV/'check-receipts-saved-binding.log',EV/'remaining-disk-forecast.json',EV/'launch009-review-proposal.json']
    missing=[str(p) for p in required if not p.is_file()]
    if missing:
        value=dict(status='PENDING_FINAL_RESTORE_RECEIPTS',time=time.time(),missing_prerequisites=missing,scientific_execution=False)
        save('complete-chain-consolidation-pending.json',value);report(value);print(json.dumps(value));return 2
    proposal=read(EV/'launch009-review-proposal.json')
    forecast=read(EV/'remaining-disk-forecast.json')
    need(forecast['status']=='EMPIRICAL_OPERATIONAL_FORECAST_NOT_CAPACITY_CERTIFICATION' and forecast['committed_panels']==361 and forecast['remaining_full_panels']==119 and forecast['remaining_normal_panels']==6000,'Capacity forecast scope')
    need(forecast['chunk_journal_sha256']==sha(ST/'chunk-journal.jsonl') and forecast['frozen_binding_sha256']==sha(ST/'binding.rds'),'Capacity forecast state bindings')
    need(sha(EV/'current-state-audit.json')==STATE_SHA,'Independent state proof changed')
    need(sha(EV/'check-current-bindings.log')==BINDING_LOG_SHA,'Independent binding proof changed')
    state=read(EV/'current-state-audit.json');bindings=read(EV/'check-current-bindings.log');frozen=read(EV/'frozen-source-verification.json');receipts=read(EV/'check-receipts-saved-binding.log')
    need(state['status']=='PASSED' and state['committed_panels']==361 and state['through_chunk']==198537 and state['journaled_chunks']==198538,'Current-state boundary proof')
    need(bindings['status']=='PASSED' and bindings['full_collection_binding'] and bindings['driver006_binding'] and bindings['source_binding'] and bindings['publication_catalogs_bound']==111,'Current binding proof')
    need(frozen['exit_code']==0 and 'e3edea53e346ce6ab1f966b8a9e6fcda6025bd1ca4e8d24a90be4ba297eba3b4' in frozen['stdout'],'Frozen source proof')
    need(receipts['status']=='PASSED_RECEIPT_CATALOG_BINDINGS' and receipts['receipts']==6480,'Saved receipt/catalog bindings')
    for n,h in state['bound_state_sha256'].items():need(sha(ST/n)==h,'Current bound state changed: '+n)
    need(sha(RUN/'recovery-provenance.json')==state['provenance_sha256'],'Current provenance changed')
    for p,h in proposal['code_hashes'].items():need(sha(Path(p))==h,'Launch control changed: '+p)
    need(sha(OPS/'launch-006/launch-review.json')==proposal['driver_review_gate_sha256'],'Persisted O6 gate changed')
    saved=read(CUR/'recovery-008/checkpoint361-recovery-index.json')
    need(saved['collection_panels']==361 and saved['source_archive_sha256']==ARCHIVE_SHA and saved['part002_required_version']==1,'Saved checkpoint identity')
    part2=[r for r in saved['saved_parts_and_support_files'] if r['file_name'].endswith('.part002')]
    need(len(part2)==1 and part2[0]['status']=='succeeded' and part2[0]['current_version_number']==1,'Part002 saved version1 required')
    roundtrip=read(BASE/'checkpoint361-roundtrip-proof.json')
    need(roundtrip['status']=='LIBRARY_ROUNDTRIP_EXACT_BYTES_VERIFIED' and roundtrip['reconstructed_bytes']==569351915 and roundtrip['reconstructed_sha256']==ARCHIVE_SHA and roundtrip['collection_panels']==361,'Fresh saved-checkpoint roundtrip proof')
    transport=read(Path(roundtrip['retained_manifest']));need(transport['source_sha256']==ARCHIVE_SHA and len(roundtrip['parts'])==3,'Checkpoint transport manifest identity')
    saved_parts={r['file_name']:r for r in saved['saved_parts_and_support_files'] if '.zip.part' in r['file_name']}
    for expected,actual in zip(transport['parts'],roundtrip['parts']):
        need(all(expected[k]==actual[k] for k in ['index','file','offset','bytes','sha256']),'Roundtrip part identity')
        saved_part=saved_parts[actual['file']]
        need(actual['library_file_id']==saved_part['library_file_id'] and actual['file_id']==saved_part['file_id'] and actual['version']==saved_part['current_version_number'],'Roundtrip saved part/version identity')
    need(roundtrip['parts'][1]['version']==1,'Roundtrip used wrong part002 version')
    need(sha(BASE/'checkpoint361-read.json')==roundtrip['read_receipt_sha256'],'Roundtrip read receipt identity')
    need(sha(BASE/'checkpoint361-materialize.json')==roundtrip['materialization_receipt_sha256'],'Roundtrip materialization receipt identity')
    EVIDENCE[str(BASE/'checkpoint361-read.json')]=roundtrip['read_receipt_sha256']
    EVIDENCE[str(BASE/'checkpoint361-materialize.json')]=roundtrip['materialization_receipt_sha256']
    immutable=read(CUR/'recovery-008/immutable-restore-dependencies.json')['archives']
    original_expected=[r for r in immutable if r['kind']=='original'];r1_expected=[r for r in immutable if r['kind']=='r1'];need(len(original_expected)==25 and len(r1_expected)==22,'Immutable archive grid')
    original=read(BASE/'original/catalog-audit.json');r1=read(BASE/'r1/r1-restore-complete.json');r1final=read(BASE/'r1/final-catalog-audit.json')
    need(original['status']=='PASS' and original['catalog_sha256']==ORIGINAL_SHA and original['expected_files']==25939 and original['expected_bytes']==5380151375 and original['actual_bytes']==5380151375 and original['archive_count']==25 and original['archive_coverage_files']==25939 and original['archive_coverage_bytes']==5380151375 and not original['errors'],'Original final catalog/coverage proof')
    need(r1['status']=='PASS' and r1['archive_count']==22 and r1['immutable_files']==25944 and r1['immutable_bytes']==5431046710 and r1['catalog_sha256']==R1_SHA and r1['all_library_calls_finished'] and r1['all_local_restore_and_audit_processes_finished'],'R1 complete proof')
    need(sha(BASE/'r1/final-catalog-audit.json')==r1['final_catalog_audit_sha256'],'R1 bound final audit')
    need(r1final['status']=='PASS' and r1final['verified_files']==25944 and r1final['verified_bytes']==5431046710 and not r1final['missing'] and not r1final['mismatches'],'R1 final payload audit')
    catalogs={'original':catalog(ROOT/'study07-recovery/evidence/original-checkpoint-catalog.csv',ORIGINAL_SHA),'r1':catalog(ROOT/'study07-r1-checkpoints/checkpoint-03/checkpoint-03-cumulative-immutable-catalog.csv',R1_SHA)}
    original_files=list((BASE/'original').glob('archive-*-restored.json'));original_records={}
    for p in original_files:
        row=read(p);name=row['archive']['filename'];need(name not in original_records,'Duplicate original archive receipt');original_records[name]=(p,row)
    r1record_map={r['filename']:r for r in r1['archives']}
    groups={}
    for kind,expected in [('original',original_expected),('r1',r1_expected)]:
        covered={};total_archive_bytes=0
        for exp in expected:
            if kind=='original':p,row=original_records[exp['filename']]
            else:p=BASE/'r1'/(exp['filename']+'.restored.json');row=read(p);need(sha(p)==r1record_map[exp['filename']]['restoration_receipt_sha256'],'R1 receipt hash')
            need(row['status']=='PASS','Immutable member restoration did not pass')
            for k in ['filename','library_file_id','version','bytes','sha256']:need(row['archive'][k]==exp[k],f'Archive identity mismatch {kind} {k}')
            for m in row['members']:
                need(m['path'] not in covered,'Repeated archive member '+m['path']);need(m['path'] in catalogs[kind],'Unexpected archive member '+m['path']);need({'bytes':m['bytes'],'md5':m['md5']}==catalogs[kind][m['path']],'Member identity mismatch '+m['path']);covered[m['path']]=m['bytes']
            total_archive_bytes+=exp['bytes']
        need(set(covered)==set(catalogs[kind]),'Archive coverage grid mismatch '+kind)
        groups[kind]=dict(archives=len(expected),archive_bytes=total_archive_bytes,files=len(covered),payload_bytes=sum(covered.values()))
    raw=read(BASE/'raw/verified-prefix.json');rawplan=read(CUR/'recovery-008/raw/missing-prefix-dependencies.json')
    need(raw['status']=='RAW_PREFIX_FULLY_VERIFIED' and raw['prefix_files']==163092 and raw['prefix_bytes']==12848037331 and raw['archive_dependencies']==81 and raw['source_journal_sha256']==state['bound_state_sha256']['chunk-journal.jsonl'] and raw['all_library_calls_finished'],'Raw final prefix proof')
    need(all(raw[k]==0 for k in ['new_scientific_panels','new_fits','new_draws','scientific_payloads_deleted']),'Raw restoration generated or deleted science')
    need(len(rawplan['archives'])==81 and len(raw['archive_receipts'])==81,'Raw archive count')
    rawrecords={}
    for r in raw['archive_receipts']:
        p=Path(r['path']);need(p.parent==BASE/'raw' and sha(p)==r['sha256'],'Raw receipt path/hash');row=read(p);need(row['library_file_id'] not in rawrecords,'Duplicate raw dependency receipt');rawrecords[row['library_file_id']]=row
    for exp in rawplan['archives']:
        row=rawrecords[exp['library_file_id']]
        need(row['status']=='ARCHIVE_AND_ALL_MEMBERS_VERIFIED_PREFIX_RESTORED' and row['archive_sha256']==exp['sha256'] and row['archive_bytes']==exp['bytes'] and row['version']==exp['version'] and Path(row['archive']).name==exp['filename'],'Raw archive identity/member proof')
        need(row['restored_files']+row['existing_exact_files']==len(exp['logical_paths']),'Raw restored coverage count')
        need(row['science_payloads_deleted']==0 and row['scientific_generation'] is False,'Raw write scope')
    groups['raw_prefix']=dict(archives=81,archive_bytes=sum(r['bytes'] for r in rawplan['archives']),files=raw['prefix_files'],payload_bytes=raw['prefix_bytes'])
    spill=read(BASE/'spill-relink-result.json');need('finished' in spill and spill['finished']>=spill['started'] and spill['lock_held'] and spill['result']['owned_links']==361 and spill['result']['spill_filesystem_bytes']==7596079977,'Completed guarded relink proof')
    # No collector may start during the final read-only consistency/capacity pass.
    with (OPS/'execution.lock').open('r') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        journal=[json.loads(s) for s in (ST/'chunk-journal.jsonl').read_text().splitlines()]
        need(len(journal)==198538,'Final raw journal length')
        actual={p.name for p in RAW.iterdir() if p.name.endswith('.csv')};need(actual=={f'{n:07}.csv' for n in range(1,198539)},'Complete raw committed filename grid')
        intents={x['source']:x for x in [json.loads(s) for s in (OPS/'spill-events.jsonl').read_text().splitlines()] if x.get('event')=='verified_intent'}
        links=0;regular=0;total=0;owned_targets=set();registration_bytes=0
        for row in journal:
            p=RUN/row['chunk'];need(p.is_file() and p.stat().st_size==row['bytes'],'Final raw presence/size '+str(p));total+=row['bytes']
            if row['product']=='full/geometry-registration.csv.gz':registration_bytes+=row['bytes']
            if p.is_symlink():
                target=Path('/dev/shm/s07r1-registration')/row['chunk'];intent=intents.get(str(p));need(os.readlink(p)==str(target) and target.is_file() and not target.is_symlink(),'Final raw owned target '+str(p));need(intent and intent['destination']==str(target) and intent['bytes']==row['bytes'] and intent['md5']==row['md5'],'Final raw ownership intent '+str(p));links+=1;owned_targets.add(str(target))
            else:regular+=1
        backing=[p for p in Path('/dev/shm/s07r1-registration').rglob('*') if p.is_file() and not p.is_symlink()];backing_bytes=sum(p.stat().st_size for p in backing)
        need(len(backing)==361 and backing_bytes==7596079977,'Final registration backing grid/size')
        need(backing_bytes<=10*GIB,'Spill budget exceeded')
        registration={str(Path('/dev/shm/s07r1-registration')/r['chunk']):r for r in journal if r['product']=='full/geometry-registration.csv.gz'}
        need(set(str(p) for p in backing)==set(registration),'Unexpected registration backing path')
        for p in backing:
            row=registration[str(p)];need(p.stat().st_size==row['bytes'] and sha(p,'md5')==row['md5'],'Final registration backing hash '+str(p))
        need(total==14795276236 and registration_bytes==7596079977,'Final raw byte accounting')
        memoryfields={k:int(v) for k,v in [l.split() for l in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines()]};limit=int(Path('/sys/fs/cgroup/memory.max').read_text());pinned=memoryfields['anon']+memoryfields['shmem']+max(0,memoryfields['kernel']-memoryfields['slab_reclaimable']);disk=shutil.disk_usage(ROOT)
        route=Path('/root/.codex/tmp/s07r1-compression-006');route_free=shutil.disk_usage(route.parent).free
        need(disk.free>=2*GIB,'Disk below2GiB launch floor');need(limit-pinned>=5*GIB,'Pinned memory below5GiB reserve');need(not os.path.lexists(route),'Compression006 route already exists');need(route_free>5*GIB,'Compression filesystem below5GiB preflight')
        need(not list((RUN/'tables').rglob('*.csv.gz')) and not list((RUN/'tables').rglob('*.committing')),'Prior gzip/staging output requires review')
        storage=dict(time=time.time(),execution_lock_available=True,raw_files=len(journal),raw_bytes=total,owned_raw_links=links,regular_raw_files=regular,registration_backing_files=len(backing),registration_backing_bytes=backing_bytes,raw_spill_cap_bytes=10*GIB,registration_backing_files_md5_verified=361,logical_payload_hash_proof='Original-prefix and independent incremental byte audits are bound here. Final pass also checks complete current raw grid/sizes/link ownership and freshly rehashes all361 registration backing files after guarded relinking.',disk_free_bytes=disk.free,disk_floor_bytes=2*GIB,cgroup_limit_bytes=limit,pinned_memory_bytes=pinned,available_after_pinned_bytes=limit-pinned,reserved_memory_bytes=5*GIB,compression_destination=str(route),compression_destination_absent=True,compression_filesystem_free_bytes=route_free,canonical_process_state_present=(OPS/'execution-process.json').exists())
        for n,h in state['bound_state_sha256'].items():need(sha(ST/n)==h,'State changed during final storage pass '+n)
        fcntl.flock(lock,fcntl.LOCK_UN)
    value=dict(status='VERIFIED_COMPLETE_RESTART_CHAIN',started=started,finished=time.time(),archive_count=128,groups=groups,remaining_disk_forecast=dict(path=str(EV/'remaining-disk-forecast.json'),sha256=EVIDENCE[str(EV/'remaining-disk-forecast.json')],maximum_full_panel_proxy_bytes=forecast['estimates']['maximum_observed_proxy']['total_incremental_workspace_bytes'],normal_phase='UNKNOWN_NO_OBSERVED_NORMAL_PREFIX',whole_run_capacity_certified=False),committed_panels=361,planned_panels=6480,through_chunk=198537,journaled_chunks=198538,compact_caches=362,input_receipts=6480,required_part002_version=1,checkpoint361_roundtrip_verified=True,checkpoint361_roundtrip_proof_sha256=EVIDENCE[str(BASE/'checkpoint361-roundtrip-proof.json')],storage=storage,evidence_sha256=EVIDENCE,new_fits=0,new_measurement_panels=0,new_draw_vectors=0,scientific_completion=False,collection_started=False,root_actions_remaining=['Save reviewed controls and recovery evidence','Explicitly review and retain stale execution-process.json before invocation','Start through the owned009 wrapper and verify fresh owned state'])
    save('complete-chain-consolidation.json',value)
    ready=dict(proposal);ready.update(status='passed',time=time.time(),lock_available=True,complete_chain_review=str(EV/'complete-chain-consolidation.json'),complete_chain_review_sha256=sha(EV/'complete-chain-consolidation.json'),final_storage_snapshot=storage,pending_evidence=[],root_launch_finalization_actions=value['root_actions_remaining'])
    ready.setdefault('independent_evidence',{}).update(EVIDENCE)
    save('launch009-review-ready.json',ready);report(value)
    print(json.dumps({k:v for k,v in value.items() if k!='evidence_sha256'},indent=2));return 0

if __name__=='__main__':
    try:sys.exit(main())
    except BaseException as e:
        if isinstance(e,SystemExit):raise
        failure=dict(status='BLOCKED_CONSOLIDATION_REQUIRES_REVIEW',time=time.time(),error=str(e),traceback=traceback.format_exc(),scientific_execution=False,evidence_sha256=EVIDENCE)
        save('complete-chain-consolidation-failure.json',failure);print(json.dumps(failure),file=sys.stderr);sys.exit(1)
