from pathlib import Path
from collections import defaultdict, Counter
import json,hashlib,statistics,shutil,time
ROOT=Path('/workspace/scratch/837e4400dd1d');ST=ROOT/'study07-r1-operations/resumable-collection-state';EV=Path('/workspace/scratch/1e9a01af2c37/recovery-009/launch-review')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(ST/'binding.rds')=='577876c33c2f8a8b4e7c8a59cdfbb6b6e1ac3a4b3cb4ccdffe99f735447cb2dd'
assert sha(ST/'chunk-journal.jsonl')=='a6a6d123f441864e7a47d19bffc5478b29ac4fc0969cecea2154b69141bc660f'
jobs=json.loads((EV/'capacity-bound-jobs.json').read_text());assert len(jobs)==6480
panels=[json.loads(l) for l in (ST/'panel-journal.jsonl').read_text().splitlines()];assert len(panels)==361
raw=defaultdict(Counter);metadata=Counter();jsonbytes=Counter();cachebytes=Counter();population=[]
for path in ['chunk-journal.jsonl','panel-journal.jsonl','json-journal.jsonl','compact-cache-005.jsonl']:
 for line in (ST/path).open('rb'):
  z=json.loads(line);key=z.get('panel') or z.get('key')
  if key:metadata[key]+=len(line)
  if path=='chunk-journal.jsonl':raw[key][z['product']]+=z['bytes']
  elif path=='json-journal.jsonl':
   if z['path'].startswith('panels/'):jsonbytes[key]+=z['bytes']
   else:population.append(z)
  elif path=='compact-cache-005.jsonl':cachebytes[key]=(ST/'compact-cache-005'/(key+'.rds')).stat().st_size
facts=[]
for i,p in enumerate(panels):
 j=jobs[i];key=f'{j["case_id"]}-{j["dataset_id"]:04d}';assert p['key']==key
 facts.append(dict(key=key,m=j['m'],B=j['B_planned'],pipeline=j['pipeline'],raw_excluding_registration=sum(raw[key].values())-raw[key]['full/geometry-registration.csv.gz'],panel_json=jsonbytes[key],compact_cache=cachebytes[key],journal_metadata=metadata[key]))
remaining=jobs[361:480];assert len(remaining)==119 and all(j['pipeline']=='full_estimator' and j['B_planned']==199 for j in remaining)
assert len(jobs[480:])==6000 and all(j['pipeline']=='normal_mean_control' for j in jobs[480:])
fields=['raw_excluding_registration','panel_json','compact_cache','journal_metadata'];forecasts=[];totals={label:Counter() for label in ['minimum_observed_proxy','mean_observed_proxy','maximum_observed_proxy']}
for m,poolm in [(160,160),(12,40)]:
 js=[j for j in remaining if j['m']==m];pool=[r for r in facts if r['m']==poolm and r['B']==199 and r['pipeline']=='full_estimator'];assert js and pool
 stats={f:dict(minimum=min(r[f] for r in pool),mean=statistics.mean(r[f] for r in pool),maximum=max(r[f] for r in pool)) for f in fields}
 already=Counter()
 for j in js:
  key=f'{j["case_id"]}-{j["dataset_id"]:04d}'
  already['raw_excluding_registration']+=sum(raw[key].values())-raw[key]['full/geometry-registration.csv.gz'];already['panel_json']+=jsonbytes[key];already['compact_cache']+=cachebytes[key];already['journal_metadata']+=metadata[key]
 for label,statname in [('minimum_observed_proxy','minimum'),('mean_observed_proxy','mean'),('maximum_observed_proxy','maximum')]:
  for f in fields:totals[label][f]+=len(js)*stats[f][statname]-already[f]
 forecasts.append(dict(planned_m=m,remaining_panels=len(js),observed_proxy_m=poolm,observed_proxy_panels=len(pool),observed_stats_bytes=stats,already_retained_bytes=dict(already),assumption='Same-m empirical size proxy' if m==poolm else 'No sparse m12 observed. Larger observed m40 panels used as planning proxy; not a guaranteed bound.'))
new_population=2*max(p['bytes'] for p in population)
summary={k:dict(v,population_json_allowance=new_population,total_incremental_workspace_bytes=sum(v.values())+new_population) for k,v in totals.items()}
free=shutil.disk_usage(ROOT).free;max_growth=summary['maximum_observed_proxy']['total_incremental_workspace_bytes'];floor=2*1024**3
result=dict(status='EMPIRICAL_OPERATIONAL_FORECAST_NOT_CAPACITY_CERTIFICATION',time=time.time(),frozen_binding_sha256=sha(ST/'binding.rds'),chunk_journal_sha256=sha(ST/'chunk-journal.jsonl'),bound_job_projection_sha256=sha(EV/'capacity-bound-jobs.json'),committed_panels=361,remaining_full_panels=119,remaining_normal_panels=6000,groups=forecasts,estimates=summary,current_disk_free_bytes=free,preserved_disk_floor_bytes=floor,maximum_proxy_growth_plus_disk_floor_bytes=max_growth+floor,headroom_after_maximum_full_proxy_and_floor_bytes=free-max_growth-floor,normal_phase=dict(status='UNKNOWN_NO_OBSERVED_NORMAL_PREFIX',panels=6000,raw_csv_bytes=None,panel_json_bytes=None,compact_cache_bytes=None,normal_registration_growth_bytes=0),excluded_requirements=['Unknown normal-phase raw CSV, JSON and compact caches','Final compact CSV and analysis-inputs assembly/products','Remaining summary outputs, final analysis and audit scratch','Progress preservation archives and upload/download staging','Future spill-event/log metadata and serialization temporaries','Compression output on separate tmpfs and its memory/audit headroom'],interpretation='Observed component maxima and a larger-m sparse proxy are operational planning allowances, not mathematical upper bounds. Existing first chunk/cache for panel362 are subtracted. Registration bytes are excluded from workspace forecast because unchanged spill controls relocate them to guarded backing; transfer temporaries still require headroom.',recommended_control_plan=['Retain all frozen/supervisor controls and minimum floors.','Use approximately the maximum full-phase proxy plus2GiB as a minimum planning requirement before entering the119 remaining full panels, with additional room for excluded items.','At completion of480 full panels, capture exact workspace growth and re-evaluate before the6000 normal panels consume the remaining headroom.','Estimate normal growth from naturally completed collection prefixes; do not extrapolate a verified whole-run capacity from this full-panel proxy.','On any capacity pause, preserve the same owned child and inspect; do not auto-resume or delete scientific payloads.'])
(EV/'remaining-disk-forecast.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('groups','recommended_control_plan')},indent=2))
