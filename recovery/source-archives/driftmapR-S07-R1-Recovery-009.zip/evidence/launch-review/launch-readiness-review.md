# Launch009 independent review

**Conditional pass. Full dependency restoration remains a required gate.**

- Unchanged frozen `verify.R` passed. Exact S07-R1 freeze: `e3edea53e346ce6ab1f966b8a9e6fcda6025bd1ca4e8d24a90be4ba297eba3b4`.
- Driver006 binding equality passed, including unchanged O6 review hash `015efb8a028c350f35f0e957e2e55d53145d7abe013289f01a61b36ef41b9cc0`; all16 review code hashes matched.
- Committed panel journal is contiguous through361 / chunk198537. Journal also retains draw chunk198538 for panel362; preserve it for normal verified reuse.
- All362 compact caches matched journal SHA256 and checkpoint-catalog MD5; all6480 saved input-verification receipts matched frozen jobs, identities, driver hash, input paths and authenticated catalog MD5s. These checks do not substitute for fresh payload verification after restoration.
- Static review found the active driver calls checkpoint readers, deterministic table/export transforms, frozen analysis/audits and status writers; it does not call generation, fitting, recovery-work or draw-construction entry points.

## Safe invocation

Copy launch007 owner, supervisor and launch-arguments bytes into fresh launch009. Create a new review binding those exact controls and completed restoration evidence. **Keep the driver argument pointing to launch006/launch-review.json**: changing that argument changes the persisted driver006 binding. Keep the existing compression target006, provided it remains absent. Review and retain stale process metadata after verifying execution-lock availability; never signal old namespace PIDs. Launch only through the new owner, which retains its direct child handle and exact-token pause/resume controls. It must not retry a failed/uncertain launch, write, or route automatically.

## Capacity

The observed snapshot at Unix1790119412 had21.744GB disk free,9.543GB pinned memory against21.475GB limit,360 registration backing files totaling7.577GB, and11.493GB free on the future compression filesystem. Compression006 was absent. Concurrent restorations change disk figures; remeasure before launch.

Committed registration chunks total7.596GB across361 panels.79 ordinary m160 and40 sparse m12 full-estimator panels remain. An empirical allowance using the largest observed m160 size, and largest m40 size as a conservative sparse proxy, projects9.289GB final registration; this is an estimate, not an exact bound. The10GiB cap remains enforced. The remaining6000 normal-mean panels do not add registration chunks.

Preserve2GiB disk floor,5GiB launch/raw-copy memory reserve,2GiB emergency memory margin and15second monitoring. Compression's5GiB preflight concerns target-filesystem free space; it is not a promise that the final audit will fit in memory. Completion capacity is not yet certified: final raw non-registration data, compact assembly, compressed output and audit working memory still require observed capacity checks. The supervisor pauses the same owned child on capacity failure; it does not restart it.

## Evidence

`frozen-source-verification.json`, `driver-binding-review.json`, `control-state-capacity-review.json`, `check-receipts-saved-binding.log`, and `launch-readiness-review.json`. The initial receipt diagnostic attempted to read not-yet-restored root metadata and stopped before verification; its log is retained. The completed receipt review instead uses existing authenticated saved bindings and catalogs.
