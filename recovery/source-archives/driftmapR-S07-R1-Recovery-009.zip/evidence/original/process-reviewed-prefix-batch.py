import json,pathlib,subprocess,sys
BASE=pathlib.Path('/workspace/scratch/1e9a01af2c37/recovery-009/original')
p=pathlib.Path(sys.argv[1]);d=json.loads(p.read_text());s=d.get('structuredContent',d)
assert not s.get('unavailable_items')
plan=json.loads(pathlib.Path('/workspace/scratch/1e9a01af2c37/recovery-008/immutable-restore-dependencies.json').read_text())
archives=[x for x in plan['archives'] if x['kind']=='original']
for t in s['transfers']:
 i=next(i for i,a in enumerate(archives) if a['library_file_id']==t['library_file_id'])
 subprocess.run(['python3',str(BASE/'prove-reviewed-prefixes.py'),str(i+1),str(p)],check=True)
