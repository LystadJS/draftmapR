import hashlib,json,os,pathlib,subprocess,sys,time,tarfile,shutil
BASE=pathlib.Path('/workspace/scratch/1e9a01af2c37/recovery-009/original')
TARGET=pathlib.Path('/workspace/scratch/837e4400dd1d/study07-results/S07-D1')
HELPER='/root/.codex/plugins/cache/openai-curated-remote/openai-library/0.1.57/skills/library/scripts/library_file_transfer.py'
plan=json.loads(pathlib.Path('/workspace/scratch/1e9a01af2c37/recovery-008/immutable-restore-dependencies.json').read_text())
archives=[x for x in plan['archives'] if x['kind']=='original']
def digest(p,alg='sha256'):
 h=hashlib.new(alg)
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
d=json.loads(pathlib.Path(sys.argv[1]).read_text());s=d.get('structuredContent',d)
if 'result' in s:s=s['result']
assert not s.get('unavailable_items')
for t in s['transfers']:
 assert t.get('workspace_path'),'Requires root placed archive'
 i=next(i for i,a in enumerate(archives) if a['library_file_id']==t['library_file_id']);a=archives[i]
 assert t['file_name']==a['filename'] and t['current_version_number']==a['version'] and t['size_bytes']==a['bytes']
 p=pathlib.Path(t['workspace_path'])
 assert p.parent==BASE.parent/'original-downloads','unexpected transport directory'
 record=BASE/f'archive-{i+1:03d}-retirement.json'
 assert not record.exists(),'previous retirement found; inspect instead of repeat'
 with tarfile.open(p,'r:gz') as tf:
  required=sum(m.size for m in tf if m.isfile())
 assert shutil.disk_usage(BASE).free-required >= 2*1024**3,'Capacity floor would be crossed; archive retained, no extraction attempted'
 rr=subprocess.run(['python3',HELPER,'apply-xattrs',str(p),t['library_file_id']],input=json.dumps(t.get('xattrs',[])),text=True,capture_output=True)
 (BASE/f'archive-{i+1:03d}-metadata.log').write_text(rr.stdout+rr.stderr)
 assert rr.returncode==0,rr.stderr
 subprocess.run(['python3',str(BASE/'restore-archive.py'),str(i),str(p)],check=True)
 r=json.loads((BASE/f'archive-{i+1:03d}-restored.json').read_text())
 for m in r['members']:
  q=TARGET/m['path'];assert q.stat().st_size==m['bytes'] and digest(q,'md5')==m['md5']
 assert p.stat().st_size==a['bytes'] and digest(p)==a['sha256']
 # Capture authenticated exact compressed prefixes while the full saved
 # archive remains available, to prove any transport residues without
 # downloading it again. No scientific payload is retired here.
 prefix_record=BASE/f'archive-{i+1:03d}-compressed-prefixes.json'
 assert not prefix_record.exists(),'prefix evidence already exists; inspect'
 h=hashlib.sha256();n=0;prefixes={}
 with p.open('rb') as f:
  while block:=f.read(65536):
   h.update(block);n+=len(block);prefixes[str(n)]=h.hexdigest()
 assert n==a['bytes'] and h.hexdigest()==a['sha256']
 prefix_record.write_text(json.dumps({'archive':a,'interval_bytes':65536,'prefix_sha256':prefixes},indent=2)+'\n')
 candidates=[q for q in p.parent.iterdir() if q.is_file() and q!=p and (q.name.startswith(a['filename']+'.') or q.name.startswith('.'+a['filename']+'.')) and q.stat().st_size]
 proofs=[]
 for q in candidates:
  before=q.stat();size=before.st_size
  assert size<a['bytes'],('unrecognized full or oversized transport residue',str(q))
  got=digest(q)
  expected=prefixes.get(str(size))
  if expected is None:
   hh=hashlib.sha256();remaining=size
   with p.open('rb') as f:
    while remaining:
     block=f.read(min(1024*1024,remaining));assert block;hh.update(block);remaining-=len(block)
   expected=hh.hexdigest()
  assert got==expected,('transport residue is not exact saved archive prefix',str(q))
  after=q.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'transport residue changed during proof'
  proofs.append({'path':str(q),'bytes':size,'sha256':got,'proof':'EXACT_PREFIX_OF_SHA256_VERIFIED_SAVED_ARCHIVE'})
 proof_record=BASE/f'archive-{i+1:03d}-partial-retirement.json'
 assert not proof_record.exists()
 evidence={'status':'PROVEN_PREFIX_RETIREMENT_INTENT','archive':a,'proofs':proofs,'members_reverified':len(r['members']),'time':time.time()}
 proof_record.write_text(json.dumps(evidence,indent=2)+'\n')
 for proof in proofs:
  q=pathlib.Path(proof['path']);assert q.stat().st_size==proof['bytes'] and digest(q)==proof['sha256']
  with q.open('r+b') as f:f.truncate(0);f.flush();os.fsync(f.fileno())
  assert q.stat().st_size==0
 evidence.update(status='PROVEN_PREFIXES_RETIRED',completed=time.time())
 proof_record.write_text(json.dumps(evidence,indent=2)+'\n')
 event={'archive':a,'path':str(p),'status':'VERIFIED_DUPLICATE_RETIREMENT_INTENT','member_count':len(r['members']),'time':time.time(),'method':'truncate exact durable transport copy; preserve empty retired placeholder'}
 record.write_text(json.dumps(event,indent=2)+'\n')
 with p.open('r+b') as f:f.truncate(0);f.flush();os.fsync(f.fileno())
 assert p.stat().st_size==0
 event.update(status='VERIFIED_DUPLICATE_RETIRED',completed=time.time())
 record.write_text(json.dumps(event,indent=2)+'\n')
 print(json.dumps({'archive_index':i+1,'status':'RESTORED_VERIFIED_TRANSPORT_RETIRED','members':len(r['members'])}),flush=True)
