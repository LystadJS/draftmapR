import hashlib,json,os,pathlib,subprocess,sys,time,shutil
BASE=pathlib.Path('/workspace/scratch/1e9a01af2c37/recovery-009/original')
ROOT=pathlib.Path('/workspace/scratch/837e4400dd1d/study07-results/S07-D1')
HELPER='/root/.codex/plugins/cache/openai-curated-remote/openai-library/0.1.57/skills/library/scripts/library_file_transfer.py'
index=int(sys.argv[1]);source=pathlib.Path(sys.argv[2])
receipt=json.loads((BASE/f'archive-{index:03d}-restored.json').read_text());a=receipt['archive']
d=json.loads(source.read_text());s=d.get('structuredContent',d)
assert not s.get('unavailable_items')
matches=[x for x in s['transfers'] if x['library_file_id']==a['library_file_id']]
assert len(matches)==1
t=matches[0]
assert t['workspace_path'] and t['file_name']==a['filename'] and t['library_file_id']==a['library_file_id'] and t['current_version_number']==a['version'] and t['size_bytes']==a['bytes']
p=pathlib.Path(t['workspace_path']);assert p.parent==BASE.parent/'original-prefix-proof-downloads'
record=BASE/f'archive-{index:03d}-reviewed-prefix-retirement.json';assert not record.exists(),'Existing retirement must be reviewed, no retry'
prefix_path=BASE/f'archive-{index:03d}-compressed-prefixes.json';assert not prefix_path.exists(),'Existing prefixes must be reused/reviewed, no overwrite'
def digest(p,alg='sha256'):
 h=hashlib.new(alg)
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
r=subprocess.run(['python3',HELPER,'apply-xattrs',str(p),t['library_file_id']],input=json.dumps(t.get('xattrs',[])),capture_output=True,text=True)
(BASE/f'archive-{index:03d}-reviewed-prefix-metadata.log').write_text(r.stdout+r.stderr)
assert r.returncode==0,r.stderr
assert p.stat().st_size==a['bytes'] and digest(p)==a['sha256']
assert receipt['status']=='PASS'
for member in receipt['members']:
 q=ROOT/member['path'];assert q.stat().st_size==member['bytes'] and digest(q,'md5')==member['md5']
h=hashlib.sha256();n=0;prefixes={}
with p.open('rb') as f:
 while b:=f.read(65536):h.update(b);n+=len(b);prefixes[str(n)]=h.hexdigest()
assert n==a['bytes'] and h.hexdigest()==a['sha256']
prefix_path.write_text(json.dumps({'archive':a,'interval_bytes':65536,'prefix_sha256':prefixes},indent=2)+'\n')
proofs=[]
for directory in [BASE.parent/'original-downloads',p.parent]:
 for q in directory.iterdir():
  if not q.is_file() or q==p or not (q.name.startswith(a['filename']+'.') or q.name.startswith('.'+a['filename']+'.')) or not q.stat().st_size:continue
  before=q.stat();size=before.st_size;assert size<a['bytes'],('not a partial',str(q))
  got=digest(q);expected=prefixes.get(str(size))
  if expected is None:
   hh=hashlib.sha256();remaining=size
   with p.open('rb') as f:
    while remaining:
     b=f.read(min(1048576,remaining));assert b;hh.update(b);remaining-=len(b)
   expected=hh.hexdigest()
  assert got==expected,('not exact compressed archive prefix',str(q))
  after=q.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'partial changed during proof'
  proofs.append({'path':str(q),'bytes':size,'sha256':got,'proof':'EXACT_PREFIX_OF_SHA256_VERIFIED_SAVED_ARCHIVE'})
assert proofs,'No partials proved; do not retire proof archive silently'
event={'status':'VERIFIED_PREFIX_RETIREMENT_INTENT','archive':a,'proof_archive_path':str(p),'proofs':proofs,'installed_members_reverified':len(receipt['members']),'review':'Root explicitly reviewed capacity recovery using new materialization; retire only exact proven redundant compressed prefixes and verified full transport copy.','time':time.time()}
record.write_text(json.dumps(event,indent=2)+'\n')
for proof in proofs+[{'path':str(p),'bytes':a['bytes'],'sha256':a['sha256']}]:
 q=pathlib.Path(proof['path']);assert q.stat().st_size==proof['bytes'] and digest(q)==proof['sha256']
 with q.open('r+b') as f:f.truncate(0);f.flush();os.fsync(f.fileno())
 assert q.stat().st_size==0
event.update(status='VERIFIED_PREFIXES_AND_PROOF_ARCHIVE_RETIRED',partial_bytes_retired=sum(x['bytes'] for x in proofs),proof_archive_bytes_retired=a['bytes'],completed=time.time(),free_bytes=shutil.disk_usage(BASE).free)
record.write_text(json.dumps(event,indent=2)+'\n')
print(json.dumps({k:v for k,v in event.items() if k not in ('proofs','archive','review')}))
