import csv,hashlib,json,os,pathlib,sys,tarfile,time
BASE=pathlib.Path('/workspace/scratch/1e9a01af2c37/recovery-009/original')
ROOT=pathlib.Path('/workspace/scratch/837e4400dd1d')
TARGET=ROOT/'study07-results/S07-D1'
CAT=ROOT/'study07-recovery/evidence/original-checkpoint-catalog.csv'
PREFIX='study07-results/S07-D1/'
CAT_SHA='64e7b5d059ef95141e1784c39038b46540f59d7c647a3308dc8c10bf3c70960f'
def digest(p,algorithm='sha256'):
 h=hashlib.new(algorithm)
 with open(p,'rb') as f:
  while b:=f.read(1024*1024): h.update(b)
 return h.hexdigest()
assert digest(CAT)==CAT_SHA,'catalog hash mismatch'
catalog={r['path']:r for r in csv.DictReader(CAT.open())}
assert len(catalog)==25939
plan=json.loads(pathlib.Path('/workspace/scratch/1e9a01af2c37/recovery-008/immutable-restore-dependencies.json').read_text())
archives=[x for x in plan['archives'] if x['kind']=='original']
BASE.mkdir(parents=True,exist_ok=True)
if sys.argv[1]=='audit':
 errors=[]; total=0
 for rel,r in catalog.items():
  p=TARGET/rel
  if not p.is_file(): errors.append({'path':rel,'error':'missing'}); continue
  if p.stat().st_size!=int(r['bytes']) or digest(p,'md5')!=r['md5']: errors.append({'path':rel,'error':'identity'})
  total+=p.stat().st_size
 actual_controlled={str(p.relative_to(TARGET)) for d in ('draw-plans','checkpoints','population') for p in (TARGET/d).rglob('*') if p.is_file()}
 expected_controlled={rel for rel in catalog if '/' in rel}
 for rel in sorted(actual_controlled-expected_controlled):errors.append({'path':rel,'error':'extra controlled file'})
 archive_seen=set();coverage=set();covered_bytes=0
 for i,a in enumerate(archives):
  rp=BASE/f'archive-{i+1:03d}-restored.json'
  if not rp.is_file():errors.append({'archive':i+1,'error':'missing archive receipt'});continue
  r=json.loads(rp.read_text())
  if r['archive']!=a or r['status']!='PASS':errors.append({'archive':i+1,'error':'archive receipt identity'})
  archive_seen.add(i)
  for m in r['members']:
   if m['path'] in coverage:errors.append({'path':m['path'],'error':'duplicate archive coverage'})
   coverage.add(m['path']);covered_bytes+=m['bytes']
 for rel in sorted(set(catalog)-coverage):errors.append({'path':rel,'error':'not in restored archives'})
 out={'status':'PASS' if not errors else 'FAIL','catalog_sha256':CAT_SHA,'expected_files':len(catalog),'expected_bytes':sum(int(r['bytes']) for r in catalog.values()),'actual_bytes':total,'archive_count':len(archive_seen),'archive_coverage_files':len(coverage),'archive_coverage_bytes':covered_bytes,'errors':errors,'time':time.time()}
 (BASE/'catalog-audit.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k!='errors'})); assert not errors
 sys.exit(0)
i=int(sys.argv[1]); path=pathlib.Path(sys.argv[2]); a=archives[i]
receipt=BASE/f'archive-{i+1:03d}-restored.json'
assert not receipt.exists(),'Already recorded; review existing receipt instead'
assert path.stat().st_size==a['bytes'],'archive size mismatch'
assert digest(path)==a['sha256'],'archive SHA256 mismatch'
out={'archive':a,'local_path':str(path),'time':time.time(),'members':[],'restored':0,'identical_existing':0}
seen=set()
with tarfile.open(path,'r:gz') as t:
 for m in t:
  assert m.isfile() and m.name.startswith(PREFIX),('unsafe archive member',m.name)
  rel=m.name[len(PREFIX):]; pp=pathlib.PurePosixPath(rel)
  assert not pp.is_absolute() and '..' not in pp.parts and rel in catalog and rel not in seen,('unexpected member',rel)
  seen.add(rel); r=catalog[rel]
  assert m.size==int(r['bytes']),('member size',rel)
  p=TARGET/rel
  assert p.resolve().is_relative_to(TARGET.resolve()),('unsafe destination',rel)
  f=t.extractfile(m); h=hashlib.md5()
  if p.exists():
   assert p.is_file() and p.stat().st_size==m.size and digest(p,'md5')==r['md5'],('existing conflict',rel)
   while b:=f.read(1024*1024): h.update(b)
   assert h.hexdigest()==r['md5'],('tar content mismatch',rel)
   out['identical_existing']+=1
  else:
   p.parent.mkdir(parents=True,exist_ok=True); temp=p.with_name(p.name+'.restore009-original')
   with temp.open('xb') as dst:
    while b:=f.read(1024*1024): dst.write(b); h.update(b)
    dst.flush(); os.fsync(dst.fileno())
   assert h.hexdigest()==r['md5'],('tar content mismatch',rel)
   assert digest(temp,'md5')==r['md5'] and temp.stat().st_size==m.size
   assert not p.exists(),'destination appeared during restore'
   os.link(temp,p); temp.unlink(); out['restored']+=1
  out['members'].append({'path':rel,'md5':r['md5'],'bytes':m.size})
assert seen,'empty archive'
out.update(status='PASS',verified_files=len(seen),verified_bytes=sum(x['bytes'] for x in out['members']))
receipt.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('members','archive')}))
