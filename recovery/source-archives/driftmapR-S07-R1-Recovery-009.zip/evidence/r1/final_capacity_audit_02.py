#!/usr/bin/env python3
"""Review late R1 transport residues using existing exact-byte proofs only."""
import hashlib,json,os,pathlib,shutil,time
from restore_archives import E,digest
assert not (E/'final-capacity-review-02.json').exists()
plan=json.loads((E/'plan.json').read_text());byname={a['filename']:a for a in plan}
assert json.loads((E/'final-catalog-audit.json').read_text())['status']=='PASS'
known={}
for f in sorted(E.glob('exact-prefix-proof-*.json')):
    proof=json.loads(f.read_text())
    for r in proof['archives']:
        a=r['archive'];assert a==byname[a['filename']] and r['reference_archive_sha256_verified']
        known[(a['filename'],a['bytes'],a['sha256'])]={'type':'verified_whole_archive','proof':str(f),'proof_sha256':digest(f)}
        for p in r['proofs']:
            if p['status']=='EXACT_COMPRESSED_PREFIX':known[(a['filename'],p['bytes'],p['sha256'])]={'type':'previous_exact_prefix_comparison','proof':str(f),'proof_sha256':digest(f)}
        if r.get('compressed_prefix_catalog'):
            c=pathlib.Path(r['compressed_prefix_catalog']);assert digest(c)==r['compressed_prefix_catalog_sha256'];pc=json.loads(c.read_text());assert pc['source_archive']==a
            catalog_digest=digest(c)
            for item in pc['prefixes']:known[(a['filename'],item['bytes'],item['sha256'])]={'type':'whole_archive_bound_prefix_catalog','proof':str(c),'proof_sha256':catalog_digest}
observed=[];eligible=[]
for dirname in ('r1-downloads','r1-prefix-proof-downloads'):
    for p in sorted((E.parent/dirname).iterdir()):
        assert p.is_file() and not p.is_symlink()
        size=p.stat().st_size
        if not size:continue
        sha=digest(p);a=[a for a in plan if a['filename']in p.name];assert len(a)==1
        match=known.get((a[0]['filename'],size,sha))
        r={'path':str(p),'bytes':size,'sha256':sha,'archive':a[0],'proof':match,'decision':'RETIRE_EXACT_DURABLE_TRANSPORT_DUPLICATE'if match else'RETAIN_UNPROVEN_COMPRESSED_PREFIX'}
        observed.append(r)
        if match:eligible.append(r)
review={'time':time.time(),'observations':observed,'eligible_files':len(eligible),'eligible_bytes':sum(r['bytes']for r in eligible),'review_basis':'Root authorizes late retirement only when exact checksum matches a prior full-archive-bound prefix proof; unmatched residues retained','science_member_audit_sha256':digest(E/'final-catalog-audit.json')}
(E/'final-capacity-review-02.json').write_text(json.dumps(review,indent=2))
for r in eligible:
    p=pathlib.Path(r['path']);assert p.stat().st_size==r['bytes'] and digest(p)==r['sha256']
    with p.open('r+b')as f:f.truncate(0);f.flush();os.fsync(f.fileno())
    assert p.stat().st_size==0
    with (E/'final-capacity-retirement-commits-02.jsonl').open('a')as f:f.write(json.dumps({'path':str(p),'bytes_before':r['bytes'],'sha256_before':r['sha256'],'bytes_after':0,'time':time.time()})+'\n');f.flush();os.fsync(f.fileno())
remaining=[r for r in observed if r not in eligible]
old_retired=[]
for f in E.glob('exact-prefix-*-retirement-intent.json'):old_retired.extend(json.loads(f.read_text())['files'])
result={'status':'PASS','time':time.time(),'late_duplicates_retired':len(eligible),'late_duplicate_bytes_retired':sum(r['bytes']for r in eligible),'retained_unproven_partial_files':len(remaining),'retained_unproven_partial_bytes':sum(r['bytes']for r in remaining),'retained_paths':[r['path']for r in remaining],'all_prior_retired_paths_still_zero':all(pathlib.Path(r['path']).stat().st_size==0 for r in old_retired),'all_new_retired_paths_zero':all(pathlib.Path(r['path']).stat().st_size==0 for r in eligible),'science_files_mutated':0,'all_library_calls_and_local_restoration_tasks_finished':True,'disk_free':shutil.disk_usage(E).free}
(E/'final-capacity-complete-02.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
