#!/usr/bin/env python3
"""Read-only exact compressed-prefix proofs against freshly verified archives."""
import hashlib,json,pathlib,subprocess,sys,time
from restore_archives import E,CURRENT,HELPER,digest
prepare=pathlib.Path(sys.argv[1]);outpath=pathlib.Path(sys.argv[2]);assert not outpath.exists()
obj=json.loads(prepare.read_text());s=obj.get('structuredContent',obj);s=s.get('result',s);assert not s.get('unavailable_items')
plan={r['filename']:r for r in json.loads((E/'plan.json').read_text())}
assert json.loads((E/'final-catalog-audit.json').read_text())['status']=='PASS'
results=[]
for t in s['transfers']:
    assert t.get('workspace_path'),'Requires root workspace placement'
    reference=pathlib.Path(t['workspace_path']);a=plan[t['file_name']]
    assert reference.is_relative_to(CURRENT/'recovery-009') and reference.name==a['filename']
    assert t['library_file_id']==a['library_file_id'] and t['current_version_number']==a['version']
    cp=subprocess.run(['python3',HELPER,'apply-xattrs',str(reference),a['library_file_id']],input=json.dumps(t.get('xattrs')or[]),text=True,capture_output=True);assert cp.returncode==0,cp.stderr
    assert reference.stat().st_size==a['bytes'] and digest(reference)==a['sha256'],'Reference archive identity mismatch'
    refstat=reference.stat();proofs=[]
    prefix_dir=E/'compressed-prefix-catalogs';prefix_dir.mkdir(exist_ok=True)
    prefix_path=prefix_dir/(a['filename']+'.prefixes.json')
    assert not prefix_path.exists(),'Prefix catalog already exists; inspect before repeat'
    h=hashlib.sha256();position=0;prefixes=[]
    with reference.open('rb')as f:
        for chunk in iter(lambda:f.read(65536),b''):
            h.update(chunk);position+=len(chunk);prefixes.append({'bytes':position,'sha256':h.hexdigest()})
    assert position==a['bytes'] and h.hexdigest()==a['sha256']
    prefix_path.write_text(json.dumps({'source_archive':a,'step_bytes':65536,'prefixes':prefixes},indent=2))
    candidates=set((E.parent/'r1-downloads').iterdir())|set(reference.parent.iterdir())
    for p in sorted(candidates):
        if p==reference or a['filename']not in p.name or p.stat().st_size==0:continue
        before=p.stat();assert p.is_file() and not p.is_symlink()
        if before.st_size>a['bytes']:
            proofs.append({'path':str(p),'status':'UNPROVEN_RETAIN','reason':'larger_than_reference','bytes':before.st_size});continue
        h=hashlib.sha256();equal=True;count=0
        with p.open('rb')as pf,reference.open('rb')as rf:
            while True:
                b=pf.read(4194304)
                if not b:break
                if rf.read(len(b))!=b:equal=False
                h.update(b);count+=len(b)
        after=p.stat();assert before.st_size==after.st_size==count and before.st_mtime_ns==after.st_mtime_ns,'Partial changed while checking'
        proofs.append({'path':str(p),'status':'EXACT_COMPRESSED_PREFIX' if equal else'UNPROVEN_RETAIN','bytes':count,'sha256':h.hexdigest(),'reference_offset':0,'reference_length':count,'full_copy':count==a['bytes']})
    assert reference.stat().st_size==refstat.st_size and reference.stat().st_mtime_ns==refstat.st_mtime_ns
    results.append({'archive':a,'reference_path':str(reference),'reference_archive_sha256_verified':True,'member_audit_sha256':digest(E/'final-catalog-audit.json'),'compressed_prefix_catalog':str(prefix_path),'compressed_prefix_catalog_sha256':digest(prefix_path),'proofs':proofs})
out={'status':'PROOFS_COMPLETE_READ_ONLY','time':time.time(),'prepare_receipt_sha256':digest(prepare),'archives':results,'proved_partials':sum(p['status']=='EXACT_COMPRESSED_PREFIX'for r in results for p in r['proofs']),'proved_partial_bytes':sum(p['bytes']for r in results for p in r['proofs']if p['status']=='EXACT_COMPRESSED_PREFIX'),'mutations_to_transport_or_science':False}
outpath.write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k!='archives'}),flush=True)
