#!/usr/bin/env python3
"""Read-only proof of every decompressed scientific byte in gzip prefixes."""
import base64,hashlib,json,math,pathlib,tarfile,time,zlib
from restore_archives import E,DEST,PREFIX,catalog,digest
OUT=E/'partial-prefix-proofs'
OUT.mkdir(exist_ok=False)
inventory=json.loads((E/'capacity-retirement-inventory-02.json').read_text())
plan=json.loads((E/'plan.json').read_text())
assert json.loads((E/'final-catalog-audit.json').read_text())['status']=='PASS'
class PrefixProof:
    def __init__(self,members):
        self.members=members;self.index=0;self.state='header';self.buf=b'';self.left=0
        self.pending_pax={};self.paxbuf=b'';self.pax_records=[];self.header_records=[]
        self.payloads=[];self.uncompressed=0;self.metadata_bytes=0;self.padding_bytes=0;self.payload_bytes=0
        self.rawfh=None;self.eof_blocks=0;self.current=None;self.uncompressed_sha=hashlib.sha256()
    def consume(self,data):
        self.uncompressed+=len(data);self.uncompressed_sha.update(data);self.buf+=data
        while self.buf:
            if self.state=='header':
                if len(self.buf)<512:return
                header,self.buf=self.buf[:512],self.buf[512:]
                self.metadata_bytes+=512
                if header==bytes(512):
                    assert self.index==len(self.members) and not self.pending_pax,'Early tar EOF'
                    self.eof_blocks+=1;continue
                assert self.eof_blocks==0,'Nonzero header after tar EOF'
                info=tarfile.TarInfo.frombuf(header,'utf-8','surrogateescape')
                assert info.type in (tarfile.REGTYPE,tarfile.AREGTYPE,tarfile.XHDTYPE),'Unexpected tar entry type'
                assert not info.linkname and info.size>=0 and info.uid>=0 and info.gid>=0 and info.mode>=0,'Invalid tar fields'
                record={'offset':self.uncompressed-len(self.buf)-512,'type':info.type.decode('ascii'),'name':info.name,'size':info.size,'header_base64':base64.b64encode(header).decode()}
                self.header_records.append(record)
                if info.type==tarfile.XHDTYPE:
                    assert not self.pending_pax and info.size<=65536,'Unexpected repeated/large PAX metadata'
                    self.current=info;self.paxbuf=b'';self.left=info.size;self.state='pax'
                else:
                    assert self.index<len(self.members),'Extra member'
                    member=self.members[self.index];expected=PREFIX+member['path']
                    name=self.pending_pax.get('path',info.name)
                    size=int(self.pending_pax.get('size',info.size))
                    assert name==expected and size==int(member['bytes']),f'Ordered member mismatch: {name}'
                    assert info.name==expected or ('path'in self.pending_pax and expected.startswith(info.name)),'Header name does not match PAX path'
                    assert size==int(catalog[member['path']]['bytes'])
                    assert not self.pending_pax.keys()-{'path','mtime','atime','ctime','size'},'Unknown PAX semantics'
                    self.pending_pax={};self.current=member;self.left=size;self.state='payload'
                    target=DEST/member['path'];assert target.is_file() and not target.is_symlink()
                    assert target.stat().st_size==size
                    self.rawfh=target.open('rb');self.md5=hashlib.md5();self.sha=hashlib.sha256();self.current_seen=0
                    if size==0:self.finish_payload()
            elif self.state=='pax':
                n=min(len(self.buf),self.left);self.paxbuf+=self.buf[:n];self.buf=self.buf[n:];self.left-=n;self.metadata_bytes+=n
                if self.left:return
                offset=0;pax={}
                while offset<len(self.paxbuf):
                    space=self.paxbuf.index(b' ',offset);length=int(self.paxbuf[offset:space]);assert length>0
                    line=self.paxbuf[space+1:offset+length];assert len(line)==length-(space+1-offset) and line.endswith(b'\n')
                    key,value=line[:-1].split(b'=',1);key=key.decode('utf-8');value=value.decode('utf-8')
                    assert key not in pax and key in {'path','mtime','atime','ctime','size'},'Unexpected PAX key'
                    if key in {'mtime','atime','ctime'}:assert math.isfinite(float(value))
                    if key=='size':assert value.isdecimal()
                    pax[key]=value;offset+=length
                assert offset==len(self.paxbuf)
                self.pending_pax=pax;self.pax_records.append({'data_base64':base64.b64encode(self.paxbuf).decode(),'fields':pax})
                self.left=(-self.current.size)%512;self.state='padding'
                if not self.left:self.state='header'
            elif self.state=='payload':
                n=min(len(self.buf),self.left);part=self.buf[:n];self.buf=self.buf[n:]
                assert self.rawfh.read(n)==part,f'Payload byte mismatch: {self.current["path"]}'
                self.md5.update(part);self.sha.update(part);self.current_seen+=n;self.payload_bytes+=n;self.left-=n
                if not self.left:self.finish_payload()
            elif self.state=='padding':
                n=min(len(self.buf),self.left);assert self.buf[:n]==bytes(n),'Nonzero tar padding'
                self.buf=self.buf[n:];self.padding_bytes+=n;self.left-=n
                if not self.left:self.state='header'
    def finish_payload(self):
        assert self.md5.hexdigest()==self.current['md5']==catalog[self.current['path']]['md5'],'Full member MD5 mismatch'
        assert self.sha.hexdigest()==self.current['sha256'],'Full member SHA256 mismatch'
        self.rawfh.close();self.rawfh=None
        self.payloads.append({'path':self.current['path'],'complete':True,'bytes_compared':self.current_seen,'md5':self.md5.hexdigest(),'sha256':self.sha.hexdigest()})
        self.index+=1;self.left=(-int(self.current['bytes']))%512;self.state='padding' if self.left else 'header'
    def finish(self):
        if self.state=='payload':
            self.rawfh.close();self.rawfh=None
            self.payloads.append({'path':self.current['path'],'complete':False,'bytes_compared':self.current_seen,'expected_member_bytes':int(self.current['bytes']),'available_prefix_sha256':self.sha.hexdigest()})
        elif self.state=='header' and self.buf:
            raise AssertionError('Unverifiable incomplete tar header; preserve residue')
        elif self.state=='pax':
            raise AssertionError('Unverifiable incomplete PAX metadata; preserve residue')
        assert not self.buf,'Unconsumed decompressed bytes'
        assert self.uncompressed==self.metadata_bytes+self.padding_bytes+self.payload_bytes,'Byte accounting mismatch'
        return {'uncompressed_bytes':self.uncompressed,'uncompressed_sha256':self.uncompressed_sha.hexdigest(),'header_and_pax_bytes':self.metadata_bytes,'zero_padding_bytes':self.padding_bytes,'scientific_payload_bytes_compared':self.payload_bytes,'complete_members':self.index,'end_state':self.state,'gzip_prefix_ends_inside_member':self.state=='payload','headers':self.header_records,'pax_metadata':self.pax_records,'payloads':self.payloads,'tar_eof_blocks':self.eof_blocks}
results=[]
for i,residue in enumerate(inventory['files'],1):
    file=pathlib.Path(residue['path']);matches=[r for r in plan if r['filename']in file.name];assert len(matches)==1
    archive=matches[0];receipt=E/(archive['filename']+'.restored.json');restored=json.loads(receipt.read_text());assert restored['status']=='PASS'
    proof=PrefixProof(restored['members']);out={'path':str(file),'source_archive':archive,'source_restoration_receipt_sha256':digest(receipt),'time_started':time.time(),'mutations_performed':False}
    try:
        before=file.stat();compressed_hash=hashlib.sha256();compressed_count=0;decomp=zlib.decompressobj(31)
        with file.open('rb')as f:
            while True:
                chunk=f.read(1024*1024)
                if not chunk:break
                compressed_hash.update(chunk);compressed_count+=len(chunk);pending=chunk
                while pending:
                    data=decomp.decompress(pending,8*1024*1024);pending=decomp.unconsumed_tail;proof.consume(data)
                    assert not decomp.unused_data,'Trailing compressed garbage/concatenated stream'
        proof.consume(decomp.flush())
        after=file.stat();assert before.st_size==after.st_size==compressed_count and before.st_mtime_ns==after.st_mtime_ns,'Residue changed during verification'
        assert compressed_hash.hexdigest()==residue['sha256'] and compressed_count==residue['bytes'],'Residue identity changed'
        out.update(proof.finish());out.update({'status':'PASS_SCIENTIFIC_PREFIX_MATCH','time_completed':time.time(),'compressed_bytes':compressed_count,'compressed_sha256':compressed_hash.hexdigest(),'gzip_complete_crc_verified':decomp.eof,'incomplete_gzip_no_crc_claim':not decomp.eof,'every_available_decompressed_byte_accounted_for':True,'contains_no_unique_decompressed_scientific_payload':True,'compressed_prefix_identity_to_saved_archive':'NOT_ESTABLISHED; whole archive SHA was verified before restoration but no saved compressed-prefix hash exists','limitation':'Incomplete gzip can end inside a code; no claim about unfinished compressed bits or missing suffix. Exact observed metadata headers and PAX payload bytes retained.'})
    except Exception as exc:
        if proof.rawfh:proof.rawfh.close()
        out.update({'status':'UNPROVEN_RETAIN','error':type(exc).__name__+': '+str(exc),'time_completed':time.time()})
    (OUT/f'prefix-{i:03d}.json').write_text(json.dumps(out,indent=2))
    results.append({k:v for k,v in out.items()if k not in {'headers','pax_metadata','payloads'}})
    print(json.dumps({'index':i,'file':file.name,'status':out['status'],'compressed_bytes':out.get('compressed_bytes'),'scientific_bytes':out.get('scientific_payload_bytes_compared'),'error':out.get('error')}),flush=True)
summary={'time':time.time(),'status':'ALL_PREFIXES_MATCH' if all(r['status']=='PASS_SCIENTIFIC_PREFIX_MATCH' for r in results)else'PARTIAL_OR_UNPROVEN','files':len(results),'passed':sum(r['status']=='PASS_SCIENTIFIC_PREFIX_MATCH'for r in results),'passed_compressed_bytes':sum(r.get('compressed_bytes',0)for r in results if r['status']=='PASS_SCIENTIFIC_PREFIX_MATCH'),'results':results,'mutations_performed':False}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items()if k!='results'}),flush=True)
