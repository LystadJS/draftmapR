#!/usr/bin/env python3
"""Restore exact R1 immutable archive members; no science generation or retries."""
import csv, hashlib, json, os, pathlib, shutil, subprocess, sys, tarfile, time
ROOT=pathlib.Path('/workspace/scratch/837e4400dd1d')
CURRENT=pathlib.Path('/workspace/scratch/1e9a01af2c37')
E=CURRENT/'recovery-009/r1'
DEST=ROOT/'study07-results/S07-R1'
CATALOG=ROOT/'study07-r1-checkpoints/checkpoint-03/checkpoint-03-cumulative-immutable-catalog.csv'
CATALOG_SHA='9ad0c789ab581bb0acf009c7a5a1226b27d2f5ee274563397b22a987cad88fd8'
HELPER='/root/.codex/plugins/cache/openai-curated-remote/openai-library/0.1.57/skills/library/scripts/library_file_transfer.py'
PREFIX='study07-results/S07-R1/'
def digest(p, algorithm='sha256'):
    h=hashlib.new(algorithm)
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()
assert digest(CATALOG)==CATALOG_SHA
rows=list(csv.DictReader(CATALOG.open()))
catalog={r['path']:r for r in rows}
assert len(rows)==len(catalog)==25944
plan={r['filename']:r for r in json.loads((E/'plan.json').read_text())}
def verify(p,r):
    assert p.is_file() and not p.is_symlink(), str(p)
    assert p.stat().st_size==int(r['bytes']), f'size mismatch: {p}'
    assert digest(p,'md5')==r['md5'], f'MD5 mismatch: {p}'
def audit():
    good=[];missing=[];bad=[]
    for r in rows:
        p=DEST/r['path']
        if not p.exists(): missing.append(r['path']);continue
        try: verify(p,r);good.append(r)
        except Exception as exc: bad.append({'path':r['path'],'error':str(exc)})
    out={'status':'PASS' if not missing and not bad else 'INCOMPLETE','time':time.time(),'catalog_sha256':CATALOG_SHA,'expected_files':len(rows),'expected_bytes':sum(int(r['bytes']) for r in rows),'verified_files':len(good),'verified_bytes':sum(int(r['bytes']) for r in good),'missing':missing,'mismatches':bad}
    (E/'final-catalog-audit.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({k:v for k,v in out.items() if k not in ('missing','mismatches')}),flush=True)
    return 0 if out['status']=='PASS' else 2
def restore(transfer):
    assert shutil.disk_usage(DEST).free>=2*1024**3,'Disk guard: less than 2 GiB free'
    expected=plan[transfer['file_name']]
    assert transfer['library_file_id']==expected['library_file_id']
    assert transfer.get('current_version_number')==expected['version']
    assert transfer.get('workspace_path'), 'Only already placed workspace transfers accepted here'
    archive=pathlib.Path(transfer['workspace_path'])
    assert archive.is_relative_to(CURRENT/'recovery-009/r1-downloads')
    assert archive.name==expected['filename']
    receipt=E/(archive.name+'.restored.json')
    assert not receipt.exists(), 'Already processed archive; no automatic repeat'
    x=subprocess.run(['python3',HELPER,'apply-xattrs',str(archive),expected['library_file_id']],input=json.dumps(transfer.get('xattrs') or []),text=True,capture_output=True)
    (E/(archive.name+'.xattrs.json')).write_text(json.dumps({'returncode':x.returncode,'stdout':x.stdout,'stderr':x.stderr}))
    assert x.returncode==0, x.stderr
    assert archive.stat().st_size==expected['bytes'], 'Archive byte count mismatch'
    assert digest(archive)==expected['sha256'], 'Archive SHA256 mismatch'
    members=[];restored=0;existing=0;total=0;seen=set()
    with tarfile.open(archive,'r:gz') as tf:
        for m in tf:
            assert m.isfile(), f'Nonregular tar member: {m.name}'
            assert m.name.startswith(PREFIX), f'Unexpected prefix: {m.name}'
            rel=m.name[len(PREFIX):]
            assert rel in catalog and rel not in seen and '..' not in pathlib.PurePosixPath(rel).parts, f'Unexpected/duplicate path: {rel}'
            seen.add(rel);r=catalog[rel]
            assert m.size==int(r['bytes']), f'Archive member size mismatch: {rel}'
            payload=tf.extractfile(m).read()
            assert len(payload)==m.size and hashlib.md5(payload).hexdigest()==r['md5'], f'Archive member digest mismatch: {rel}'
            target=DEST/rel
            if target.exists() or target.is_symlink(): verify(target,r);existing+=1
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                assert not any(p.is_symlink() for p in target.parents if p.is_relative_to(DEST)), 'Symlink parent'
                temporary=target.with_name(target.name+'.r1009-restoring')
                with temporary.open('xb') as f: f.write(payload);f.flush();os.fsync(f.fileno())
                assert not target.exists()
                os.rename(temporary,target);restored+=1
            verify(target,r);total+=m.size
            members.append({'path':rel,'bytes':m.size,'md5':r['md5'],'sha256':hashlib.sha256(payload).hexdigest()})
    assert seen
    out={'status':'PASS','time':time.time(),'archive':expected,'local_archive':str(archive),'archive_bytes_verified':True,'archive_sha256_verified':True,'catalog_sha256':CATALOG_SHA,'members':members,'member_count':len(members),'member_bytes':total,'restored':restored,'existing_identical':existing,'transport_retirement_authorized':'Known durable Library archive and every member restored and reverified'}
    receipt.write_text(json.dumps(out,indent=2))
    assert digest(archive)==expected['sha256']
    with archive.open('r+b') as f: f.truncate(0);f.flush();os.fsync(f.fileno())
    (E/(archive.name+'.retired.json')).write_text(json.dumps({'time':time.time(),'archive':expected,'restoration_receipt_sha256':digest(receipt),'method':'reviewed_zero_byte_transport_placeholder','local_size_after_retirement':archive.stat().st_size},indent=2))
    print(json.dumps({k:v for k,v in out.items() if k!='members'}),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='audit': sys.exit(audit())
    p=pathlib.Path(sys.argv[1]);obj=json.loads(p.read_text());s=obj.get('structuredContent',obj);s=s.get('result',s)
    assert not s.get('unavailable_items'), s.get('unavailable_items')
    for transfer in s['transfers']: restore(transfer)
