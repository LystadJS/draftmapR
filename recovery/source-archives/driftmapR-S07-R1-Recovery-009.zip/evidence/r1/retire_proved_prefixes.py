#!/usr/bin/env python3
"""One reviewed retirement of exact byte ranges of durable verified archives."""
import hashlib,json,os,pathlib,shutil,sys,time
from restore_archives import E,CURRENT,DEST,catalog,digest,verify
proof_path=pathlib.Path(sys.argv[1]);tag=sys.argv[2]
intent=E/(tag+'-retirement-intent.json');assert not intent.exists()
proof=json.loads(proof_path.read_text());assert proof['status']=='PROOFS_COMPLETE_READ_ONLY'
selected=[]
for archive in proof['archives']:
    a=archive['archive'];reference=pathlib.Path(archive['reference_path'])
    assert archive['reference_archive_sha256_verified']
    assert reference.stat().st_size==a['bytes'] and digest(reference)==a['sha256']
    receipt=E/(a['filename']+'.restored.json');restored=json.loads(receipt.read_text());assert restored['status']=='PASS'
    for m in restored['members']:verify(DEST/m['path'],catalog[m['path']])
    for r in archive['proofs']:
        if r['status']!='EXACT_COMPRESSED_PREFIX':continue
        p=pathlib.Path(r['path']);assert p.is_relative_to(CURRENT/'recovery-009') and not p.is_symlink()
        assert p.stat().st_size==r['bytes'] and digest(p)==r['sha256']
        with p.open('rb')as f,reference.open('rb')as ref:
            for chunk in iter(lambda:f.read(4194304),b''):assert chunk==ref.read(len(chunk))
        selected.append({'path':str(p),'bytes':r['bytes'],'sha256':r['sha256'],'kind':'exact_compressed_prefix','source_archive':a,'source_byte_start':0,'source_byte_length':r['bytes'],'members_reverified':len(restored['members'])})
    selected.append({'path':str(reference),'bytes':a['bytes'],'sha256':a['sha256'],'kind':'full_verified_reference_archive','source_archive':a,'members_reverified':len(restored['members'])})
assert len({r['path']for r in selected})==len(selected)
intent.write_text(json.dumps({'time':time.time(),'proof_path':str(proof_path),'proof_sha256':digest(proof_path),'review':'Root explicitly authorized exact compressed-prefix and full verified reference archive zero-byte placeholders after passing installed-member audit','files':selected},indent=2))
for r in selected:
    p=pathlib.Path(r['path']);assert p.stat().st_size==r['bytes'] and digest(p)==r['sha256']
    with p.open('r+b')as f:f.truncate(0);f.flush();os.fsync(f.fileno())
    assert p.stat().st_size==0
    with (E/(tag+'-retirement-commits.jsonl')).open('a')as f:f.write(json.dumps({'time':time.time(),'path':str(p),'sha256_before':r['sha256'],'bytes_before':r['bytes'],'bytes_after':0})+'\n');f.flush();os.fsync(f.fileno())
result={'status':'PASS','time':time.time(),'files_retired':len(selected),'bytes_retired':sum(r['bytes']for r in selected),'previous_residue_bytes_retired':sum(r['bytes']for r in selected if r['kind']=='exact_compressed_prefix'),'science_files_mutated':0,'retired_paths_all_zero':all(pathlib.Path(r['path']).stat().st_size==0 for r in selected),'disk_free':shutil.disk_usage(E).free}
(E/(tag+'-retirement-complete.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
