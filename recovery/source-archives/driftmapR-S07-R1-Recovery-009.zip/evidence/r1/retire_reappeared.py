#!/usr/bin/env python3
"""One reviewed retirement of verified, durable transport duplicates only."""
import json,os,pathlib,time
from restore_archives import E,DEST,digest,verify,catalog
inventory=json.loads((E/'reappeared-transport-inventory.json').read_text())
assert not (E/'placeholder-retirement-intent.json').exists()
selected=[r for r in inventory['files'] if r.get('matches_archive')]
proofs=[]
for r in selected:
    p=pathlib.Path(r['path']);receipt=E/(r['matches_archive']+'.restored.json');x=json.loads(receipt.read_text())
    assert x['status']=='PASS' and x['archive_sha256_verified'] and x['archive_bytes_verified']
    assert p.is_file() and not p.is_symlink()
    assert p.stat().st_size==r['bytes'] and digest(p)==r['sha256']==x['archive']['sha256']
    for m in x['members']:verify(DEST/m['path'],catalog[m['path']])
    proofs.append({'path':str(p),'bytes':r['bytes'],'sha256':r['sha256'],'archive':x['archive'],'restoration_receipt_sha256':digest(receipt),'reverified_member_count':len(x['members'])})
(E/'placeholder-retirement-intent.json').write_text(json.dumps({'time':time.time(),'method':'truncate_exact_durable_transport_duplicates_once','proofs':proofs},indent=2))
for r in proofs:
    p=pathlib.Path(r['path']);assert p.stat().st_size==r['bytes'] and digest(p)==r['sha256']
    with p.open('r+b') as f:f.truncate(0);f.flush();os.fsync(f.fileno())
    assert p.stat().st_size==0
    with (E/'placeholder-retirement-commits.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'path':str(p),'sha256_before':r['sha256'],'bytes_before':r['bytes'],'bytes_after':0})+'\n');f.flush();os.fsync(f.fileno())
result={'status':'PASS','time':time.time(),'retired_copies':len(proofs),'retired_bytes':sum(x['bytes'] for x in proofs),'remaining_unknown_partials':'retained unchanged'}
(E/'placeholder-retirement-complete.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
