#!/usr/bin/env python3
"""Consume root-prepared workspace files; never initiate a network transfer."""
from pathlib import Path
import importlib.util, json, subprocess, sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('restore_raw009', HERE / 'restore-archive.py')
restore = importlib.util.module_from_spec(spec)
spec.loader.exec_module(restore)
request = Path(sys.argv[1])
response = json.loads(request.read_text())
body = response.get('structuredContent', response)
body = body.get('result', body)
assert not response.get('isError') and not body.get('unavailable_items'), 'Materialization not wholly available'
plan, _, _ = restore.bindings()
by_id = {row['library_file_id']:(i,row) for i,row in enumerate(plan['archives'])}
helper = '/root/.codex/plugins/cache/openai-curated-remote/openai-library/0.1.57/skills/library/scripts/library_file_transfer.py'
for transfer in body['transfers']:
    index, row = by_id[transfer['library_file_id']]
    assert transfer.get('workspace_path'), 'A root-context workspace placement is required; no URL retry'
    path = Path(transfer['workspace_path'])
    assert path.is_relative_to(restore.CURRENT / 'recovery-009/raw-downloads')
    assert path.name == row['filename']
    assert transfer['file_id'] == row['file_id']
    assert transfer.get('current_version_number') == row['version']
    assert path.stat().st_size == row['bytes'] and restore.digest(path) == row['sha256']
    completed = subprocess.run([sys.executable, helper, 'apply-xattrs', str(path), transfer['library_file_id']],
                               input=json.dumps(transfer.get('xattrs') or []), text=True, capture_output=True)
    restore.save_new(HERE / f'metadata-{index:03}.json',
                     {'request':str(request), 'returncode':completed.returncode,
                      'stdout':completed.stdout, 'stderr':completed.stderr})
    assert completed.returncode == 0, 'Metadata application failed'
    restore.restore(index, path)
