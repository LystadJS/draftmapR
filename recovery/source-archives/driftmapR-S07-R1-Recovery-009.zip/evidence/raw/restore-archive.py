#!/usr/bin/env python3
"""Restore only hash-bound S07-R1 raw-prefix archive members; no science execution."""
from pathlib import Path, PurePosixPath
import csv, hashlib, json, os, shutil, sys, tarfile, time

ROOT = Path('/workspace/scratch/837e4400dd1d')
CURRENT = Path('/workspace/scratch/1e9a01af2c37')
RUN = ROOT / 'study07-results/S07-R1'
STATE = ROOT / 'study07-r1-operations/resumable-collection-state'
LIVE = CURRENT / 'recovery-004/verified-bundles/live-002'
EVIDENCE = CURRENT / 'recovery-009/raw'
PREFIX = 'csv-chunks-20260921192657143845-45-1/'

def digest(path, algorithm='sha256'):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, algorithm).hexdigest()

def save_new(path, obj):
    with path.open('x') as handle:
        json.dump(obj, handle, sort_keys=True, indent=2)
        handle.write('\n'); handle.flush(); os.fsync(handle.fileno())

def bindings():
    plan = json.loads((CURRENT / 'recovery-008/raw/missing-prefix-dependencies.json').read_text())
    journal_path = STATE / 'chunk-journal.jsonl'
    assert digest(journal_path) == plan['source_journal_sha256'], 'Raw journal changed'
    journal = {}
    with journal_path.open() as handle:
        for line in handle:
            row = json.loads(line)
            if row['serial'] <= 163092:
                assert row['chunk'] == PREFIX + f"{row['serial']:07}.csv"
                assert row['chunk'] not in journal
                journal[row['chunk']] = row
    assert len(journal) == 163092
    assert digest(LIVE / 'SNAPSHOT-MANIFEST.json') == '8faed4263b878b0c268f5118ecb962343222d21e5d3d727f76d093ba2283958c'
    manifest = json.loads((LIVE / 'SNAPSHOT-MANIFEST.json').read_text())
    return plan, journal, manifest

def restore(index, archive):
    plan, journal, manifest = bindings()
    archive = Path(archive)
    spec = plan['archives'][index]
    receipt = EVIDENCE / f'restored-{index:03}.json'
    assert not receipt.exists(), 'Receipt exists; inspect prior outcome rather than retry'
    assert archive.stat().st_size == spec['bytes']
    assert digest(archive) == spec['sha256']
    canonical = next(x for x in manifest['raw_dependencies']['archives'] if x['filename'] == spec['filename'])
    assert all(spec[k] == canonical[k] for k in ('filename', 'bytes', 'sha256', 'library_file_id', 'version', 'tag'))
    catalog_path = LIVE / 'current-workspace/final-preservation' / spec['tag'] / (spec['tag'] + '-products-catalog.csv')
    cat_binding = next(x for x in manifest['bound_catalogs'] if x['filename'] == catalog_path.name)
    assert digest(catalog_path) == cat_binding['sha256']
    catalog = {x['path']: x for x in csv.DictReader(catalog_path.open())}
    wanted = set(spec['logical_paths'])
    assert wanted <= catalog.keys() and wanted <= journal.keys()
    seen = set(); restored = []; existing = []; total_bytes = 0
    prefix = 'study07-results/S07-R1/'
    with tarfile.open(archive, 'r:gz') as handle:
        for member in handle:
            rel = PurePosixPath(member.name)
            assert not rel.is_absolute() and '..' not in rel.parts
            assert member.isfile() and member.name.startswith(prefix)
            name = member.name[len(prefix):]
            assert name not in seen and name in catalog
            seen.add(name)
            cat = catalog[name]
            assert int(cat['bytes']) == member.size
            row = journal.get(name)
            if row:
                assert name.startswith(PREFIX)
                assert int(cat['bytes']) == row['bytes'] and cat['md5'] == row['md5']
            target = RUN / name
            needed = name in wanted and not target.exists()
            if needed:
                assert not os.path.lexists(target), f'Dangling target requires review: {target}'
                assert shutil.disk_usage(RUN).free > member.size + 2 * 1024**3
                target.parent.mkdir(parents=True, exist_ok=True)
                temp = target.with_name(target.name + '.restore009')
                out = temp.open('xb')
            else:
                out = None
            md = hashlib.md5(); size = 0
            try:
                with handle.extractfile(member) as source:
                    while data := source.read(1024 * 1024):
                        md.update(data); size += len(data)
                        if out: out.write(data)
                if out: out.flush(); os.fsync(out.fileno())
            finally:
                if out: out.close()
            assert size == member.size and md.hexdigest() == cat['md5']
            total_bytes += size
            if needed:
                os.link(temp, target); temp.unlink()
                assert target.stat().st_size == size and digest(target, 'md5') == cat['md5']
                restored.append({'path': name, 'bytes': size, 'md5': cat['md5']})
            elif name in wanted:
                assert target.is_file() and target.stat().st_size == size and digest(target, 'md5') == cat['md5']
                existing.append(name)
    assert seen == catalog.keys()
    assert len(restored) + len(existing) == len(wanted)
    result = {'status':'ARCHIVE_AND_ALL_MEMBERS_VERIFIED_PREFIX_RESTORED', 'time':time.time(),
              'index':index, 'archive':str(archive), 'archive_sha256':spec['sha256'],
              'archive_bytes':spec['bytes'], 'library_file_id':spec['library_file_id'],
              'version':spec['version'], 'catalog_sha256':cat_binding['sha256'],
              'archive_members_verified':len(seen), 'archive_member_bytes':total_bytes,
              'restored_files':len(restored), 'restored_bytes':sum(x['bytes'] for x in restored),
              'existing_exact_files':len(existing), 'restored_members':restored,
              'scientific_generation':False, 'science_payloads_deleted':0}
    save_new(receipt, result)
    # These transport bytes remain safely stored under the verified durable identity.
    assert archive.is_file() and not archive.is_symlink()
    assert archive.stat().st_size == spec['bytes'] and digest(archive) == spec['sha256']
    # Preserve authenticated prefix fingerprints while the verified transport exists.
    # They can prove exact late-arriving partial copies without another download.
    h = hashlib.sha256(); length = 0; boundaries = []
    with archive.open('rb') as handle:
        while data := handle.read(65536):
            h.update(data); length += len(data)
            boundaries.append({'bytes':length, 'sha256':h.hexdigest()})
    assert length == spec['bytes'] and h.hexdigest() == spec['sha256']
    save_new(EVIDENCE / f'transport-prefix-proofs-{index:03}.json',
             {'archive':str(archive), 'library_file_id':spec['library_file_id'],
              'archive_bytes':spec['bytes'], 'archive_sha256':spec['sha256'],
              'prefix_block_bytes':65536, 'prefixes':boundaries})
    partials = []; unproved = []
    for candidate in archive.parent.iterdir():
        if candidate == archive or candidate.is_symlink() or not candidate.is_file():
            continue
        if not candidate.name.lstrip('.').startswith(archive.name + '.'):
            continue
        size = candidate.stat().st_size
        if not size:
            continue
        exact = size <= spec['bytes']; sh = hashlib.sha256()
        if exact:
            with candidate.open('rb') as part, archive.open('rb') as full:
                while data := part.read(1024 * 1024):
                    sh.update(data)
                    if data != full.read(len(data)):
                        exact = False; break
        record = {'path':str(candidate), 'bytes':size, 'exact_prefix_of_archive':exact}
        if exact:
            record['sha256'] = sh.hexdigest(); partials.append(record)
        else:
            unproved.append(record)
    partial_review = {'action':'ROOT_REVIEWED_EXACT_TRANSPORT_PREFIX_PLACEHOLDER_RETIREMENT',
                      'verified_archive_sha256':spec['sha256'], 'library_file_id':spec['library_file_id'],
                      'verified_partials':partials, 'unknown_partials_retained':unproved,
                      'scientific_payloads_deleted':0}
    save_new(EVIDENCE / f'transport-partial-retirement-{index:03}-intent.json', partial_review)
    for proof in partials:
        candidate = Path(proof['path'])
        assert candidate.stat().st_size == proof['bytes'] and digest(candidate) == proof['sha256']
        with candidate.open('r+b') as handle:
            handle.truncate(0); handle.flush(); os.fsync(handle.fileno())
        assert candidate.stat().st_size == 0
    save_new(EVIDENCE / f'transport-partial-retirement-{index:03}-complete.json', partial_review)
    retirement = {'archive':str(archive), 'bytes':spec['bytes'], 'sha256':spec['sha256'],
                  'library_file_id':spec['library_file_id'], 'restoration_receipt_sha256':digest(receipt),
                  'action':'TRUNCATE_VERIFIED_REDUNDANT_TRANSPORT_TO_RETIRED_PLACEHOLDER',
                  'review':'Root reviewed exact verified transport retirement after unexplained reappearance; retain zero-byte placeholder',
                  'scientific_payloads_deleted':0}
    save_new(EVIDENCE / f'transport-retirement-{index:03}-intent.json', retirement)
    with archive.open('r+b') as handle:
        handle.truncate(0); handle.flush(); os.fsync(handle.fileno())
    retirement['retired_placeholder_bytes'] = archive.stat().st_size
    assert retirement['retired_placeholder_bytes'] == 0
    save_new(EVIDENCE / f'transport-retirement-{index:03}-complete.json', retirement)
    print(json.dumps({k:result[k] for k in ('index','status','restored_files','restored_bytes','existing_exact_files')}), flush=True)

if __name__ == '__main__':
    restore(int(sys.argv[1]), sys.argv[2])
