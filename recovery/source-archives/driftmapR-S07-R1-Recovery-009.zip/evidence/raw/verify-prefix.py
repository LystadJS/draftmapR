#!/usr/bin/env python3
"""Exhaustive read-only verification of the 163092-row preserved raw prefix."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import importlib.util, json, os, time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('restore_raw009', HERE / 'restore-archive.py')
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
plan, journal, manifest = r.bindings()
started = time.time()
archive_receipts = []
for i, archive in enumerate(plan['archives']):
    receipt = HERE / f'restored-{i:03}.json'
    row = json.loads(receipt.read_text())
    assert row['archive_sha256'] == archive['sha256'] and row['library_file_id'] == archive['library_file_id']
    assert row['status'] == 'ARCHIVE_AND_ALL_MEMBERS_VERIFIED_PREFIX_RESTORED'
    archive_receipts.append({'path':str(receipt), 'sha256':r.digest(receipt)})

def verify(item):
    name, row = item
    path = r.RUN / name
    assert path.is_file(), f'Missing {name}'
    before = path.stat()
    assert before.st_size == row['bytes'], f'Size mismatch {name}'
    actual = r.digest(path, 'md5')
    after = path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns) == (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns), f'Changed during read {name}'
    assert actual == row['md5'], f'Hash mismatch {name}'
    return row['bytes'], path.is_symlink()

count = size = links = 0
with ThreadPoolExecutor(max_workers=4) as pool:
    for n, link in pool.map(verify, journal.items()):
        count += 1; size += n; links += int(link)
        if count % 20000 == 0:
            print(json.dumps({'verified_files':count,'verified_bytes':size}), flush=True)
assert count == 163092 and size == 12848037331
present = {p.name for p in (r.RUN / r.PREFIX).iterdir() if p.name.endswith('.csv') and p.stem.isdigit() and int(p.stem) <= 163092}
assert present == {f'{i:07}.csv' for i in range(1,163093)}, 'Prefix grid mismatch'
assert r.digest(r.STATE / 'chunk-journal.jsonl') == plan['source_journal_sha256']
result = {'status':'RAW_PREFIX_FULLY_VERIFIED','started_at':started,'completed_at':time.time(),
          'prefix_files':count,'prefix_bytes':size,'symlink_files':links,'regular_files':count-links,
          'source_journal_sha256':plan['source_journal_sha256'],'archive_dependencies':len(archive_receipts),
          'archive_receipts':archive_receipts,'all_library_calls_finished':True,
          'new_scientific_panels':0,'new_fits':0,'new_draws':0,'scientific_payloads_deleted':0}
r.save_new(HERE / 'verified-prefix.json',result)
print(json.dumps({k:v for k,v in result.items() if k != 'archive_receipts'}),flush=True)
