from pathlib import Path
import json,subprocess,time,os,sys,select,shutil
O=Path(__file__).resolve().parent;ops=O.parent
assert json.loads((O/'launch-review.json').read_text())['status']=='passed'
assert not (O/'owned-launch.json').exists()
log=(O/'supervisor.log').open('x')
p=subprocess.Popen([sys.executable,'-u',str(O/'supervise.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'owned-launch.json').write_text(json.dumps(dict(supervisor_pid=p.pid,launch_time=time.time(),command=[sys.executable,'-u',str(O/'supervise.py')]),indent=2))
last=0
while p.poll() is None:
 now=time.time();state=None
 f=ops/'execution-process.json'
 if f.is_file():
  try:
   state=json.loads(f.read_text());assert state['supervisor_pid']==p.pid
  except (ValueError,AssertionError):state=None
 if now-last>=20:
  row=dict(time=now,supervisor_pid=p.pid,disk_free=shutil.disk_usage(ops).free)
  if state:
   row.update(status=state['status'],child_state=state['child_state'],phase=state.get('adapter_phase'),storage=state.get('storage'),error=state.get('last_error'))
   lf=Path(state['log']) if state.get('log') else None
   if lf and lf.exists():
    with lf.open('rb') as h:h.seek(max(0,lf.stat().st_size-1000));row['log_tail']=h.read().decode(errors='replace')[-700:]
  else:row['phase']='owned supervisor initial storage verification'
  print(json.dumps(row),flush=True);last=now
 ready,_,_=select.select([sys.stdin],[],[],1)
 if ready:
  line=sys.stdin.readline()
  if line.strip():
   try:
    q=json.loads(line);assert state and q['action'] in ('pause','resume')
    name='pause-execution-request-005.json' if q['action']=='pause' else 'resume-execution-request.json'
    with (ops/name).open('x') as h:json.dump(dict(action=q['action'],supervisor_token=state['supervisor_token'],child_pid=state['pid']),h);h.flush();os.fsync(h.fileno())
    print(json.dumps(dict(request_submitted=q['action'])),flush=True)
   except Exception as e:print(json.dumps(dict(request_refused=str(e))),flush=True)
  elif not line:time.sleep(1)
log.close();result=dict(exit_code=p.returncode,time=time.time())
(O/'owned-launch-exit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
print((O/'supervisor.log').read_text()[-4000:],flush=True)
if p.returncode == 0:
 for name in ['preserve-collection-005.py','finish-preservation-005.py']:
  print(json.dumps(dict(next_stage=name)),flush=True)
  with (O/(name+'.log')).open('x') as output:
   q=subprocess.Popen([sys.executable,str(ops/name)],stdout=output,stderr=subprocess.STDOUT)
   while q.poll() is None:
    print(json.dumps(dict(stage=name,status='running',time=time.time())),flush=True);time.sleep(20)
  if q.returncode:raise SystemExit(q.returncode)
raise SystemExit(p.returncode)
