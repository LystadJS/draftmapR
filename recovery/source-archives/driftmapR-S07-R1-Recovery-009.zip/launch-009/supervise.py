from pathlib import Path
import importlib.util,json,hashlib,signal,os,time,shutil
O=Path(__file__).resolve().parent;ops=O.parent;root=ops.parent
spec=importlib.util.spec_from_file_location('base',ops/'execute-resume.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
class Supervisor(base.ResumeSupervisor):
 def step(self):
  request=self.ops/'pause-execution-request-005.json'
  if request.exists():
   saved=self.ops/('pause-request-'+str(time.time_ns())+'.json');os.replace(request,saved);r=json.loads(saved.read_text())
   if r.get('action')=='pause' and r.get('supervisor_token')==self.token and r.get('child_pid')==self.child.pid:self.external_pause_requested='Explicit matching pause request'
   else:self.event('pause_request_refused',request=str(saved))
  if self.child.poll() is None and not self.child_state.startswith('paused_'):
   try:base.raw_allocation_guard(0,reserve_bytes=2*base.GIB)
   except Exception as e:self.pause('paused_for_memory',str(e))
  return super().step()
def main():
 gate=json.loads((O/'launch-review.json').read_text());assert gate['status']=='passed' and gate['reserved_launch_authorized']
 for name,h in gate['code_hashes'].items():assert base.sha256(name)==h,name
 base.raw_allocation_guard(0,reserve_bytes=5*base.GIB)
 assert not (ops/'execution-process.json').exists(),'Existing process state requires explicit review'
 run=root/'study07-results/S07-R1';state=ops/'resumable-collection-state'
 old=json.loads((O/'launch-arguments.json').read_text())
 command=[root/'r-runtime/bin/Rscript-local',ops/'resume-collection-prefix-006.R',*old['driver_args']]
 os.environ['S07_COMPRESSION_ROUTE_ROOT_005']='/root/.codex/tmp/s07r1-compression-006'
 supervisor=Supervisor(ops,run,command,base.make_spill_action(ops,run,audit_headroom_bytes=5*base.GIB),code_hashes=gate['code_hashes'],minimum_disk_bytes=2*base.GIB,interval=15,phase_file=state/'driver-status.json')
 def pause(number,frame):supervisor.external_pause_requested='Supervisor signal '+str(number)
 signal.signal(signal.SIGTERM,pause);signal.signal(signal.SIGINT,pause)
 return supervisor.run_to_terminal()
if __name__=='__main__':raise SystemExit(main())
