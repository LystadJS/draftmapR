# driftmapR S07-R1 — recovery audit, 24 September 2026

**Status: recovery integrity passed within the checked scope; scientific execution remains blocked.**

The audit continued from saved Library artifacts in a new, inactive workspace. Four incremental scientific checkpoint archives, four operational archives, and the frozen source archive were retrieved and verified. The latest scientific snapshot verified here contains **3,915 committed panels out of 6,480 (60.42%)**, with panel 3,916 partially serialized. **No new scientific panels, fitted models, or bootstrap draw vectors were generated.**

This is an audit handoff, not a new scientific checkpoint, complete end-of-run audit, or package-release certification. It does not establish that the previous chat's owner or publishers terminated.

## Work completed in this continuation

| Check | Actual verified result |
|---|---|
| Scientific checkpoint transport | All 21 parts passed their saved SHA-256/size checks and reproduced the exact 464, 468, 2250, and 3915 archives. |
| Scientific checkpoint contents | All 132,896 archive entries passed exact manifest membership, safe-path/type, size, CRC, and SHA-256 checks. Entries include repeated state across snapshots; this is not a count of unique scientific files. |
| Operational preservation | Recovery009, Launch014, Capacity-and-Fallback014, and Later-Phase-Controls014 passed byte/member verification: 1,250 additional entries. Historical save-status and owner records remain historical. |
| Frozen scientific source | All 460 files matched the authenticated source receipt. None was edited. |
| Journal continuity | All four journals retain exact byte prefixes across 464→468, 468→2250, and 2250→3915: 12 successful prefix comparisons. |
| Raw-file ledger | All 258,466 chunk-journal rows parsed with sequential, unique serials. The 95,374 freshly restored raw delta files match their journal paths, sizes, and MD5 bindings. Their byte hashes were verified against the archive manifests. |
| JSON exports | The journal contains 3,924 unique entries: 3,915 panel exports plus nine population exports. All 3,643 recovered JSON delta files match their journal bindings. Population exports are not extra completed panels. |
| Cached outputs | All 3,916 compact-cache hashes match the cache journal. R read every cache and checked component schemas and planned case/dataset identity, with the explicit population-level exception described below. |
| Input-verification receipts | R read all 6,480 receipts. Every job, seed stream, bootstrap seed, budget, stage, and frozen execution identity matches the saved design. For the 3,916 cache-linked jobs, checkpoint MD5s also match the ledger. These are receipt checks, not fresh rehashing of all referenced original inputs. |
| R validation | **Parsed successfully:** the audit script and all 191 recovered R source files. **Executed successfully:** the new read-only audit script. The frozen scientific runner and historical test suite were not executed. |
| Post-audit preservation | All 10,540 latest-state files and all 460 frozen-source files were rehashed after the audit and remained unchanged. |

The eight scientific/operational archives contain **134,146 checked entries** in total. The separate source archive contributes 460 files. Do not interpret archive-entry totals or receipt counts as additional collected panels.

## Exact preserved boundary

The committed panel journal ends at `s07_normal_mean_m160-1435` (panel 3,915), through raw chunk **258465**. The next key, `s07_normal_mean_m160-1436`, has a compact cache, an input-verification receipt, and journaled draw chunk **258466**, but no committed panel row or panel JSON export. It remains unfinished. Its saved bytes must be reused only through a newly approved recovery/launch procedure.

The committed cohort consists of 480 full-estimator panels and 3,435 normal-control panels. There are 2,565 uncommitted panels relative to this saved boundary. Saved operational capacity reports describe later live progress, but they explicitly do not contain later scientific payloads. This audit neither disproves that progress nor treats a live counter as a durable checkpoint. No newer scientific snapshot was established by the retrieved evidence.

Checkpoint3915 archive: **275,145,095 bytes**.

`SHA256 35937acbabb66d70347b89bf14bda5cd057c5b025632e3218f061ce0c83952fc`

## Why collection was not restarted

**Capacity is below the unchanged launch requirement.** This workspace has a hard cgroup memory cap of **4 GiB**. The saved collection controls require a **5 GiB free-memory launch/raw-copy reserve**, before considering actual scientific memory consumption. That requirement cannot be satisfied inside a 4 GiB cap. The gate was not reduced or bypassed. Host memory readings or reclaimable file cache do not change the hard cap.

**The pinned scientific runtime was not restored.** The authorized retrieval attempt for `driftmapR-study06-pinned-runtime.tar.gz` returned: “This Project file does not have an authorized raw-byte materialization path.” The saved scientific identity specifies **R 4.5.3**. A separate saved **R 4.6.1** package was extracted only to inspect RDS files and parse source. It was not installed over, aliased to, or represented as the pinned scientific runtime. Successful R4.6.1 inspection does not certify R4.5.3 numerical reproduction.

**The full ancestral input chain is not freshly restored.** Recovery009 records 128 prior archive dependencies, including the original checkpoints/draw plans and historical raw-prefix archives. The older **163,092 raw-prefix files** and all original referenced checkpoint/draw-plan payloads were not freshly restored and rehashed in this continuation. This is a remaining recovery task, not a claim that those Library artifacts are missing or corrupt. Preserve the historical dependency indexes and exact versions, especially checkpoint361 part002 version1.

The previous workspace paths do not exist here. No historical PID was signaled, no old owner/control program was invoked, and no stale ownership record was treated as proof of a live or terminated process elsewhere.

## Audit implementation correction, retained transparently

The first audit-only R pass rejected all 480 full-estimator caches because it incorrectly required `dataset_id` in every table. The frozen producer deliberately assigns `derivative_status` from a population-level reference. `study07-execution/R/diagnostics.R:40` makes that assignment, and `population.R:47–52` constructs case-level rows without `dataset_id`.

The corrected validator allows that one documented schema, retains case/dataset checks everywhere else, requires the exact component grid, and verifies that all 480 derivative reference tables are identical within each of the nine cases. It then passed all caches. The original script, failed results, logs, source references, and correction record are retained. No scientific data or frozen source was changed to make a check pass.

A separate initial Python verifier did not recognize Recovery009's `BUNDLE-MANIFEST.json` schema. That audit-tool limitation was corrected before the successful archive verification; the history is retained. Neither event is classified as scientific non-delivery or evidence of corrupted source data.

## Required next executable stage

Continue in an authorized workspace that satisfies the existing capacity gates. Restore the exact pinned runtime and the remaining upstream scientific payloads, verify their saved hashes and versions, and evaluate actual owner/lock state in that workspace. Then prepare a **new reviewed launch binding** for the changed workspace and resume deterministically from the preserved checkpoint, retaining the unfinished panel state. Do not invoke old launch or relocation commands as shortcuts.

After collection reaches all 6,480 panels, execute the frozen analyses and complete-grid scientific audits, retain full non-delivery accounting, verify owner and publisher closure, and preserve/read back the full scientific payload chain. Only then can this study support the pending evidence-based package scope/readiness decision.

## Evidence and reproduction

The accompanying ZIP contains complete new archive audit inventories, transport proofs, lineage checks, source-byte proof, R parsing/execution logs and per-object CSVs, environment/gate evidence, both audit revision histories, exact input identities, and the read-only audit scripts. It excludes the large scientific input archives and the R runtime; they remain separately identified dependencies. Embedded historical records are labeled as references and are not new owner-closure evidence.

Reproduction requires restoring the same inactive `staging` layout and original verified input archives identified in `results/input-identities-and-dependencies.json`. `scripts/verify_archive.py` verifies/extracts each archive into a new directory; `verify_sources.py` authenticates the frozen source archive; `verify_transport.py` verifies multipart transport; `audit_lineage.py` performs the ledger checks. `audit_saved_state.R` can be run with a suitable inspection R via `Rscript scripts/audit_saved_state.R AUDIT_ROOT`. `run_audit_R.sh` records the exact extracted-R invocation used here. These are inspection procedures, not scientific restart commands.

The ZIP's embedded `AUDIT-PACKAGE-MANIFEST.json` lists every member's size and SHA-256. Its own hash is bound by the external package receipt, avoiding a self-hash claim. The receipt distinguishes local packing from subsequent Library upload and fresh retrieval. The new audit package does not replace any scientific checkpoint or upstream dependency.

Primary historical references: Launch014 operator report and checkpoint roundtrip proofs; Recovery009 source/runtime receipts and dependency indexes; Capacity-and-Fallback014 and Later-Phase-Controls014 preservation records. New findings are supported by the executable checks and per-file results included in this handoff.
