#!/usr/bin/env python3
"""Package audit evidence, not a new scientific checkpoint.
Inputs remain separately saved Library dependencies. No source, runtime,
scientific data, controls, or ownership records are altered by this builder.
"""
import argparse,csv,hashlib,json,shutil,time,zipfile
from pathlib import Path

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def jread(path):return json.loads(path.read_text())
def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);r=p.parse_args().root.resolve()
    out=r/'delivery';out.mkdir(exist_ok=True)
    # Recheck the actual inspected latest-state and frozen-source bytes after R.
    latest=r/'staging/checkpoint3915';manifest=jread(latest/'SNAPSHOT-MANIFEST.json')
    checked=0
    for row in manifest['members']:
        if '/resumable-collection-state/' not in row['member']:continue
        f=latest/row['member'];assert f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],f
        checked+=1
    sreceipt=jread(r/'staging/recovery009-v2/prior-restoration/frozen_sources-restoration.json')
    for row in sreceipt['members']:
        f=r/'staging/sources'/row['path'].removeprefix('/workspace/scratch/837e4400dd1d/')
        assert f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],f
    readonly={'schema':'driftmapR-post-audit-no-change-check-v1','status':'PASS','time':time.time(),
      'latest_checkpoint_state_files_rehashed':checked,'frozen_source_files_rehashed':len(sreceipt['members']),
      'all_match_authenticated_manifests':True,'scientific_operations_performed':0}
    (r/'results/post-audit-no-change-check.json').write_text(json.dumps(readonly,indent=2)+'\n')
    archives=[jread(f) for f in sorted((r/'results').glob('*archive-audit.json'))]
    assert all(a['status']=='PASS' for a in archives)
    lineage=jread(r/'results/checkpoint-lineage-audit.json');assert lineage['status']=='PASS'
    with (r/'results/r-audit-checks.csv').open() as f:assert all(x['passed']=='TRUE' for x in csv.DictReader(f))
    names={
      'driftmapR-S07-R1-Launch-014.zip':'file_0000000010e081f59d449d64f1f80c67',
      'driftmapR-S07-R1-Capacity-and-Fallback-014.zip':'file_00000000c89081fda59c98a56cb838aa',
      'driftmapR-S07-R1-Later-Phase-Controls-014.zip':'file_000000007cf081fdabd771d163eb2887',
      'driftmapR-S07-R1-Recovery-009.zip':'file_000000006fa48230afcb5ee81d7cc58c',
      'driftmapR-S07-R1-sources.zip':'file_00000000b4d481f5a800634c14f97498'}
    inputs=[]
    for name,fid in names.items():
        f=r/'downloads'/name;inputs.append({'filename':name,'file_id':fid,'bytes':f.stat().st_size,'sha256':sha(f),'fresh_byte_verification':'PASS'})
    transport=jread(r/'results/transport-audit.json')
    inputs_index={'schema':'driftmapR-audit-input-identities-v1','time':time.time(),'single_file_inputs':inputs,
      'checkpoint_transport_groups':transport['checkpoint_groups'],
      'pinned_runtime':jread(r/'results/current-environment-and-restart-gate.json')['pinned_runtime'],
      'upstream_scientific_dependencies':'Recovery009 records 128 prior archive dependencies; not freshly restored in this audit. Refer to retained historical dependency indexes, and preserve exact versions, including checkpoint361 part002 version1.',
      'warning':'Historical status fields in dependency records are not fresh tests of availability or owner closure. This bundle contains audit evidence, not missing original payloads.'}
    (r/'results/input-identities-and-dependencies.json').write_text(json.dumps(inputs_index,indent=2)+'\n')
    report=out/'driftmapR-S07-R1-Recovery-Audit-20260924.md'
    report.write_text('''# driftmapR S07-R1 — recovery audit, 24 September 2026

**Status: recovery integrity passed within the checked scope; scientific execution remains blocked.**

The audit continued from saved Library artifacts in a new, inactive workspace. Four incremental scientific checkpoint archives, four operational archives, and the frozen source archive were retrieved and verified. The latest scientific snapshot verified here contains **3,915 committed panels out of 6,480 (60.42%)**, with panel 3,916 partially serialized. **No new scientific panels, fitted models, or bootstrap draw vectors were generated.**

This is an audit handoff, not a new scientific checkpoint, complete end-of-run audit, or package-release certification. It does not establish that the previous chat's owner or publishers terminated.

## Work completed in this continuation

| Check | Actual verified result |
|---|---|
| Scientific checkpoint transport | All 21 parts passed their saved SHA-256/size checks and reproduced the exact 464, 468, 2250, and 3915 archives. |
| Scientific checkpoint contents | All 132,896 archive entries passed exact manifest membership, safe-path/type, size, CRC, and SHA-256 checks. Entries include repeated state across snapshots; this is not a count of unique scientific files. |
| Operational preservation | Recovery009, Launch014, Capacity-and-Fallback014, and Later-Phase-Controls014 passed byte/member verification: 1,250 additional entries. Historical save-status and owner records remain historical. |
| Frozen scientific source | All 460 files matched the authenticated source receipt. None was edited. |
| Journal continuity | All four journals retain exact byte prefixes across 464→468, 468→2250, and 2250→3915: 12 successful prefix comparisons. |
| Raw-file ledger | All 258,466 chunk-journal rows parsed with sequential, unique serials. The 95,374 freshly restored raw delta files match their journal paths, sizes, and MD5 bindings. Their byte hashes were verified against the archive manifests. |
| JSON exports | The journal contains 3,924 unique entries: 3,915 panel exports plus nine population exports. All 3,643 recovered JSON delta files match their journal bindings. Population exports are not extra completed panels. |
| Cached outputs | All 3,916 compact-cache hashes match the cache journal. R read every cache and checked component schemas and planned case/dataset identity, with the explicit population-level exception described below. |
| Input-verification receipts | R read all 6,480 receipts. Every job, seed stream, bootstrap seed, budget, stage, and frozen execution identity matches the saved design. For the 3,916 cache-linked jobs, checkpoint MD5s also match the ledger. These are receipt checks, not fresh rehashing of all referenced original inputs. |
| R validation | **Parsed successfully:** the audit script and all 191 recovered R source files. **Executed successfully:** the new read-only audit script. The frozen scientific runner and historical test suite were not executed. |
| Post-audit preservation | All 10,540 latest-state files and all 460 frozen-source files were rehashed after the audit and remained unchanged. |

The eight scientific/operational archives contain **134,146 checked entries** in total. The separate source archive contributes 460 files. Do not interpret archive-entry totals or receipt counts as additional collected panels.

## Exact preserved boundary

The committed panel journal ends at `s07_normal_mean_m160-1435` (panel 3,915), through raw chunk **258465**. The next key, `s07_normal_mean_m160-1436`, has a compact cache, an input-verification receipt, and journaled draw chunk **258466**, but no committed panel row or panel JSON export. It remains unfinished. Its saved bytes must be reused only through a newly approved recovery/launch procedure.

The committed cohort consists of 480 full-estimator panels and 3,435 normal-control panels. There are 2,565 uncommitted panels relative to this saved boundary. Saved operational capacity reports describe later live progress, but they explicitly do not contain later scientific payloads. This audit neither disproves that progress nor treats a live counter as a durable checkpoint. No newer scientific snapshot was established by the retrieved evidence.

Checkpoint3915 archive: **275,145,095 bytes**.

`SHA256 35937acbabb66d70347b89bf14bda5cd057c5b025632e3218f061ce0c83952fc`

## Why collection was not restarted

**Capacity is below the unchanged launch requirement.** This workspace has a hard cgroup memory cap of **4 GiB**. The saved collection controls require a **5 GiB free-memory launch/raw-copy reserve**, before considering actual scientific memory consumption. That requirement cannot be satisfied inside a 4 GiB cap. The gate was not reduced or bypassed. Host memory readings or reclaimable file cache do not change the hard cap.

**The pinned scientific runtime was not restored.** The authorized retrieval attempt for `driftmapR-study06-pinned-runtime.tar.gz` returned: “This Project file does not have an authorized raw-byte materialization path.” The saved scientific identity specifies **R 4.5.3**. A separate saved **R 4.6.1** package was extracted only to inspect RDS files and parse source. It was not installed over, aliased to, or represented as the pinned scientific runtime. Successful R4.6.1 inspection does not certify R4.5.3 numerical reproduction.

**The full ancestral input chain is not freshly restored.** Recovery009 records 128 prior archive dependencies, including the original checkpoints/draw plans and historical raw-prefix archives. The older **163,092 raw-prefix files** and all original referenced checkpoint/draw-plan payloads were not freshly restored and rehashed in this continuation. This is a remaining recovery task, not a claim that those Library artifacts are missing or corrupt. Preserve the historical dependency indexes and exact versions, especially checkpoint361 part002 version1.

The previous workspace paths do not exist here. No historical PID was signaled, no old owner/control program was invoked, and no stale ownership record was treated as proof of a live or terminated process elsewhere.

## Audit implementation correction, retained transparently

The first audit-only R pass rejected all 480 full-estimator caches because it incorrectly required `dataset_id` in every table. The frozen producer deliberately assigns `derivative_status` from a population-level reference. `study07-execution/R/diagnostics.R:40` makes that assignment, and `population.R:47–52` constructs case-level rows without `dataset_id`.

The corrected validator allows that one documented schema, retains case/dataset checks everywhere else, requires the exact component grid, and verifies that all 480 derivative reference tables are identical within each of the nine cases. It then passed all caches. The original script, failed results, logs, source references, and correction record are retained. No scientific data or frozen source was changed to make a check pass.

A separate initial Python verifier did not recognize Recovery009's `BUNDLE-MANIFEST.json` schema. That audit-tool limitation was corrected before the successful archive verification; the history is retained. Neither event is classified as scientific non-delivery or evidence of corrupted source data.

## Required next executable stage

Continue in an authorized workspace that satisfies the existing capacity gates. Restore the exact pinned runtime and the remaining upstream scientific payloads, verify their saved hashes and versions, and evaluate actual owner/lock state in that workspace. Then prepare a **new reviewed launch binding** for the changed workspace and resume deterministically from the preserved checkpoint, retaining the unfinished panel state. Do not invoke old launch or relocation commands as shortcuts.

After collection reaches all 6,480 panels, execute the frozen analyses and complete-grid scientific audits, retain full non-delivery accounting, verify owner and publisher closure, and preserve/read back the full scientific payload chain. Only then can this study support the pending evidence-based package scope/readiness decision.

## Evidence and reproduction

The accompanying ZIP contains complete new archive audit inventories, transport proofs, lineage checks, source-byte proof, R parsing/execution logs and per-object CSVs, environment/gate evidence, both audit revision histories, exact input identities, and the read-only audit scripts. It excludes the large scientific input archives and the R runtime; they remain separately identified dependencies. Embedded historical records are labeled as references and are not new owner-closure evidence.

Reproduction requires restoring the same inactive `staging` layout and original verified input archives identified in `results/input-identities-and-dependencies.json`. `scripts/verify_archive.py` verifies/extracts each archive into a new directory; `verify_sources.py` authenticates the frozen source archive; `verify_transport.py` verifies multipart transport; `audit_lineage.py` performs the ledger checks. `audit_saved_state.R` can be run with a suitable inspection R via `Rscript scripts/audit_saved_state.R AUDIT_ROOT`. `run_audit_R.sh` records the exact extracted-R invocation used here. These are inspection procedures, not scientific restart commands.

The ZIP's embedded `AUDIT-PACKAGE-MANIFEST.json` lists every member's size and SHA-256. Its own hash is bound by the external package receipt, avoiding a self-hash claim. The receipt distinguishes local packing from subsequent Library upload and fresh retrieval. The new audit package does not replace any scientific checkpoint or upstream dependency.

Primary historical references: Launch014 operator report and checkpoint roundtrip proofs; Recovery009 source/runtime receipts and dependency indexes; Capacity-and-Fallback014 and Later-Phase-Controls014 preservation records. New findings are supported by the executable checks and per-file results included in this handoff.
''')
    tree=out/'package';tree.mkdir(exist_ok=False)
    shutil.copy2(report,tree/report.name)
    shutil.copytree(r/'scripts',tree/'scripts');shutil.copytree(r/'results',tree/'results')
    refs=tree/'references';refs.mkdir()
    for f in (r/'staging/launch014/evidence').glob('interruption*/checkpoint*-roundtrip-proof.json'):
        shutil.copy2(f,refs/f.name)
    for n in ['frozen_sources-restoration.json','pinned_runtime-restoration.json','restart-bundle-receipt.json']:
        shutil.copy2(r/'staging/recovery009-v2/prior-restoration'/n,refs/n)
    shutil.copytree(r/'staging/recovery009-v2/dependencies',refs/'historical-recovery009-dependencies')
    for name in ['driftmapR-S07-R1-Later-Phase-Controls-014-save-confirmation.json','driftmapR-S07-R1-checkpoint3915-014-manifest.json']:
        shutil.copy2(r/'downloads'/name,refs/name)
    members=[]
    for f in sorted(tree.rglob('*')):
        if f.is_file():members.append({'member':str(f.relative_to(tree)),'bytes':f.stat().st_size,'sha256':sha(f)})
    manifest={'schema':'driftmapR-recovery-audit-package-v1','created_epoch':time.time(),'status':'AUDIT_EVIDENCE_ONLY_NOT_A_SCIENTIFIC_CHECKPOINT',
      'scientific_panels_created':0,'members':members,'manifest_excludes_itself':True}
    manifest_path=tree/'AUDIT-PACKAGE-MANIFEST.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
    zip_path=out/'driftmapR-S07-R1-Recovery-Audit-20260924.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(tree.rglob('*')):
            if f.is_file():z.write(f,str(f.relative_to(tree)))
    with zipfile.ZipFile(zip_path) as z:
        expected={x['member']:x for x in members};expected['AUDIT-PACKAGE-MANIFEST.json']={'bytes':manifest_path.stat().st_size,'sha256':sha(manifest_path)}
        assert len(z.namelist())==len(expected) and set(z.namelist())==set(expected)
        for name,row in expected.items():
            data=z.read(name);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],name
    receipt={'schema':'driftmapR-recovery-audit-local-packing-receipt-v1','created_epoch':time.time(),
      'status':'LOCALLY_BYTE_VERIFIED_LIBRARY_UPLOAD_AND_READBACK_PENDING','archive':str(zip_path),'archive_bytes':zip_path.stat().st_size,'archive_sha256':sha(zip_path),
      'manifest_sha256':sha(manifest_path),'archive_members_verified':len(expected),'report':str(report),'report_sha256':sha(report),
      'scientific_checkpoint_created':False,'new_scientific_panels':0,'current_collection_restarted':False}
    receipt_path=out/'driftmapR-S07-R1-Recovery-Audit-20260924-receipt.json';receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
