#!/usr/bin/env bash
# Uses only the separately extracted inspection R. Never aliases the pinned runtime.
set -euo pipefail
ROOT="${1:?Provide the audit root}"
R="$ROOT/audit_runtime/unpacked/opt/R/4.6.1/lib/R"
export R_HOME="$R" R_SHARE_DIR="$R/share" R_INCLUDE_DIR="$R/include" R_DOC_DIR="$R/doc"
export LD_LIBRARY_PATH="$R/lib:${LD_LIBRARY_PATH:-}"
SCRIPT="$ROOT/scripts/audit_saved_state.R"
"$R/bin/exec/R" --vanilla --slave -e 'parse(file=commandArgs(trailingOnly=TRUE)[[1]]); cat("PARSED SUCCESSFULLY: audit-only script\n")' --args "$SCRIPT" > "$ROOT/results/r-audit-script-parsing.log" 2>&1
"$R/bin/exec/R" --vanilla --slave --file="$SCRIPT" --args "$ROOT" 2>&1 | tee "$ROOT/results/r-audit-execution.log"
