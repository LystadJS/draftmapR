#!/usr/bin/env python3
"""Read-only archive audit; optionally extract ONLY into a new inactive directory.
Never executes archived programs, recreates historical control endpoints or
changes frozen scientific files. Expected outer hashes must come from saved
receipts. Run with: python verify_archive.py ARCHIVE EXPECTED_SHA OUTPUT_JSON
"""
from __future__ import annotations
import argparse, collections, hashlib, json, os, stat, time, zipfile
from pathlib import Path, PurePosixPath

BLOCK = 1024 * 1024

def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(BLOCK), b''): h.update(b)
    return h.hexdigest()

def check(condition: bool, message: str) -> None:
    if not condition: raise ValueError(message)

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('archive', type=Path)
    ap.add_argument('expected_sha256')
    ap.add_argument('output', type=Path)
    ap.add_argument('--extract', type=Path)
    args = ap.parse_args()
    started = time.time()
    before = args.archive.stat()
    digest = sha_file(args.archive)
    check(digest == args.expected_sha256, 'Archive SHA-256 mismatch')
    if args.extract:
        check(not args.extract.exists(), 'Extraction target must not already exist')
        args.extract.mkdir(parents=True)
    with zipfile.ZipFile(args.archive) as z:
        infos = z.infolist(); names = [i.filename for i in infos]
        check(len(names) == len(set(names)), 'Duplicate ZIP member names')
        for i in infos:
            p = PurePosixPath(i.filename)
            check(not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename,
                  f'Unsafe path: {i.filename}')
            check(str(p) == i.filename and not i.is_dir(), f'Noncanonical path: {i.filename}')
            mode = i.external_attr >> 16
            check(stat.S_IFMT(mode) in (0, stat.S_IFREG), f'Nonregular member: {i.filename}')
            check(not i.flag_bits & 1, 'Encrypted members are not accepted')
        manifests = [x for x in ('MANIFEST.json','SOURCE-MANIFEST.json','SNAPSHOT-MANIFEST.json','BUNDLE-MANIFEST.json') if x in names]
        check(len(manifests)==1, 'Expected exactly one top-level manifest')
        mn = manifests[0]; mb = z.read(mn); manifest = json.loads(mb)
        entries = manifest.get('members')
        if mn == 'BUNDLE-MANIFEST.json':
            entries = [dict(e, member=e['path']) for e in manifest['files']]
        check(isinstance(entries,list), 'Manifest members must be a list')
        em = {e['member']:e for e in entries}
        check(len(em)==len(entries), 'Duplicate manifest members')
        check(set(names)==set(em)|{mn}, 'Archive/manifest membership differs')
        rows=[]; total=0; categories=collections.Counter()
        for idx,i in enumerate(infos,1):
            hs=hashlib.sha256(); hm=hashlib.md5(); n=0
            out=None
            if args.extract:
                target=args.extract / i.filename; target.parent.mkdir(parents=True,exist_ok=True)
                out=target.open('xb')
            try:
                with z.open(i) as f:
                    for b in iter(lambda: f.read(BLOCK),b''):
                        hs.update(b); hm.update(b); n+=len(b)
                        if out: out.write(b)
            finally:
                if out: out.close()
            check(n==i.file_size, f'ZIP size differs: {i.filename}')
            if i.filename!=mn:
                e=em[i.filename]
                check(n==e['bytes'] and hs.hexdigest()==e['sha256'], f'Manifest mismatch: {i.filename}')
                if e.get('md5'): check(hm.hexdigest()==e['md5'],f'MD5 differs: {i.filename}')
                for c in e.get('categories',[]): categories[c]+=1
            total+=n
            rows.append({'member':i.filename,'bytes':n,'sha256':hs.hexdigest(),'md5':hm.hexdigest(),'status':'PASS'})
        after=args.archive.stat()
        check((before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino),'Archive changed during audit')
        report={'schema':'driftmapR-fresh-archive-audit-v1','status':'PASS','started_utc_epoch':started,
                'finished_utc_epoch':time.time(),'archive':str(args.archive),'archive_bytes':before.st_size,
                'archive_sha256':digest,'manifest':mn,'manifest_sha256':hashlib.sha256(mb).hexdigest(),
                'archive_members_verified':len(infos),'manifest_payload_members_verified':len(entries),
                'logical_bytes_verified':total,'security_checks_passed':True,'all_crc_size_sha256_checks_passed':True,
                'category_counts':dict(categories),'extraction_directory':str(args.extract) if args.extract else None,
                'scientific_operations_performed':0,'original_live_workspace_modified':False,
                'limitations':['Verifies this archive only, not missing ancestral payloads or scientific validity.'],
                'members':rows}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    temp=args.output.with_suffix('.tmp'); temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(args.output)
    print(json.dumps({k:v for k,v in report.items() if k!='members'},indent=2))

if __name__=='__main__': main()
