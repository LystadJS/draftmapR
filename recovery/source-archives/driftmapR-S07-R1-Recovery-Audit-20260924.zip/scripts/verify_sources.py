#!/usr/bin/env python3
"""Verify a frozen source ZIP against the previously authenticated external receipt.
Only reads source bytes and creates files in a new, inactive staging directory.
No recovered source is executed and no historical workspace is overwritten.
"""
import argparse, hashlib, json, stat, time, zipfile
from pathlib import Path, PurePosixPath

def digest(data, algorithm='sha256'):
    return hashlib.new(algorithm, data).hexdigest()

def main():
    p=argparse.ArgumentParser(); p.add_argument('root', type=Path); args=p.parse_args(); root=args.root.resolve()
    receipt_path=root/'staging/recovery009-v2/prior-restoration/frozen_sources-restoration.json'
    archive=root/'downloads/driftmapR-S07-R1-sources.zip'; destination=root/'staging/sources'
    expected=json.loads(receipt_path.read_text()); started=time.time(); archive_before=archive.stat()
    sha=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
    assert sha==expected['archive_sha256'], 'Source archive SHA256 mismatch'
    mapping={}; prefix='/workspace/scratch/837e4400dd1d/'
    for row in expected['members']:
        assert row['path'].startswith(prefix), 'Unexpected source root'
        name=row['path'][len(prefix):]; assert name not in mapping; mapping[name]=row
    destination.mkdir(exist_ok=False); checked=[]
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist(); names=[x.filename for x in infos]
        assert len(names)==len(set(names)) and set(names)==set(mapping), 'Source membership mismatch'
        for info in infos:
            name=info.filename; pp=PurePosixPath(name); mode=info.external_attr>>16
            assert not pp.is_absolute() and '..' not in pp.parts and str(pp)==name and '\\' not in name
            assert stat.S_IFMT(mode) in (0,stat.S_IFREG) and not info.is_dir() and not (info.flag_bits&1)
            data=z.read(info); row=mapping[name]
            assert len(data)==row['bytes'] and digest(data)==row['sha256'] and digest(data,'md5')==row['md5'], name
            target=destination.joinpath(*pp.parts); target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as f:f.write(data)
            checked.append({'member':name,'bytes':len(data),'sha256':row['sha256'],'md5':row['md5']})
    after=archive.stat(); assert (archive_before.st_size,archive_before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    assert len(checked)==expected['files'] and sum(x['bytes'] for x in checked)==expected['bytes']
    result={'schema':'driftmapR-20260924-source-byte-audit-v1','status':'PASS','started_epoch':started,'finished_epoch':time.time(),
      'archive':str(archive),'archive_sha256':sha,'archive_bytes':after.st_size,'reference_receipt':str(receipt_path),
      'reference_receipt_sha256':digest(receipt_path.read_bytes()),'files_verified':len(checked),'logical_bytes':sum(x['bytes'] for x in checked),
      'extraction_directory':str(destination),'frozen_sources_modified':False,'scientific_operations_performed':0,
      'runtime_reproduction_claimed':False,'members':checked}
    out=root/'results/frozen-sources-audit.json'; out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='members'},indent=2))
if __name__=='__main__':main()
