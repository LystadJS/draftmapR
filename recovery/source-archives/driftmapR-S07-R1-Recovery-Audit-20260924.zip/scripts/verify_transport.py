#!/usr/bin/env python3
"""Verify freshly retrieved checkpoint parts and their reconstructed archives.
Exact identities are read from authenticated historical proofs; their historical
owner or version claims are not recast as new process-closure verification.
"""
import argparse,hashlib,json,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);r=p.parse_args().root.resolve();groups=[]
    for source in sorted((r/'staging/launch014/evidence').glob('interruption*/checkpoint*-roundtrip-proof.json')):
        d=json.loads(source.read_text());offset=0;whole=hashlib.sha256();parts=[];ids=set();library_ids=set()
        for expected in d['parts']:
            name=expected.get('filename',expected.get('file'));f=r/'downloads'/name
            assert expected['offset']==offset and f.stat().st_size==expected['bytes']
            assert expected['file_id'] not in ids and expected['library_file_id'] not in library_ids
            ids.add(expected['file_id']);library_ids.add(expected['library_file_id']);h=hashlib.sha256()
            with f.open('rb') as stream:
                for block in iter(lambda:stream.read(1<<20),b''):h.update(block);whole.update(block)
            assert h.hexdigest()==expected['sha256'];offset+=f.stat().st_size
            parts.append({k:expected[k] for k in ('index','offset','bytes','sha256','file_id','library_file_id','version')}|{'filename':name,'retrieved_path':str(f),'fresh_bytes_verified':True})
        assert offset==d['reconstructed_bytes'] and whole.hexdigest()==d['reconstructed_sha256']
        archive_name=parts[0]['filename'].rsplit('.part',1)[0];archive=r/'downloads'/archive_name
        with archive.open('rb') as stream:archive_sha=hashlib.file_digest(stream,'sha256').hexdigest()
        assert archive_sha==whole.hexdigest() and archive.stat().st_size==offset
        groups.append({'checkpoint':d['collection_panels'],'archive':archive_name,'archive_bytes':offset,'archive_sha256':archive_sha,
          'parts':parts,'proof_reference':str(source),'proof_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'status':'PASS'})
    result={'schema':'driftmapR-20260924-transport-audit-v1','status':'PASS','time':time.time(),'checkpoint_groups':groups,
      'parts_verified':sum(len(x['parts']) for x in groups),'reconstructed_archives_verified':len(groups),
      'distinct_byte_total':sum(x['archive_bytes'] for x in groups),
      'scope':'Fresh retrieved bytes and reconstructed archive hashes; no live owner verification or new scientific checkpoint creation.'}
    (r/'results/transport-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS:',result['parts_verified'],'parts;',len(groups),'reconstructed archives')
if __name__=='__main__':main()
