# S07-R1 completed engineering freeze

S07-R1 is implemented, engineering-validated, frozen, and freshly verified.
This completes the authorized numerical recovery implementation. The reserved
recovery study has not been executed under R1.

## Completed

- Restored and verified immutable S07-D1, S07-I1, the pinned R 4.5.3 runtime,
  installed driftmapR 0.0.7.9000, and the original checkpoint-catalog lock.
- Implemented stable weighted-centered-data QR control pivots with an independent
  physically expanded-sample SVD check at the unchanged `1e-9` scalar tolerance.
- Preserved original covariance entries, the `1e-8` SPD ratio gate, means,
  seeds, budgets, full-estimator calculations, and population references.
- Implemented uniform recomputation of every linear/normal control, strict
  read-only source preflight, exact missing-job permissions, preservation hashes,
  deterministic resume, and infrastructure/non-delivery separation.
- Retained the inherited analyses and complete independent audit, including
  full-estimator, population, deletion, cohort, reporting, and figure checks.

## Validation

| Executed gate | Result |
|---|---:|
| Integrated R assertions | 1,080 passed in 19 blocks |
| Independent Python audit tests | 25 passed |
| Synthetic sealing/guard tests | 12 passed, including 9 isolated R guard cases |
| Complete engineering panels | 12 / 12 |
| Planned engineering draw vectors | 1,564 / 1,564 |
| Two-frame deletion slots audited | 124,368 |
| Population perturbation roles audited | 16,524 |
| Public-adapter audit rows | 10,381 |
| Physical control audit rows | 681 |
| Complete independent audit assertions | 754,793 passed |
| Recovery provenance assertions, included above | 439 |
| Figures generated and visually reviewed | 4 |
| Newly generated reserved panels / weights | 0 / 0 |

Final tests have zero failures, errors, warnings, or skips. The engineering
grid, collection, analyses, final audit, freeze, and fresh verification exited
successfully. An initial test-harness reporter initialization error was fixed
before the final suite. A catalog comparison bug found during review was fixed
before integrated validation. No package code or dependencies were changed;
a fresh `R CMD check` was not run for this standalone study-runner amendment.

The tests include serial/parallel equality, unchanged RNG state, corrupted-input
refusal without quarantine, changed-payload resume refusal, explicit failure
accounting, and reconstruction of an isolated missing sparse engineering panel.
That panel matched the original full-estimator scientific hash and exact saved
units, plan, and reference. Only seed 781 / dataset 999 fixtures and deterministic
arrays were used; the five reserved replay matrices were not used for validation.

The independent numerical review exercised 945 deterministic cases in each
runtime. Maximum QR/SVD relative discrepancy was approximately `2.77e-12` in R
and `3.99e-12` in Python. The original covariance-spectrum calculation exceeded
`1e-9` in 73 R fixtures, reproducing the numerical mechanism without reserved
outcomes. These are engineering checks, not coverage estimates.

## Frozen identities

| Item | SHA256 |
|---|---|
| S07-R1 freeze JSON, 46 files plus two locks | `e3edea53e346ce6ab1f966b8a9e6fcda6025bd1ca4e8d24a90be4ba297eba3b4` |
| S07-I1 freeze | `f9d2ce830c8e8cde52ad22d995fdf343b3df7f7430dcf7df0ee11a169f32dd7e` |
| S07-D1 freeze | `d8286657a1ec3410e2574f98e08a0a9c98936a987872c32136e579871eb2d85b` |
| Original checkpoint catalog | `64e7b5d059ef95141e1784c39038b46540f59d7c647a3308dc8c10bf3c70960f` |
| Pinned runtime archive | `a61e14e5815a70cd8d70e1600e2583c10d52c0af59475773934a9843dd7caf2d` |

The new source archive contains `study07-recovery/`, unchanged ancestor source
trees, this handoff, and the historical original-run recovery index. The
engineering archive contains both original and recovered engineering grids,
tests, exact tables, raw/checkpoint ledgers, all four figures, and independent
review material. The separate pinned runtime archive remains required.

## Remaining state and progress

The S07-R1 implementation/freeze milestone is complete. The package remains a
research prototype pending the complete Study 07 mechanism evidence and v0.1
scope decision; this work does not establish calibration or release readiness.

The original reserved run still has 6,475 validated checkpoints and five
uncommitted sparse exceptions: datasets 18, 20, 30, 32, and 37. These are
implementation exceptions, not statistical non-delivery. The 25-part original
checkpoint chain remains the source of truth. This session restored its index
and locked catalog, not the complete 5.38 GB input tree. Reserved preflight will
rehash and validate every catalogued file before any recovery work.

## Next concrete target

Restore the original 25-part checkpoint chain in the recorded order, verify it,
and execute the frozen S07-R1 recovery. It will migrate all 6,475 verified
checkpoints, uniformly recompute their controls, and refit only the five exact
missing original jobs using existing saved draw plans. No replacement draw
vectors are allowed. The target remains all 6,480 panels, 1,313,520 saved draw
vectors, and 31,232,000 full-estimator deletion slots with full non-delivery
accounting.

Use the original workspace `/workspace/scratch/837e4400dd1d` because the inherited
runtime identity is path-bound. After restoring the pinned runtime and source
archives, the commands are:

```sh
r-runtime/bin/Rscript-local study07-recovery/scripts/verify.R
r-runtime/bin/Rscript-local study07-recovery/scripts/run.R reserved study07-results/S07-D1 study07-results/S07-R1 4
```

Do not restart the old S07-I1 runner. Do not change a frozen file to resume.
If any source file is missing/corrupt, restore its exact archived bytes first.
The new run must pass its complete-grid final audit before any scientific
conclusion is reported. After that, make the planned v0.1 supported-regime scope
decision; do not automatically open another calibration study.
