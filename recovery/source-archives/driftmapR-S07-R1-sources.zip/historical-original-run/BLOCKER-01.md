# S07-I1 execution blocker: sparse linear-control pivot agreement

Status: reproduced implementation/validation exception; unresolved. S07-D1 and
S07-I1 remain unchanged. This is not statistical non-delivery and does not
authorize relaxing a tolerance or changing a screen.

## Evidence

The original frozen run raised `Control scalar pivot` in `s07_sparse_m12`
datasets 18, 20, 30, 32 and 37. Their original incident RDS files are preserved.
All five jobs lack validated scientific checkpoints. The other 35 sparse jobs
completed their job-level checks; this is not a claim of confidence-region delivery.

The S07-I1 source SHA256 remains verified:
`f9d2ce830c8e8cde52ad22d995fdf343b3df7f7430dcf7df0ee11a169f32dd7e`.

`diagnose-control-pivots.R` reconstructs exactly those five original measurement
panels and loads their already-committed draw weights. It creates no new
independent panels or weights, changes no scientific code, and publishes no
successful replacement checkpoints. The five exact measurement replays are
counted separately. Complete diagnostics are in `pivot-diagnostic-01/`.

| Dataset | Target | Scalar comparisons failing the frozen check |
|---|---|---:|
| 18 | E003 | 12 |
| 20 | E003 | 2 |
| 30 | E003 | 3 |
| 32 | E003 | 20 |
| 37 | E003 | 5 |

All five failures were reproduced, with 42 failing scalar comparisons. Normalized
pivot discrepancies range from 1.016482e-9 to 1.667557e-8; the threshold is 1e-9.
Expanded covariance eigenvalue ratios range from 1.015203e-8 to 5.531158e-8,
near the SPD boundary of 1e-8. Weighted-versus-expanded covariance differences
are 3.388132e-21 to 4.336809e-19 in absolute magnitude, or 1.586492e-17 to
4.042897e-16 relative to the maximum covariance entry. Mean differences are at
most 1.387779e-17.

These observations are consistent with amplification of floating-point
differences by poorly conditioned covariance matrices. They do not establish
that either scalar computation meets the required agreement. No validator has
been suppressed, tolerance increased, or correction implemented.

## Accounting

The original runner finished all already-planned job attempts and exited with
code 1. Exactly 475 full-estimator and all 6,000 normal-control jobs validated.
Final grid reconciliation and the incomplete-study summary refusal gate passed.
The five sparse jobs remain
implementation/infrastructure-unresolved, not failures to deliver regions.
Do not publish complete coverage, final figures, or a completed-study scope decision.

The full-plan gate and independent audit remain mandatory. The operational
checkpoint audit's `infrastructure_invalid=0` means committed checkpoints passed
identity/checksum checks; it does not negate exceptions in uncommitted jobs.

## Next authorization required

Specify a separately named S07-R1 numerical-validation recovery amendment.
Develop deterministic ill-conditioned linear-control fixtures, establish a
stable calculation with independent arithmetic checks, preserve the original
evidence, and freeze the amendment before recovery. Retain the original design,
seeds, weights, budgets, SPD rule and agreement tolerance unless a separately
justified change is explicitly approved. Reuse verified unaffected checkpoints
only under an explicit compatibility/provenance contract. Recompute exact
unresolved original jobs; never redraw for success. Then collect the entire
original plan and run the complete independent audit.

Repeated unchanged reruns are not a remedy. The original resume command is
retained for provenance, not as a proposed fix. No new calibration or
outcome-selected inferential revision is authorized by this diagnosis.
