# Study 07 recovery state — incomplete execution

The scientific design and implementation remain S07-D1 / S07-I1 without amendment.
No complete-study coverage or release-scope conclusion is available yet.

**Execution blocker:** five sparse-unit jobs (datasets 18, 20, 30, 32, 37) fail
the frozen `Control scalar pivot` check. Exact diagnostic replays reproduced all
five. See `BLOCKER-01.md`. Do not treat them as statistical non-delivery or retry
them repeatedly without a separately authorized recovery amendment. The original
runner finished every planned job attempt and exited with code 1: 6,475
validated jobs and those five unresolved exceptions.

## Saved checkpoint chain

Extract the following archives in order under the original workspace root:

1. `driftmapR-S07-execution-checkpoint-part-001.tar.gz`
   - All 6,480 exact draw plans (1,313,520 draw vectors), all nine population
     references, the execution identity, and the complete seed/job plan.
   - SHA256 `64f7373aba22a4420e4507614207f1fca903c6bcf8898d402d820be62615e4da`.
2. `driftmapR-S07-checkpoint-02-part-001.tar.gz`
   - Incremental checkpoint payloads and manifests for 39 completed panels.
   - Depends on archive 1; unchanged files are not duplicated.
   - SHA256 `246e07fedd9943d3022be6fc1f6e0d89ed752cdf32cc7fee5cba22a50efcb4ac`.
3. `driftmapR-S07-checkpoint-03-part-001.tar.gz`
   - Remaining 41 panels of the m=40 regular-null cell; 80 completed panels in
     the cumulative snapshot. Depends on archives 1 and 2.
   - SHA256 `155f3318e0e2f8de7ac5554e05c75d894309f0e4e1b826a15070fcf252f277fa`.
4. Both `driftmapR-S07-checkpoint-04-part-001.tar.gz` and
   `driftmapR-S07-checkpoint-04-part-002.tar.gz`
   - Twelve m=160 extension panels; 92 completed panels cumulatively.
     Depends on all preceding archives.
   - Part 1 SHA256 `124cc734f392d65c63d9ea9a3f46ceabbdf2f9749f46c13818d77a9eba16c575`.
   - Part 2 SHA256 `dcea3860831c80eabd5bf84ca488320419955c874fc9ca3203cf2e05ac172a3b`.
5. Both `driftmapR-S07-checkpoint-05-part-001.tar.gz` and
   `driftmapR-S07-checkpoint-05-part-002.tar.gz`
   - Thirty additional m=160 panels; 122 completed panels cumulatively.
     Depends on all preceding archives.
   - Part 1 SHA256 `d03cfdd3d56d935a30770a95d773eb708a1ab077374a081104e34c30b1a8a655`.
   - Part 2 SHA256 `93ece23502c3dbe5213470a7d65c21ce9fa1192286af2ed7ef54460e5db31897`.
6. Both `driftmapR-S07-checkpoint-06-part-001.tar.gz` and
   `driftmapR-S07-checkpoint-06-part-002.tar.gz`
   - Remaining 38 m=160 panels; all 160 panels of the two primary null cells,
     including all 40 B=799 extensions, are now in the cumulative snapshot.
     Depends on all preceding archives.
   - Part 1 SHA256 `089fd397be3d339c014d3564b53b05f5f6c8a605b54eb5d78141a779efb85630`.
   - Part 2 SHA256 `22c8d8e32ecab55465f603f17772aae1d64521052eef2038900270ebb871d27d`.
7. All three `driftmapR-S07-checkpoint-07-part-00N.tar.gz` files (N=1,2,3)
   - Twenty-one m=640 panels; 181 completed panels cumulatively.
     Depends on all preceding archives.
   - Part 1 SHA256 `005dff80c0b2f64dda72a59d183a1a1c1badce0c679d17cbc32a1a975a5701ac`.
   - Part 2 SHA256 `7da7f743fe8d39ce38d6cc814ef38e8c3d99e4d380c4ea0bd06969725fdf16a4`.
   - Part 3 SHA256 `96e191bab89471473797fc2ca22f2457801e7106f1b31d5fab82d88c58f408e4`.

8. All three `driftmapR-S07-checkpoint-08-part-00N.tar.gz` files (N=1,2,3)
   - Remaining nineteen m=640 panels and fifteen anchor-contamination panels;
     215 completed panels cumulatively, including all 200 regular-null panels.
     Depends on all preceding archives.
   - Part 1 SHA256 `df43d20853ad2484622ddffb6858ff497ac742a013b46a5cdd3742a72a535be9`.
   - Part 2 SHA256 `6e1c5ac846c4e8cc2923d3ab7efbf6c66c1168672b08b87f75717eb688bd3d72`.
   - Part 3 SHA256 `1c30ebd92fa24e3f24b5045727cdd873d1522c431a5e8959a43985b515d03acd`.

9. Both `driftmapR-S07-checkpoint-09-part-001.tar.gz` and
   `driftmapR-S07-checkpoint-09-part-002.tar.gz`
   - Remaining 105 anchor-contamination panels and eight movement panels;
     328 completed panels cumulatively. Depends on all preceding archives.
   - Part 1 SHA256 `dd801c2555fbad95223fdb85904a9b88807f746c81dac5db6efaf95c3766372b`.
   - Part 2 SHA256 `ea829a43329156d7df3b9abf88f4ca9dc7b8f601b20c4317a1f462a60457bba6`.

10. All three `driftmapR-S07-checkpoint-10-part-00N.tar.gz` files (N=1,2,3)
    - Remaining 72 movement panels, 35 sparse panels and one AR(1) panel;
      436 completed panels cumulatively. Depends on all preceding archives.
    - Part 1 SHA256 `b29ac3580f03f859837a5844ae606beee5df4d1411cb04aa5d612c25b49f268b`.
    - Part 2 SHA256 `ec42563a2019cb8226f7e6b521d75f646c20736d7c9a7ffef9c5bf4f139edacb`.
    - Part 3 SHA256 `b1f93edb30da8412f651ab4c00c958d3d43e595773652c8bf5a515352a571845`.

11. Both `driftmapR-S07-checkpoint-11-part-001.tar.gz` and
    `driftmapR-S07-checkpoint-11-part-002.tar.gz`
    - Remaining 39 AR(1) panels, 1,761 normal m=40 panels, and five incident
      records; 2,236 validated panels cumulatively. All 475 successful full
      panels are now saved. Depends on all preceding archives.
    - Part 1 SHA256 `6fde829911d18ac7b982cfc6c7446c4ec9e753f77c0431705f5554505f43e4e0`.
    - Part 2 SHA256 `057b7f2f9a6f2b32dd134c91732e0d121c752588571b69fa87506e252156786b`.

12. All three `driftmapR-S07-checkpoint-12-part-00N.tar.gz` files (N=1,2,3)
    - Remaining 4,239 normal-control panels and final original execution-status
      files; 6,475 validated panels cumulatively. Depends on all preceding archives.
    - Part 1 SHA256 `08abf5ad067452fab1e9d03914df8da2d4c8fc8dbeb9e41b60d2b9078707a878`.
    - Part 2 SHA256 `789cc06332d70a95940ac026c985fa025c34f25bc23336ff135c16403909b696`.
    - Part 3 SHA256 `796d80593164fa656504a351d5aa125913473c9d2395bc3615fcd0e6629568e2`.

The catalog in `checkpoint-12/` is the final authoritative operational snapshot.
Its audit found zero invalid committed checkpoints, all 6,475 validated panels,
and exactly five unresolved incident jobs. There are no pending or running jobs.
Those five uncommitted panels are implementation/infrastructure incompleteness,
not statistical non-delivery. The original process exited with code 1.

A completed panel includes its retained failure and non-delivery states; it does
not imply that all of that panel's confidence regions were delivered.

`RECOVERY-INDEX.json` supplies machine-readable identities and checksums for the
confirmed saved archives, including their required restoration order.

Restore `driftmapR-S07-I1-sources.zip` and
`driftmapR-study06-pinned-runtime.tar.gz` at their original paths. Verify both
freezes and the numerical runtime before any separately authorized recovery:

```sh
python3 study07-specification/scripts/freeze.py verify
r-runtime/bin/Rscript-local study07-execution/scripts/verify.R
python3 study07-execution/scripts/manifest.py verify study07-execution
```

Do not start a second runner against an output directory while its first runner
is still active. Reuse existing immutable checkpoints and exact original jobs.
The original command is retained in `RECOVERY-INDEX.json` for provenance only;
it will not fix the reproduced validator exceptions without a separately
specified and frozen recovery amendment.

## Additional validation

All nine saved population references passed the frozen R validator and a separate
invocation of the frozen independent population arithmetic audit (49,694
assertions). These read-only audits generated no panels or bootstrap weights.
They do not replace the complete-plan independent final audit.

`summarize-complete.R` is a presentation-only extractor outside the freeze. Its
incomplete-study refusal gate was tested successfully; it emits no results before
the frozen complete-plan and independent-audit markers pass. Its numerical
extraction awaits the completed study and will use the unchanged frozen reports.

## Remaining work

Complete all 480 full-estimator and 6,000 normal-control panels, collect the full
planned ledgers, run the unchanged analyses and independent final audit, inspect
the four figures and exact scalar tables, then make the prescribed v0.1 scope
decision. Do not choose a revised screen from partial results or automatically
schedule another calibration study.
