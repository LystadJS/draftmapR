# Implementation map and failure contract

| Frozen requirement | Implementation | Evidence |
|---|---|---|
| Exact restored ancestry, new case/B adapter, reserved gate | `guards.R`, `generator.R` | Source/runtime guards; seed, dimensions, caller-RNG and inherited-law tests |
| Complete population functional, fixed finite differences | `population.R` | All 306×3×2 roles; regular/movement/weak directional checks; forced base/perturbation/moment failures; independent NumPy refits |
| Gaussian paired fourth moments and AR diagnostic | `population.R` | Independent trace contraction and covariance contraction; Toeplitz factor test; sparse structural-N/A test |
| Linear occurrence covariance and normal controls | `controls.R` | Physical expanded deletions at m=40/160/640; independent weighted covariance, Hotelling and pivot calculations |
| Full estimator and 199/799 exact nesting | `full.R` | Unchanged inherited engine; actual independent B199 fit versus B799 prefix; all metadata recomputed at B199 |
| Complete raw collectors/checkpoints | `runner.R` | Exact job/source identity, content/row-count manifests; immutable checkpoint corruption and identity tests |
| Original/T1 reporting and empty cohorts | `analysis.R` | Six retained cohorts; D/M, C/D, C/M, Z/D, Z/M; independent counts/Wilson/MCSE |
| Covariance, remainder, sparse/selection diagnostics | `diagnostics.R` | Matched own/joint cohorts, outer-delete failures, 80/160 ID joins; independent covariance and cross-term identities |
| Public PCA/classical-MDS and physical deletion audits | `validation.R` | Every planned draw on audit panels; observed/first-two bootstrap physical parents; numerical comparisons distinguished from blocks |
| Independent audit and four exact-value figures | `scripts/audit_*.py`, `scripts/final-audit.py`, `figures.R` | Independent arithmetic; malformed/duplicate/missing/corrupt adversarial tests; image review |
| Immutable I1 freeze | `scripts/freeze.R`, `manifest.py`, `verify.R` | Bound source/runtime/test identities; exact MD5 and SHA256 inventories; refusal of a second freeze |

The complete functional uses centered Gram eigendecomposition, an orthogonal registration to the fixed baseline reference, and declared-anchor temporal registration. Translation, rotations and reflections are retained. There is no fixed-frame deletion shortcut. Influence derivatives include both embedding and registration dependence.

For weights w with sum m, a linear mean has occurrence covariance

`sum_i w_i (psi_i - mean_w)(psi_i - mean_w)' / [m(m-1)]`.

Its exact conditional multinomial covariance uses m² in the denominator. Full-estimator occurrence jackknifes instead refit after each required original-unit deletion and weight repeated deletion values by their occurrence multiplicities. A failed required deletion invalidates that parent covariance; later available-parent deletions still run. Zero-multiplicity original-unit slots remain in the ledger.

Every stage balances required = attempted + unattempted-required and attempted = successful + failed-after-attempt. Counts for original units, represented occurrences, targets and shared population diagnostics are separate. Normal/linear occurrence slots represent closed-form computations; they are not falsely counted as separately executed refits.

Core candidate availability and population evaluation availability are distinct. If evaluation registration alone fails, candidate delivery remains unknown and study-evaluable delivery is false. Diagnostic non-delivery cannot be relabeled as candidate failure. Policy T1 only restricts reported delivery, using original observed core diagnostics and the six frozen assumptions. Oracle truth, analytic moments, bootstrap outcomes and clean-anchor fits never choose T1.

The independent Python audit does not invoke R or draw random numbers. It recomputes population functionals, finite-difference Jacobians, Gaussian fourth moments, weighted influence values, all full bootstrap point estimates, scalar pivots, covariance/scatter identities, and selected physical deletion covariances. R public adapters and the inherited mechanical validator independently cover the full deletion ledger and public PCA/classical-MDS comparisons. Reports are recomputed from exported raw rows. Checksums alone are not treated as statistical validation.

Infrastructure failure is an incomplete execution, not statistical non-delivery. Reports are not declared complete until every original job and the final audit pass. Raw evidence from failed engineering attempts is preserved outside the frozen implementation.

Checkpoint storage retains canonical unit matrices, every exact weight/state,
all scalar geometry and deletion records, unmasked covariance/scatter values,
and all population matrices. The temporary per-fit Gram/registration matrix
cache is checked in memory and then omitted from checkpoints: those matrices
are exactly regenerable from the retained inputs and frozen source. This avoids
persisting hundreds of copies of the same high-dimensional input geometry.
The checkpoint records this retention policy explicitly. Public-audit records
and mechanical validation results are retained; omitted caches are never
counted as missing scientific jobs.

CSV collection publishes immutable, individually checksummed chunks after an R
read-back count/schema check. The Python finalizer checks every chunk checksum,
header and record width, writes a complete gzip stream, verifies its trailer and
row count, then atomically publishes the product. All final table row counts
must match the planned collector counts. Core and oracle-frame deletion rows
share an explicit `core_success` field, preserving the per-deletion dependency.
The temporary chunk catalog is retained so collection failures can be audited.
