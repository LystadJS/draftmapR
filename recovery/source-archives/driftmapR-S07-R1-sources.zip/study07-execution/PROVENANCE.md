# Restored sources

The user supplied two archives locally. They were read from their supplied scratch paths, not re-downloaded or reconstructed from summaries.

| Artifact | SHA256 |
|---|---|
| `driftmapR-S07-D1-specification.zip` | `0b7cae301393812e1c1343f64e90716f0a792bce0a5e209cf8356f648325c2b9` |
| `driftmapR-study06-pinned-runtime.tar.gz` | `a61e14e5815a70cd8d70e1600e2583c10d52c0af59475773934a9843dd7caf2d` |
| S07-D1 immutable freeze | `d8286657a1ec3410e2574f98e08a0a9c98936a987872c32136e579871eb2d85b` |

S07-D1 verifies 352 files, including the original S05/S05-R1 and S06 source and reporting-recovery ancestry. The seed-plan RDS has MD5 `b1689b49d234af0efa0298b7c7bfdfef`. No frozen design or vendored guard was changed. The m=640 population adapter reuses the identical specified population law and changes only the new job's unit-count metadata; it does not weaken old case validators.

Runtime: R 4.5.3, driftmapR 0.0.7.9000, testthat 3.3.2, ggplot2 4.0.3; Python 3.12.14 and NumPy 2.3.5. Exact binaries/numerical libraries and installed estimator files are fingerprinted in the implementation freeze. No package dependency was added.

Earlier scratch sources were not all recoverable. The current S07 implementation was reconstructed against the verified immutable design and ancestry, then revalidated. Historical smoke/test reports are not used as evidence that reconstructed files passed. The final I1 evidence binds this exact source grid. Failed engineering attempts remain outside the frozen tree and are not calibration results.

The restored source package DESCRIPTION is version **0.0.8.9000**; the separately
pinned installed estimator used by S07 remains **0.0.7.9000**. Both are retained
as supplied. A source build/check is reported separately from the pinned-engine
engineering validation; no installation replaced the frozen runtime engine.
