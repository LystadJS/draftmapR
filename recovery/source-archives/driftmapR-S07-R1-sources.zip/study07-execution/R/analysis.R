s07i_cohorts<-function(x){if(!all(c('support_status','screen_status')%in%names(x)))return(list(all=rep(TRUE,nrow(x))));study06r1_cohorts(x)}
s07i_scopes<-function(x){if(!nrow(x))return(x);if(!'budget'%in%names(x)){x$budget<-0L;x$scope<-'budget_independent';return(x)};p<-x[x$budget==x$primary_budget,,drop=FALSE];p$scope<-'primary';e<-x[x$extension_planned,,drop=FALSE];e$scope<-rep('prespecified_budget_subset',nrow(e));s07i_bind(list(p,e))}
s07i_distribution<-function(x){
  z<-x[!is.na(x)];f<-z[is.finite(z)];q<-if(length(z))as.numeric(quantile(z,c(.1,.5,.9,.95),type=7,names=FALSE))else rep(NA_real_,4)
  if(length(z)){a<-sort(z);for(i in seq_along(q))if(is.nan(q[i])){h<-(length(a)-1)*c(.1,.5,.9,.95)[i];lo<-floor(h)+1L;hi<-ceiling(h)+1L;if(identical(a[lo],a[hi]))q[i]<-a[lo]}}
  c(n_planned=length(x),n_available=length(z),n_finite=length(f),n_pos_inf=sum(z==Inf),n_neg_inf=sum(z== -Inf),mean=if(length(z))mean(z)else NA_real_,sd=if(length(z)>1L&&all(is.finite(z)))sd(z)else NA_real_,q10=q[1],median=q[2],q90=q[3],q95=q[4],maximum=if(length(z))max(z)else NA_real_)
}
s07i_coverage<-function(regions,kind='full'){
  regions<-s07i_scopes(regions);keys<-c('case_id','frame','entity','method','scope','budget');rows<-reasons<-tails<-list()
  for(g in study05_analysis_groups(regions,keys))for(cohort in names(s07i_cohorts(g)))for(policy in if(kind=='full')c('original','T1_restricted')else 'diagnostic_original'){
    z<-g[s07i_cohorts(g)[[cohort]],,drop=FALSE];d<-z$delivered
    if(policy=='T1_restricted')d<-d&z$support_status=='eligible'&z$screen_status=='pass'
    if(anyNA(d)||anyNA(z$covered[d])||anyNA(z$rejects_zero[d]))stop('Unknown delivered outcome.')
    M<-nrow(z);D<-sum(d);C<-sum(z$covered[d]);Z<-sum(z$rejects_zero[d])
    base<-data.frame(g[1,keys,drop=FALSE],construction_kind=kind,policy_cohort=cohort,policy=policy,N_unstratified=nrow(g),M=M,D=D,C=C,Z=Z,
      candidate_unknown=if(kind=='full')sum(is.na(z$candidate_region_delivered))else NA_integer_,demonstrated_candidate_nondelivery=if(kind=='full')sum(!z$candidate_region_delivered,na.rm=TRUE)else NA_integer_,
      evaluation_only_blocks=if(kind=='full')sum(z$evaluation_only_block)else NA_integer_,policy_withheld=if(kind=='full')sum(z$support_status!='eligible'|z$screen_status!='pass')else NA_integer_,structurally_inapplicable=if('structurally_applicable'%in%names(z))sum(!z$structurally_applicable)else 0L)
    for(name in c('delivery','coverage','covered_yield','zero_exclusion','detected_yield')){counts<-switch(name,delivery=c(D,M),coverage=c(C,D),covered_yield=c(C,M),zero_exclusion=c(Z,D),detected_yield=c(Z,M));stats<-study05_analysis_prop(counts[1],counts[2]);for(n in names(stats))base[[paste0(name,'_',n)]]<-unname(stats[n])}
    rows[[length(rows)+1L]]<-base;r<-if(kind=='full')z$nondelivery_reason else ifelse(z$delivered,'delivered',z$reason)
    levels<-sort(unique(c('delivered',if(kind=='full')study05_analysis_reasons()else c('influence_unavailable','observed_unavailable','not_applicable_non_gaussian'),r)))
    for(reason in levels)reasons[[length(reasons)+1L]]<-data.frame(base[c(keys,'construction_kind','policy_cohort','policy')],reason=reason,count=sum(r==reason),M=M,definition='Original computational reason; policy withholding is separate.')
    for(metric in c('area_raw','cutoff_raw'))for(selection in c('all','delivered'))tails[[length(tails)+1L]]<-data.frame(base[c(keys,'construction_kind','policy_cohort','policy')],metric=metric,selection=selection,as.list(s07i_distribution(z[[metric]][if(selection=='all')rep(TRUE,M)else d])))
  };list(coverage=s07i_bind(rows),nondelivery=s07i_bind(reasons),tails=s07i_bind(tails))
}
s07i_budget_comparisons<-function(regions){
  x<-regions[regions$extension_planned,,drop=FALSE];keys<-c('case_id','frame','entity','method');out<-pairs<-list()
  for(g in study05_analysis_groups(x,keys)){
    budgets<-sort(unique(g$budget));if(!identical(as.integer(budgets),c(199L,799L)))stop('Paired subset must have both prescribed budgets.')
    low<-g[g$budget==199L,,drop=FALSE];high<-s07i_match(low,g[g$budget==799L,,drop=FALSE],c('case_id','dataset_id','frame','entity','method'))
    for(cohort in names(s07i_cohorts(low)))for(policy in c('original','T1_restricted')){
      use<-s07i_cohorts(low)[[cohort]];a<-low[use,,drop=FALSE];b<-high[use,,drop=FALSE];da<-a$delivered;db<-b$delivered
      if(policy=='T1_restricted'){pass<-a$support_status=='eligible'&a$screen_status=='pass';da<-da&pass;db<-db&pass}
      ca<-da&!is.na(a$covered)&a$covered;cb<-db&!is.na(b$covered)&b$covered;common<-da&db;deltaD<-as.integer(db)-as.integer(da);deltaC<-as.integer(cb)-as.integer(ca)
      base<-data.frame(g[1,keys,drop=FALSE],scope='prespecified_budget_subset',policy_cohort=cohort,policy=policy,B_from=199L,B_to=799L,M=nrow(a),common_delivery=sum(common),delivery_gain=sum(!da&db),delivery_loss=sum(da&!db),coverage_gain_common=sum(!a$covered[common]&b$covered[common]),coverage_loss_common=sum(a$covered[common]&!b$covered[common]))
      for(name in c('delivery_difference','covered_yield_difference','common_coverage_difference','log_area_ratio','log_cutoff_ratio')){
        v<-switch(name,delivery_difference=deltaD,covered_yield_difference=deltaC,common_coverage_difference=as.integer(b$covered[common])-as.integer(a$covered[common]),log_area_ratio=log(b$area[common]/a$area[common]),log_cutoff_ratio=log(b$cutoff[common]/a$cutoff[common]))
        base[[name]]<-if(length(v))mean(v)else NA_real_;base[[paste0(name,'_mcse')]]<-if(length(v)>1&&all(is.finite(v)))sd(v)/sqrt(length(v))else NA_real_
      };out[[length(out)+1L]]<-base
      pairs[[length(pairs)+1L]]<-data.frame(case_id=rep(g$case_id[1],nrow(a)),frame=rep(g$frame[1],nrow(a)),entity=rep(g$entity[1],nrow(a)),method=rep(g$method[1],nrow(a)),dataset_id=a$dataset_id,policy_cohort=rep(cohort,nrow(a)),policy=rep(policy,nrow(a)),B_from=rep(199L,nrow(a)),B_to=rep(799L,nrow(a)),delivered_from=da,delivered_to=db,covered_from=a$covered,covered_to=b$covered,delivery_difference=deltaD,covered_yield_difference=deltaC)
    }
  };list(budget_comparisons=s07i_bind(out),budget_panel_pairs=s07i_bind(pairs))
}
s07i_error_tables<-function(inputs){
  errors<-decomposition<-list();keys<-c('case_id','frame','entity')
  for(g in study05_analysis_groups(inputs,keys))for(cohort in names(s07i_cohorts(g))){
    z<-g[s07i_cohorts(g)[[cohort]],,drop=FALSE];full<-as.matrix(z[c('full_error_dx','full_error_dy')]);linear<-as.matrix(z[c('linear_error_dx','linear_error_dy')]);rem<-full-linear
    ff<-rowSums(!is.finite(full))==0L;lf<-rowSums(!is.finite(linear))==0L;joint<-ff&lf
    base<-data.frame(g[1,keys,drop=FALSE],policy_cohort=cohort,M=nrow(z),N_full=sum(ff),N_linear=sum(lf),N_joint=sum(joint));C<-L<-R<-X<-matrix(NA_real_,2,2)
    if(sum(joint)>=2L){C<-cov(full[joint,,drop=FALSE]);L<-cov(linear[joint,,drop=FALSE]);R<-cov(rem[joint,,drop=FALSE]);X<-cov(linear[joint,,drop=FALSE],rem[joint,,drop=FALSE])}
    diff<-if(sum(joint)>=2L)max(abs(C-L-R-X-t(X)))else NA_real_;if(is.finite(diff)&&diff>1e-9*max(1,max(abs(C))))stop('Covariance decomposition identity failed.')
    for(name in c('full','linear','remainder','cross')){S<-switch(name,full=C,linear=L,remainder=R,cross=X);for(a in 1:2)for(b in 1:2)base[[paste0(name,'_cov_',a,b)]]<-S[a,b]}
    base$identity_max_abs_error<-diff;base$identity_status<-if(sum(joint)>=2L)'verified'else 'insufficient_joint_errors';decomposition[[length(decomposition)+1L]]<-base
    for(which in c('full','linear','remainder'))for(availability in c('own_available','joint')){
      v<-switch(which,full=full,linear=linear,remainder=rem);use<-if(availability=='joint')joint else if(which=='full')ff else if(which=='linear')lf else joint;v<-v[use,,drop=FALSE];n<-nrow(v);bias<-if(n)colMeans(v)else c(NA_real_,NA_real_);S<-if(n>=2L)cov(v)else matrix(NA_real_,2,2)
      errors[[length(errors)+1L]]<-data.frame(g[1,keys,drop=FALSE],policy_cohort=cohort,availability_cohort=availability,estimator=which,M=nrow(z),n=n,bias_dx=bias[1],bias_dy=bias[2],rmse_dx=if(n)sqrt(mean(v[,1]^2))else NA_real_,rmse_dy=if(n)sqrt(mean(v[,2]^2))else NA_real_,euclidean_rmse=if(n)sqrt(mean(rowSums(v^2)))else NA_real_,var_dx=S[1,1],var_dy=S[2,2],cov_dx_dy=S[1,2])
    }
  };list(errors=s07i_bind(errors),error_decomposition=s07i_bind(decomposition))
}
s07i_analyze<-function(tables,out,engineering=FALSE,figures=TRUE){
  dir.create(out,recursive=TRUE,showWarnings=FALSE);answer<-list()
  for(kind in c('full','linear','analytic','normal')){name<-if(kind=='full')'regions'else paste0(kind,'_regions');if(is.data.frame(tables[[name]])&&nrow(tables[[name]])){z<-s07i_coverage(tables[[name]],kind);for(n in names(z))answer[[paste0(kind,'_',n)]]<-z[[n]]}}
  if(is.data.frame(tables$regions)&&nrow(tables$regions))answer<-c(answer,s07i_budget_comparisons(tables$regions),s07i_error_tables(tables$decomposition_inputs),s07i_covariance_analysis(tables$covariance_inputs),s07i_selection_analysis(tables))
  for(n in names(answer))write.csv(answer[[n]],file.path(out,paste0(gsub('_','-',n),'.csv')),row.names=FALSE,na='NA')
  saveRDS(answer,file.path(out,'analysis-results.rds'),version=2);if(figures)s07i_figures(answer,tables,out,engineering);answer
}
