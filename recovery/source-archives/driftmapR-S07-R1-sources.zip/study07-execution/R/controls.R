s07i_ellipse<-function(point,S,truth,cutoff,method){
  status<-study03_covariance_status(S);point_ok<-length(point)==2L&&all(is.finite(point));truth_ok<-length(truth)==2L&&all(is.finite(truth))
  area_raw<-if(status$valid)pi*cutoff*status$determinant_root else NA_real_
  out<-data.frame(method=method,center_dx=point[1],center_dy=point[2],truth_dx=truth[1],truth_dy=truth[2],var_dx=S[1,1],var_dy=S[2,2],cov_dx_dy=S[1,2],
    cutoff=cutoff,cutoff_raw=cutoff,area=NA_real_,area_raw=area_raw,truth_statistic=NA_real_,null_statistic=NA_real_,available=FALSE,delivered=FALSE,covered=NA,rejects_zero=NA,
    reason=if(!point_ok)'observed_unavailable'else if(!truth_ok)'truth_unavailable'else if(!status$valid)status$reason else 'region_geometry_unavailable')
  if(!point_ok||!truth_ok||!status$valid)return(out)
  ts<-study03_quadratic_spectrum(truth-point,status);ns<-study03_quadratic_spectrum(-point,status);out$truth_statistic<-ts;out$null_statistic<-ns
  if(!all(is.finite(c(ts,ns,cutoff,area_raw)))||cutoff<=0||area_raw<=0)return(out)
  out$available<-out$delivered<-TRUE;out$area<-area_raw;out$reason<-'ok';out$covered<-ts<=cutoff*(1+1e-12);out$rejects_zero<-ns>cutoff*(1+1e-12);out
}
s07i_mean_path<-function(values,truth,weights,job,construction,entity,hooks=list()){
  s07i_hooks(job,hooks)
  if(!is.matrix(values)||!identical(dim(values),c(job$m,2L))||!is.matrix(weights)||!identical(dim(weights),c(job$B_planned,job$m)))stop('Invalid control dimensions.')
  finite<-all(is.finite(values));B<-job$B_planned;parents<-covariances<-vector('list',B+1L);observed_mean<-if(finite)colMeans(values)else c(NA_real_,NA_real_)
  for(b in 0:B){
    w<-if(b==0L)rep(1L,job$m)else as.numeric(weights[b,]);ctx<-list(parent_id=b,entity=entity,construction=construction)
    z<-if(finite)study03_capture({a<-s07_linear_covariance(values,w);if(!is.null(hooks$covariance))a$jackknife<-hooks$covariance(ctx,a$jackknife);a})else list(ok=FALSE,stage='influence_unavailable',message='Population influence unavailable.',warnings='')
    mean<-if(finite)colSums(values*w)/job$m else c(NA_real_,NA_real_);S<-if(z$ok)z$value$jackknife else matrix(NA_real_,2,2);cond<-if(z$ok)z$value$conditional_bootstrap else matrix(NA_real_,2,2)
    status<-study03_covariance_status(S);pivot_attempted<-b>0L&&finite&&status$valid
    pivot<-if(pivot_attempted)study03_capture({p<-study03_quadratic(mean-observed_mean,S);if(!is.null(hooks$pivot))p<-hooks$pivot(ctx,p);p})else NULL
    raw<-if(!is.null(pivot)&&pivot$ok)pivot$value else NA_real_;ok<-pivot_attempted&&!is.null(pivot)&&pivot$ok&&length(raw)==1L&&is.finite(raw)&&raw>=0
    parents[[b+1L]]<-data.frame(case_id=job$case_id,dataset_id=job$dataset_id,entity=entity,construction=construction,parent_id=b,m=job$m,point_available=finite,dx=truth[1]+mean[1],dy=truth[2]+mean[2],
      covariance_required=TRUE,covariance_attempted=finite,covariance_ok=z$ok&&status$valid,covariance_reason=if(!z$ok)z$stage else status$reason,
      var_dx=S[1,1],var_dy=S[2,2],cov_dx_dy=S[1,2],conditional_var_dx=cond[1,1],conditional_var_dy=cond[2,2],conditional_cov_dx_dy=cond[1,2],
      pivot_required=b>0L,pivot_attempted=pivot_attempted,pivot_ok=ok,pivot=if(ok)raw else NA_real_,pivot_raw=raw,
      message=if(!z$ok)z$message else if(!is.null(pivot)&&!pivot$ok)pivot$message else '',warnings=z$warnings,distinct_units=sum(w>0),max_multiplicity=max(w),required_unique=sum(w>0),required_occurrences=sum(w))
    covariances[[b+1L]]<-S
  }
  list(parents=s07i_bind(parents),covariances=covariances,observed=truth+observed_mean,truth=truth,values=values,construction=construction,entity=entity)
}
s07i_mean_regions<-function(path,job,normal=FALSE){
  rows<-list();point<-path$observed;S<-path$covariances[[1L]];parents<-path$parents
  for(B in s07i_budget_views(job)){
    pivots<-parents$pivot[parents$parent_id>0L&parents$parent_id<=B&parents$pivot_ok]
    z<-study03_studentized_region(if(all(is.finite(point)))point else c(0,0),S,pivots,path$truth,as.integer(B));z<-z[z$method=='jackknife_studentized',,drop=FALSE]
    z$method<-if(normal)'normal_bootstrap_studentized'else 'linear_studentized';z$center_dx<-point[1];z$center_dy<-point[2]
    if(!all(is.finite(point))){z$available<-z$delivered<-FALSE;z$covered<-z$rejects_zero<-NA;z$reason<-'influence_unavailable'}
    z$cutoff_raw<-if(length(pivots)>=20L)as.numeric(quantile(pivots,.95,type=7,names=FALSE))else NA_real_;status<-study03_covariance_status(S);z$area_raw<-if(status$valid)pi*z$cutoff_raw*status$determinant_root else NA_real_
    if(normal)z<-s07i_bind(list(s07i_ellipse(point,S,path$truth,s07_hotelling_cutoff(job$m),'normal_hotelling'),s07i_ellipse(point,S,path$truth,qchisq(.95,2),'normal_chisquare_wald'),z))
    z$case_id<-job$case_id;z$dataset_id<-job$dataset_id;z$m<-job$m;z$budget<-B;z$entity<-path$entity;z$frame<-if(normal)'normal_mean'else 'population_linear'
    z$truth_dx<-path$truth[1];z$truth_dy<-path$truth[2];z$construction<-path$construction;z$diagnostic_only<-!normal;z$observed_available<-all(is.finite(point));z$pivot_n<-length(pivots);z$required_valid_pivots<-max(20L,ceiling(.95*B));rows[[length(rows)+1L]]<-z
  };s07i_bind(rows)
}
s07i_linear<-function(job,generated,reference,plan,hooks=list()){
  influences<-s07i_influences(generated,reference);ids<-reference$model$target_ids
  paths<-lapply(seq_along(ids),function(j)s07i_mean_path(influences$psi[[j]],as.numeric(reference$model$truth[j,]),plan$weights,job,'population_linear',ids[j],hooks))
  units<-s07i_bind(lapply(seq_along(ids),function(j)data.frame(case_id=job$case_id,dataset_id=job$dataset_id,entity=ids[j],unit_id=seq_len(job$m),psi_dx=influences$psi[[j]][,1],psi_dy=influences$psi[[j]][,2],influence_available=reference$derivative$available[j],reason=reference$derivative$status[j])))
  list(paths=paths,units=units,parents=s07i_bind(lapply(paths,`[[`,'parents')),regions=s07i_bind(lapply(paths,s07i_mean_regions,job=job)),h=influences$h)
}
s07i_normal<-function(job,case=s07i_case(job),generated=NULL,plan=NULL,identity=NULL,hooks=list()){
  s07i_validate_job(job,case,identity);s07i_hooks(job,hooks);if(is.null(generated))generated<-s07i_generate(job,case,identity);if(is.null(plan))plan<-s07i_draws(job,case,identity)
  path<-s07i_mean_path(generated$Y,c(0,0),plan$weights,job,'normal_mean','mean',hooks)
  list(job=job,case=case,generated=generated,plan=plan,path=path,regions=s07i_mean_regions(path,job,TRUE),units=data.frame(case_id=job$case_id,dataset_id=job$dataset_id,unit_id=seq_len(job$m),y1=generated$Y[,1],y2=generated$Y[,2]),parents=path$parents)
}
