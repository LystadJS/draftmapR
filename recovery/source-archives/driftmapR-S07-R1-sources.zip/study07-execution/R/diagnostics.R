s07i_cov3<-function(S)c(var_dx=S[1,1],var_dy=S[2,2],cov_dx_dy=S[1,2])
s07i_ratio<-function(A,S){st<-study03_covariance_status(S);if(!st$valid||any(!is.finite(A)))return(c(trace=NA_real_,minimum=NA_real_,maximum=NA_real_));W<-sweep(st$eigenvectors,2,sqrt(st$eigenvalues),'/');v<-eigen(crossprod(W,A%*%W),symmetric=TRUE,only.values=TRUE)$values;c(trace=sum(diag(A))/sum(diag(S)),minimum=v[2],maximum=v[1])}
s07i_cov_stats<-function(x){
  n<-nrow(x);S<-if(n>=2L)cov(as.matrix(x[c('error_dx','error_dy')]))else matrix(NA_real_,2,2);A<-if(n)matrix(c(mean(x$var_dx),mean(x$cov_dx_dy),mean(x$cov_dx_dy),mean(x$var_dy)),2)else matrix(NA_real_,2,2)
  stat<-c(setNames(s07i_cov3(S),paste0('empirical_',names(s07i_cov3(S)))),setNames(s07i_cov3(A),paste0('estimated_',names(s07i_cov3(A)))))
  add<-function(v,prefix){stat<<-c(stat,setNames(v,paste0(prefix,names(v))))};add(s07i_ratio(A,S),'estimated_to_empirical_')
  for(kind in c('iid','dependence')){fields<-paste0('oracle_',kind,c('_xx','_yy','_xy'));ok<-n>0L&&all(is.finite(as.matrix(x[fields])));O<-if(ok){v<-colMeans(x[fields]);matrix(c(v[1],v[3],v[3],v[2]),2)}else matrix(NA_real_,2,2);add(s07i_ratio(A,O),paste0('estimated_to_oracle_',kind,'_'));add(s07i_ratio(S,O),paste0('empirical_to_oracle_',kind,'_'))}
  se<-study03_covariance_status(S);ae<-study03_covariance_status(A);orientation<-NA_real_
  if(se$valid&&ae$valid&&diff(rev(se$eigenvalues))>1e-8*se$eigenvalues[1]&&diff(rev(ae$eigenvalues))>1e-8*ae$eigenvalues[1])orientation<-acos(min(1,abs(sum(se$eigenvectors[,1]*ae$eigenvectors[,1]))))*180/pi
  stat<-c(stat,empirical_eigenvalue_max=se$eigenvalues[1],empirical_eigenvalue_min=se$eigenvalues[2],estimated_eigenvalue_max=ae$eigenvalues[1],estimated_eigenvalue_min=ae$eigenvalues[2],orientation_degrees=orientation)
  list(values=stat,status=if(n<2L)'insufficient_matched_errors'else if(!se$valid)'empirical_covariance_not_spd'else 'available')
}
s07i_covariance_analysis<-function(inputs){
  rows<-deletions<-variability<-list();keys<-c('case_id','frame','entity','covariance_source','scope','budget')
  for(g in study05_analysis_groups(inputs,keys))for(cohort in names(s07i_cohorts(g))){
    in_cohort<-s07i_cohorts(g)[[cohort]];finite<-rowSums(!is.finite(as.matrix(g[c('error_dx','error_dy','var_dx','var_dy','cov_dx_dy')])))==0L;z<-g[in_cohort&finite,,drop=FALSE];n<-nrow(z);st<-s07i_cov_stats(z)
    base<-data.frame(g[1,keys,drop=FALSE],policy_cohort=cohort,M=nrow(g),N_in_cohort=sum(in_cohort),n_matched=n,n_covariance_finite=sum(in_cohort&rowSums(!is.finite(as.matrix(g[c('var_dx','var_dy','cov_dx_dy')])))==0L),status=st$status,as.list(st$values))
    ratio_names<-grep('_to_',names(st$values),value=TRUE);loo<-matrix(NA_real_,n,length(ratio_names),dimnames=list(NULL,ratio_names))
    for(i in seq_len(n)){
      attempted<-n>=20L;a<-if(attempted)s07i_cov_stats(z[-i,,drop=FALSE])else list(values=setNames(rep(NA_real_,length(st$values)),names(st$values)),status='n_below_20');loo[i,]<-a$values[ratio_names]
      deletions[[length(deletions)+1L]]<-data.frame(g[1,keys,drop=FALSE],policy_cohort=cohort,deleted_dataset_id=z$dataset_id[i],required=TRUE,attempted=attempted,status=a$status,successful=attempted&&a$status=='available',failed_after_attempt=attempted&&a$status!='available',unattempted_required=!attempted,n_original=n,n_remaining=n-1L,as.list(a$values[ratio_names]))
    }
    for(name in ratio_names){available<-n>=20L&&is.finite(st$values[name])&&all(is.finite(loo[,name]));base[[paste0(name,'_mcse')]]<-if(available)sqrt((n-1)/n*sum((loo[,name]-mean(loo[,name]))^2))else NA_real_;base[[paste0(name,'_mcse_status')]]<-if(n<20L)'n_below_20'else if(!is.finite(st$values[name]))'base_ratio_unavailable'else if(!all(is.finite(loo[,name])))'required_deletion_unavailable'else 'available'}
    base$n_outer_required<-n;base$n_outer_attempted<-if(n>=20L)n else 0L;rows[[length(rows)+1L]]<-base;selected<-g[in_cohort,,drop=FALSE]
    for(metric in c('var_dx','var_dy','cov_dx_dy','trace'))variability[[length(variability)+1L]]<-data.frame(g[1,keys,drop=FALSE],policy_cohort=cohort,metric=metric,as.list(s07i_distribution(if(metric=='trace')selected$var_dx+selected$var_dy else selected[[metric]])))
  };list(covariance=s07i_bind(rows),covariance_outer_deletions=s07i_bind(deletions),covariance_variability=s07i_bind(variability))
}
s07i_panel_tables<-function(result){
  job<-result$job;if(job$pipeline=='normal_mean_control'){r<-result$normal$regions;r$primary_budget<-job$B_primary;r$extension_planned<-job$extension;return(list(normal_regions=r))}
  full<-result$full;linear<-result$linear;reference<-result$reference;t<-s07i_full_tables(full)
  for(n in names(t))if('budget'%in%names(t[[n]])){t[[n]]$primary_budget<-job$B_primary;t[[n]]$extension_planned<-job$extension}
  t$linear_regions<-s07i_decorate_policy(linear$regions,full$s07_screen);t$linear_regions$primary_budget<-job$B_primary;t$linear_regions$extension_planned<-job$extension;t$analytic_regions<-s07i_analytic_regions(job,full,linear,reference)
  l<-s07i_decorate_policy(linear$parents[linear$parents$parent_id==0L,,drop=FALSE],full$s07_screen);l$truth_dx<-reference$model$truth[,1];l$truth_dy<-reference$model$truth[,2];l$frame<-'population_linear';t$linear_points<-l
  inputs<-t$estimates;i<-match(inputs$entity,l$entity);inputs$full_error_dx<-inputs$dx-inputs$truth_dx;inputs$full_error_dy<-inputs$dy-inputs$truth_dy;inputs$linear_error_dx<-l$dx[i]-inputs$truth_dx;inputs$linear_error_dy<-l$dy[i]-inputs$truth_dy;inputs$remainder_dx<-inputs$full_error_dx-inputs$linear_error_dx;inputs$remainder_dy<-inputs$full_error_dy-inputs$linear_error_dy;t$decomposition_inputs<-inputs
  r<-s07i_scopes(t$regions[t$regions$method%in%c('wald','jackknife_wald'),,drop=FALSE]);r$covariance_source<-ifelse(r$method=='wald','bootstrap_covariance','full_occurrence_covariance');r$error_dx<-r$center_dx-r$truth_dx;r$error_dy<-r$center_dy-r$truth_dy
  l$covariance_source<-'linear_occurrence_covariance';l$scope<-'budget_independent';l$budget<-0L;l$error_dx<-l$dx-l$truth_dx;l$error_dy<-l$dy-l$truth_dy
  a<-t$analytic_regions;a$covariance_source<-a$method;a$scope<-'budget_independent';a$budget<-0L;a$error_dx<-a$center_dx-a$truth_dx;a$error_dy<-a$center_dy-a$truth_dy
  common<-c('case_id','dataset_id','frame','entity','covariance_source','scope','budget','error_dx','error_dy','var_dx','var_dy','cov_dx_dy','support_status','screen_status');cv<-s07i_bind(list(r[common],l[common],a[common]))
  for(kind in c('iid','dependence')){factor<-if(kind=='iid')1 else s07i_dependence_factor(job$m,full$case$rho_unit);om<-lapply(reference$Omega,function(S)S/job$m*factor);j<-match(cv$entity,reference$model$target_ids);for(coord in c('xx','yy','xy'))cv[[paste0('oracle_',kind,'_',coord)]]<-vapply(j,function(k)switch(coord,xx=om[[k]][1,1],yy=om[[k]][2,2],xy=om[[k]][1,2]),numeric(1))}
  t$covariance_inputs<-cv;t$derivative_status<-reference$derivative;t
}
s07i_selection_analysis<-function(tables){
  summaries<-counts<-sparse<-tails<-list();p<-tables$selection_panel
  for(g in study05_analysis_groups(p,c('case_id','frame','entity','budget','metric','contrast')))for(cohort in names(s07i_cohorts(g))){z<-g[s07i_cohorts(g)[[cohort]],,drop=FALSE];for(metric in c('baseline_mean','selected_mean','failed_mean','difference','selected_minus_failed')){v<-z[[metric]];ok<-is.finite(v);summaries[[length(summaries)+1L]]<-data.frame(g[1,c('case_id','frame','entity','budget','metric','contrast'),drop=FALSE],policy_cohort=cohort,summary_metric=metric,M=nrow(g),N_in_cohort=nrow(z),n_finite=sum(ok),mean=if(any(ok))mean(v[ok])else NA_real_,mcse=if(sum(ok)>1L)sd(v[ok])/sqrt(sum(ok))else NA_real_)}}
  for(g in study05_analysis_groups(tables$regions,c('case_id','frame','entity','method','budget'))){if(all(g$rare_bin=='not_sparse'))next;for(bin in c('0','1','2','3','4+')){z<-g[g$rare_bin==bin,,drop=FALSE];d<-z$delivered;sparse[[length(sparse)+1L]]<-data.frame(g[1,c('case_id','frame','entity','method','budget'),drop=FALSE],rare_bin=bin,M=nrow(g),N_in_bin=nrow(z),D=sum(d),C=sum(z$covered[d]),observed_available=sum(z$observed_success),evaluation_only_blocks=sum(z$evaluation_only_block),policy_withheld=sum(z$support_status!='eligible'|z$screen_status!='pass'))}}
  for(g in study05_analysis_groups(tables$decomposition_inputs,c('case_id','frame','entity')))for(cohort in names(s07i_cohorts(g))){z<-g[s07i_cohorts(g)[[cohort]],,drop=FALSE];tails[[length(tails)+1L]]<-data.frame(g[1,c('case_id','frame','entity'),drop=FALSE],policy_cohort=cohort,metric='remainder_norm',as.list(s07i_distribution(sqrt(z$remainder_dx^2+z$remainder_dy^2))))}
  for(g in study05_analysis_groups(tables$geometry_panel,c('case_id','budget','kind','role','stage','period','parent_kind','metric')))for(cohort in names(s07i_cohorts(g))){z<-g[s07i_cohorts(g)[[cohort]],,drop=FALSE];counts[[length(counts)+1L]]<-data.frame(g[1,c('case_id','budget','kind','role','stage','period','parent_kind','metric'),drop=FALSE],policy_cohort=cohort,M=nrow(g),N_in_cohort=nrow(z),n_attempted=sum(z$n_attempted),n_successful=sum(z$n_successful),n_failed_after_attempt=sum(z$n_failed_after_attempt),n_unattempted=sum(z$n_unattempted),mean=study05_analysis_mean(z$mean),mean_mcse=study05_analysis_se(z$mean),maximum=if(any(is.finite(z$maximum)))max(z$maximum[is.finite(z$maximum)])else NA_real_)}
  frame<-study05_panel_diagnostic_summary(tables$frame_variation_panel,c('case_id','budget','metric'),c('mean','q95','maximum','n_finite'))
  list(selection=s07i_bind(summaries),sparse_delivery=s07i_bind(sparse),remainder_tails=s07i_bind(tails),geometry=s07i_bind(counts),frame_variation=frame)
}
