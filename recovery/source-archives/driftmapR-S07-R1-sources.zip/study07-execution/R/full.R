s07i_full<-function(job,case=s07i_case(job),generated=NULL,plan=NULL,identity=NULL,keep_values=FALSE,hooks=list()){
  s07i_validate_job(job,case,identity);s07i_hooks(job,hooks);if(is.null(generated))generated<-s07i_generate(job,case,identity);if(is.null(plan))plan<-s07i_draws(job,case,identity)
  z<-study05_one(job,case,generated,B=job$B_planned,keep_inner_values=keep_values,hooks=hooks[intersect(names(hooks),c('fit','projector','covariance','quadratic'))],oracle_register=hooks$oracle_register,evaluation_register=hooks$evaluation_register)
  if(!identical(unname(z$weights),unname(plan$weights))||!identical(unname(z$streams),unname(plan$streams)))stop('Full estimator differs from pre-materialized draw plan.')
  z$s07_screen<-s06_observed_policy(z);z
}
s07i_prefix<-function(result,B){
  if(length(B)!=1L||!B%in%s07i_budget_views(result$job))stop('Unprescribed budget.')
  trim<-function(z){
    z$B<-as.integer(B);z$case$B<-as.integer(B)
    for(n in c('weights','streams','pivots'))z[[n]]<-z[[n]][seq_len(B),,drop=FALSE]
    for(n in intersect(c('values','eval_values','rotations'),names(z)))z[[n]]<-z[[n]][seq_len(B),,,drop=FALSE]
    z$inner<-z$inner[seq_len(B)];z$attempts<-z$attempts[z$attempts$replicate_id<=B,,drop=FALSE];z$studentization<-z$studentization[z$studentization$replicate_id<=B,,drop=FALSE]
    tables<-study03_tables(z);z[names(tables)]<-tables
    # Recompute B-dependent delivery metadata; copying it from B799 is invalid.
    r<-z$regions
    r$observed_core_fit_available<-result$observed_core_fit_available
    r$evaluation_registration_available<-result$evaluation_registration_available
    r$evaluation_only_block<-result$evaluation_only_block
    r$candidate_region_delivered<-if(result$evaluation_only_block)rep(NA,nrow(r))else r$delivered
    r$study_evaluable_region_delivered<-r$delivered;r$studentized_nondelivery_reason<-NA_character_
    for(j in seq_along(z$model_metadata$target_ids)) {
      at<-which(r$entity==z$model_metadata$target_ids[j]&r$method=='jackknife_studentized')
      r$studentized_nondelivery_reason[at]<-study05_nondelivery(z$observed_success,z$observed_jackknife$all_required_success,z$observed_jackknife$covariance_ok[j],sum(is.finite(z$pivots[,j])),B=B,geometry_ok=isTRUE(r$available[at]))
    }
    z$regions<-r
    z$outer$B<-B;z$outer$n_full_attempted<-sum(z$attempts$attempted);z$outer$n_full_success<-sum(z$attempts$success)
    for(n in c('required','attempted','success')){field<-switch(n,required='n_planned_unique',attempted='n_attempted_unique',success='n_successful_unique');z$outer[[paste0('inner_jackknife_',n)]]<-sum(vapply(z$inner,`[[`,numeric(1),field))};z
  }
  z<-trim(result);z$frame<-trim(result$frame)
  for(n in c('embedding','registration'))z$geometry[[n]]<-z$geometry[[n]][z$geometry[[n]]$parent_id<=B,,drop=FALSE]
  z
}
s07i_decorate_policy<-function(table,screen){
  if(!nrow(table))return(table)
  for(n in setdiff(names(screen),c('case_id','dataset_id','m')))table[[n]]<-screen[[n]][1L]
  if(all(c('candidate_region_delivered','delivered','evaluation_only_block','nondelivery_reason','covered')%in%names(table))){
    z<-s07i_bind(lapply(seq_len(nrow(table)),function(i)study06_delivery(table$candidate_region_delivered[i],table$delivered[i],table$evaluation_only_block[i],table$nondelivery_reason[i],screen$support_status[1L],screen$screen_status[1L],table$covered[i])))
    for(n in names(z))table[[n]]<-z[[n]]
  };table
}
s07i_full_tables<-function(result){
  views<-list()
  for(B in s07i_budget_views(result$job)){
    z<-s07i_prefix(result,B);t<-study05_analysis_extract(z)
    t<-lapply(t,function(x){x<-s07i_decorate_policy(x,result$s07_screen);x$budget<-rep(B,nrow(x));x})
    t$regions$cutoff_raw<-t$regions$cutoff;t$regions$area_raw<-t$regions$area
    for(i in seq_len(nrow(t$regions))){
      r<-t$regions[i,,drop=FALSE];fr<-if(r$frame=='core')z else z$frame;j<-match(r$entity,z$model_metadata$target_ids)
      if(r$method=='jackknife_studentized'){p<-fr$pivots[,j];p<-p[is.finite(p)];t$regions$cutoff_raw[i]<-if(length(p)>=20L)as.numeric(quantile(p,.95,type=7,names=FALSE))else NA_real_}else if(r$method%in%c('wald','jackknife_wald'))t$regions$cutoff_raw[i]<-qchisq(.95,2)
      if(r$method%in%c('bootstrap_ball','bootstrap_mahalanobis')){
        v<-matrix(fr$eval_values[,j,],ncol=2);good<-rowSums(!is.finite(v))==0L
        if(sum(good)>=20L&&all(is.finite(c(r$center_dx,r$center_dy)))){
          err<-sweep(v[good,,drop=FALSE],2,c(r$center_dx,r$center_dy),'-')
          if(r$method=='bootstrap_ball'){radius<-as.numeric(quantile(sqrt(rowSums(err^2)),.95,type=7,names=FALSE));t$regions$cutoff_raw[i]<-radius;t$regions$area_raw[i]<-pi*radius^2}else{
            status<-study03_covariance_status(cov(v[good,,drop=FALSE]));if(status$valid)t$regions$cutoff_raw[i]<-as.numeric(quantile(apply(err,1,function(e)study03_quadratic_spectrum(e,status)),.95,type=7,names=FALSE))
          }
        }
      }
      if(r$method!='bootstrap_ball'){S<-matrix(c(r$var_dx,r$cov_dx_dy,r$cov_dx_dy,r$var_dy),2);status<-study03_covariance_status(S);t$regions$area_raw[i]<-if(status$valid)pi*t$regions$cutoff_raw[i]*status$determinant_root else NA_real_}
    };views[[as.character(B)]]<-t
  }
  out<-lapply(names(views[[1L]]),function(n){if(n%in%c('estimates','observed_geometry','clean_points')){z<-views[[1L]][[n]];z$budget<-z$B<-NULL;z}else s07i_bind(lapply(views,`[[`,n))});names(out)<-names(views[[1L]]);out$screen<-result$s07_screen;out
}
s07i_analytic_regions<-function(job,full,linear,reference){
  rows<-list();ids<-reference$model$target_ids;variants<-c(iid=1,if(full$case$rho_unit>0)c(dependence=s07i_dependence_factor(job$m,full$case$rho_unit)))
  for(j in seq_along(ids))for(frame in c('core','population_frame_oracle','population_linear'))for(v in names(variants)){
    point<-if(frame=='population_linear')linear$paths[[j]]$observed else if(frame=='core')full$estimate[j,]else full$frame$estimate[j,]
    z<-s07i_ellipse(as.numeric(point),reference$Omega[[j]]/job$m*variants[[v]],as.numeric(reference$model$truth[j,]),qchisq(.95,2),paste0('analytic_',v))
    z$case_id<-job$case_id;z$dataset_id<-job$dataset_id;z$m<-job$m;z$entity<-ids[j];z$frame<-frame;z$construction<-paste0('analytic_',v);z$diagnostic_only<-TRUE;z$dependence_multiplier<-variants[[v]]
    z$structurally_applicable<-full$case$scenario!='rare_axis';z$oracle_status<-reference$derivative$omega_status[j]
    if(!z$structurally_applicable)z$reason<-'not_applicable_non_gaussian'else if(!reference$derivative$omega_available[j])z$reason<-z$oracle_status
    rows[[length(rows)+1L]]<-s07i_decorate_policy(z,full$s07_screen)
  };s07i_bind(rows)
}
