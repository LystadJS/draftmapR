s07i_parent_case<-function(case){p<-study05_cases();i<-if(case$scenario=='rare_axis')which(p$scenario=='rare_axis')else which(p$scenario=='gapped_gaussian'&p$g==case$g&p$a==case$a&p$m==(if(case$m==640L)160L else case$m)&p$focal_motion==case$focal_motion&p$rho_unit==case$rho_unit);if(length(i)!=1L)stop('No unique inherited population.');p[i,,drop=FALSE]}
s07i_model<-function(case){z<-study05_model(s07i_parent_case(case));z$case<-case;z$scenario$m<-case$m;z}
s07i_generate<-function(job,case=s07i_case(job),identity=NULL){
  s07i_validate_job(job,case,identity)
  if(job$pipeline=='normal_mean_control')return(study05_preserve_rng({assign('.Random.seed',job$data_stream,.GlobalEnv);S<-matrix(c(1,.3,.3,2),2);list(Y=matrix(rnorm(job$m*2L),job$m,2L)%*%chol(S),sigma=S,truth=c(0,0),unit_ids=seq_len(job$m))}))
  model<-s07i_model(case)
  if(case$scenario=='rare_axis'){z<-study03_generate(job,s07i_parent_case(case));z$model<-model;z$contract<-model$contract;return(z)}
  study05_preserve_rng({
    assign('.Random.seed',job$data_stream,.GlobalEnv);n<-length(model$ids);m<-job$m;s<-study05_settings()
    innovations<-list(loadings=matrix(rnorm(3L*m),3L,m),noise_first=matrix(rnorm(n*m),n,m),noise_second=matrix(rnorm(n*m),n,m))
    loadings<-study05_ar1_units(innovations$loadings,case$rho_unit);n1<-study05_ar1_units(innovations$noise_first,case$rho_unit)
    n2<-s$rho_time*n1+sqrt(1-s$rho_time^2)*study05_ar1_units(innovations$noise_second,case$rho_unit)
    features<-sprintf('f%03d',seq_len(m));noise<-list(n1,n2)
    X<-lapply(1:2,function(t){z<-model$H%*%(model$layout$latent[[t]]%*%loadings+s$sigma*noise[[t]]);dimnames(z)<-list(model$ids,features);z})
    data<-do.call(rbind,lapply(1:2,function(t)data.frame(entity=model$ids,time=t,X[[t]],check.names=FALSE)));rownames(data)<-NULL
    list(data=data,features=features,unit_map=setNames(sprintf('unit%03d',seq_len(m)),features),rare=setNames(rep(FALSE,m),features),rare_count=NA_integer_,layout=model$layout,model=model,X=X,loadings=loadings,noise=noise,innovations=innovations,contract=model$contract)
  })
}
s07i_draws<-function(job,case=s07i_case(job),identity=NULL){s07i_validate_job(job,case,identity);z<-study05_materialize_draws(job,case);if(!identical(dim(z$weights),c(job$B_planned,job$m))||any(rowSums(z$weights)!=job$m))stop('Incorrect draw dimensions.');z$weights_md5<-study05_object_md5(z$weights);z$streams_md5<-study05_object_md5(z$streams);z}
