s07i_paths<-local({v<-NULL;function(execution=NULL,specification=NULL){if(!is.null(execution))v<<-list(execution=normalizePath(execution),specification=normalizePath(specification));if(is.null(v))stop('Load S07 first.');v}})
s07i_jobs<-function()readRDS(file.path(s07i_paths()$specification,'design/seed-plan.rds'))
s07i_source_files<-function(){x<-sort(list.files(s07i_paths()$execution,recursive=TRUE,pattern='\\.(R|py)$'));x[grepl('^(R|scripts|tests)/',x)]}
s07i_verify_design<-function(){
  p<-s07i_paths()$specification;ans<-system2('python3',c(shQuote(file.path(p,'scripts/freeze.py')),'verify'),stdout=TRUE,stderr=TRUE)
  if(!is.null(attr(ans,'status')))stop(paste(ans,collapse='\n'))
  z<-jsonlite::fromJSON(tail(ans,1))
  if(z$freeze_sha256!='d8286657a1ec3410e2574f98e08a0a9c98936a987872c32136e579871eb2d85b'||!identical(s07i_jobs(),s07_jobs()))stop('Wrong or altered D1.')
  list(design='S07-D1',freeze_sha256=z$freeze_sha256,seed_plan_md5=study05_md5(file.path(p,'design/seed-plan.rds')))
}
s07i_runtime<-function(){
  z<-s05r1_runtime();p<-find.package('driftmapR');f<-sort(list.files(p,recursive=TRUE,all.files=TRUE,no..=TRUE))
  if(as.character(packageVersion('driftmapR'))!='0.0.7.9000')stop('Wrong engine.')
  z$engine_files<-f;z$engine_md5<-unname(study05_md5(file.path(p,f)))
  py<-system2('python3',shQuote(file.path(s07i_paths()$execution,'scripts/runtime.py')),stdout=TRUE,stderr=TRUE)
  if(!is.null(attr(py,'status')))stop('Independent audit runtime unavailable.')
  z$python<-jsonlite::fromJSON(paste(py,collapse='\n'));z
}
s07i_context<-local({v<-NULL;function(set=NULL){if(!is.null(set))v<<-set;v}})
s07i_verify_implementation<-function(){
  p<-s07i_paths()$execution;f<-file.path(p,'implementation-freeze.rds')
  if(!file.exists(f))stop('S07-I1 is not frozen; reserved generation forbidden.')
  z<-readRDS(f);actual<-sort(list.files(p,recursive=TRUE,all.files=TRUE,no..=TRUE));actual<-setdiff(actual,c('implementation-freeze.rds','implementation-freeze.json'))
  if(z$freeze_id!='S07-I1'||!isTRUE(z$ready_for_reserved)||z$reserved_measurement_panels_generated!=0L||z$reserved_bootstrap_weight_vectors_generated!=0L)stop('Invalid freeze.')
  if(!identical(z$design,s07i_verify_design())||!identical(z$runtime,s07i_runtime()))stop('Design/runtime changed.')
  if(!identical(actual,z$files)||!identical(unname(study05_md5(file.path(p,actual))),z$md5)||!identical(study05_md5(file.path(p,'implementation-freeze.json')),z$json_md5))stop('Frozen file grid or bytes changed.')
  identity<-list(study='S07',design=z$design,implementation_md5=study05_md5(f),runtime=z$runtime)
  jobs<-s07i_jobs();names(jobs)<-vapply(jobs,s07i_key,character(1));s07i_context(list(identity=identity,jobs=jobs));identity
}
s07i_case<-function(job){
  if(job$pipeline=='normal_mean_control')return(data.frame(case_index=job$case_index,case_id=job$case_id,scenario='normal_mean',g=NA_real_,a=0,m=job$m,M=2000L,B=job$B_planned,focal_motion=FALSE,rho_unit=0,role='normal_mean_control',extension_n=0L,movement_scale=0,target_regime='null',contract='iid_units_nominal_contract'))
  z<-s07_cases()[match(job$case_index,s07_cases()$case_index),,drop=FALSE]
  if(nrow(z)!=1L||is.na(z$case_id))stop('Unknown S07 case.')
  z$B<-job$B_planned;z$movement_scale<-if(z$focal_motion).2 else 0;z$target_regime<-if(z$focal_motion)'focal_movement' else if(z$a>0)'anchor_change' else 'null'
  z$contract<-if(z$rho_unit>0)'dependence_stress_outside_iid_contract' else 'iid_units_nominal_contract';rownames(z)<-NULL;z
}
s07i_fixture<-function(case_index=1L,B=21L){
  if(length(case_index)!=1L||!case_index%in%c(1:9,101:103)||length(B)!=1L||!is.finite(B)||B<1||B>799||B!=floor(B))stop('Invalid fixture.')
  normal<-case_index>=101L;m<-if(normal)c(40L,160L,640L)[case_index-100L]else s07_cases()$m[case_index]
  job<-list(case_id=if(normal)paste0('s07_normal_mean_m',m)else s07_cases()$case_id[case_index],case_index=as.integer(case_index),dataset_id=999L,m=m,B_planned=as.integer(B),B_primary=as.integer(min(199L,B)),extension=B>199L,pipeline=if(normal)'normal_mean_control'else 'full_estimator',data_stream=study05_seed_state(781L),bootstrap_seed=781L,stage='s07_engineering_fixture')
  list(job=job,case=s07i_case(job))
}
s07i_validate_job<-function(job,case=s07i_case(job),identity=NULL){
  if(identical(job$stage,'s07_engineering_fixture')){
    e<-s07i_fixture(job$case_index,job$B_planned);if(!identical(job,e$job)||!identical(case,e$case))stop('Fixture must be exact seed781/dataset999.')
  }else if(identical(job$stage,'reserved_method_development')){
    c<-s07i_context();if(is.null(identity)||is.null(c)||!identical(identity,c$identity))stop('Verified frozen S07-I1 required.')
    if(!identical(job,c$jobs[[s07i_key(job)]])||!identical(case,s07i_case(job)))stop('Not an exact frozen job.')
  }else stop('Unknown execution domain.');invisible(TRUE)
}
s07i_key<-function(job)sprintf('%s-%04d',job$case_id,job$dataset_id)
s07i_hooks<-function(job,hooks){if(!is.list(hooks)||any(!vapply(hooks,is.function,logical(1))))stop('Invalid hooks.');if(length(hooks)&&job$stage!='s07_engineering_fixture')stop('Hooks forbidden in reserved execution.');invisible(TRUE)}
s07i_bind<-function(x){z<-study05_analysis_bind(x);rownames(z)<-NULL;z}
s07i_key_columns<-function(x,columns)study06r1_cov_key(x,columns)
s07i_match<-function(x,y,columns,complete=TRUE){a<-s07i_key_columns(x,columns);b<-s07i_key_columns(y,columns);if(anyDuplicated(a)||anyDuplicated(b)||(complete&&!setequal(a,b)))stop('Duplicate or incomplete joined identities.');i<-match(a,b);if(anyNA(i))stop('Unmatched identities.');y[i,,drop=FALSE]}
s07i_budget_views<-function(job)sort(unique(c(job$B_primary,job$B_planned)))
