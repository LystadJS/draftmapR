s07i_load <- function(execution_dir,specification_dir=file.path(dirname(execution_dir),'study07-specification')) {
  execution_dir<-normalizePath(execution_dir);specification_dir<-normalizePath(specification_dir)
  vendor<-file.path(specification_dir,'vendor')
  source(file.path(vendor,'study06-execution/R/load.R'),local=.GlobalEnv)
  s06_load(file.path(vendor,'study06-execution'),file.path(vendor,'study06-specification'))
  for(n in c('design.R','math-contracts.R'))source(file.path(specification_dir,'R',n),local=.GlobalEnv)
  for(n in c('covariance.R','cohorts.R'))source(file.path(vendor,'study06-reporting-recovery/R',n),local=.GlobalEnv)
  for(n in c('guards','generator','population','controls','full','analysis','diagnostics','validation','figures','runner')) {
    p<-file.path(execution_dir,'R',paste0(n,'.R'));if(file.exists(p))source(p,local=.GlobalEnv)
  }
  s07i_paths(execution_dir,specification_dir);invisible(execution_dir)
}
