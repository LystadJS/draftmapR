s07i_functional<-function(K,A,anchors,targets){z<-study03_fit(K[[1L]],K[[2L]],A,anchors);z$displacement[targets,,drop=FALSE]}
s07i_gaussian_moments<-function(Gamma,indices){
  if(length(Gamma)!=2L||any(lengths(Gamma)!=2L))stop('Invalid paired Gamma.')
  r<-17L;all<-unlist(Gamma,recursive=FALSE)
  if(any(vapply(all,function(x)!is.matrix(x)||!identical(dim(x),c(r,r))||any(!is.finite(x)),logical(1))))stop('Invalid Gamma dimensions.')
  joint<-rbind(cbind(Gamma[[1]][[1]],Gamma[[1]][[2]]),cbind(Gamma[[2]][[1]],Gamma[[2]][[2]]))
  mag<-max(1,max(abs(joint)));if(max(abs(joint-t(joint)))>1e-12*mag||min(eigen(joint,symmetric=TRUE,only.values=TRUE)$values) < -1e-10*mag)stop('Invalid joint Gaussian covariance.')
  a<-indices[,1];b<-indices[,2];w<-ifelse(a==b,1,sqrt(2));d<-length(a);V<-matrix(NA_real_,2*d,2*d)
  for(t in 1:2)for(s in 1:2){g<-Gamma[[t]][[s]];V[(t-1L)*d+seq_len(d),(s-1L)*d+seq_len(d)]<-(g[a,a]*g[b,b]+g[a,b]*g[b,a])*outer(w,w)}
  V
}
s07i_reference<-function(case,hook=NULL,moment_hook=NULL){
  model<-s07i_model(case);basis<-s07_centered_basis();Q<-basis$Q;K<-model$population_grams;A<-model$population_points[[1L]]
  k<-length(model$target_ids);d<-length(basis$basis)*2L;L<-max(1,sqrt(sum(vapply(K,function(x)sum(x^2),numeric(1)))))
  steps<-L*2^(-c(12,14,16));expanded<-lapply(basis$basis,function(E)Q%*%E%*%t(Q))
  call<-function(pair,ctx)study03_capture({if(!is.null(hook))hook(ctx);s07i_functional(pair,A,model$anchors,model$target_rows)})
  base<-call(K,list(role='base',direction=0L,step_index=0L,sign=0L));values<-array(NA_real_,c(d,3L,2L,k,2L));ledger<-list()
  for(direction in seq_len(d))for(step in 1:3)for(si in 1:2){
    sign<-c(-1L,1L)[si];period<-(direction-1L)%/%length(expanded)+1L;b<-(direction-1L)%%length(expanded)+1L
    ctx<-list(role='perturbation',direction=direction,step_index=step,sign=sign,period=period,basis_index=b)
    pair<-K;pair[[period]]<-pair[[period]]+sign*steps[step]*expanded[[b]]
    z<-if(base$ok)call(pair,ctx)else list(ok=FALSE,stage='population_base_unavailable',message=base$message,warnings='')
    if(z$ok)values[direction,step,si,,]<-z$value
    ledger[[length(ledger)+1L]]<-data.frame(case_id=case$case_id,direction=direction,period=period,basis_index=b,step_index=step,step=steps[step],sign=sign,
      required=TRUE,attempted=base$ok,successful=z$ok,failed_after_attempt=base$ok&&!z$ok,unattempted_required=!base$ok,stage=z$stage,message=z$message,warnings=z$warnings)
  }
  jacobians<-lapply(1:3,function(s)lapply(seq_len(k),function(j)t((values[,s,2L,j,]-values[,s,1L,j,])/(2*steps[s]))))
  Gamma<-V<-NULL;moment_status<-'not_applicable_non_gaussian';moment_message<-''
  if(case$scenario!='rare_axis'){
    moment<-study03_capture({
      if(!is.null(moment_hook))moment_hook()
      sigma<-model$scenario$sigma;rho<-model$scenario$rho_time;H<-model$H
      Gamma<-lapply(1:2,function(t)lapply(1:2,function(s)t(Q)%*%(model$layout$latent[[t]]%*%t(model$layout$latent[[s]])+sigma^2*(if(t==s)1 else rho)*H)%*%Q))
      list(Gamma=Gamma,V=s07i_gaussian_moments(Gamma,basis$indices))
    })
    if(moment$ok){Gamma<-moment$value$Gamma;V<-moment$value$V;moment_status<-'available'}else{moment_status<-'moment_computation_failed';moment_message<-moment$message}
  }
  derivative<-list();Omega<-vector('list',k)
  for(j in seq_len(k)){
    Js<-lapply(jacobians,`[[`,j);finite<-all(is.finite(unlist(Js)))
    fm<-if(finite)sqrt(sum((Js[[3]]-Js[[2]])^2))else NA_real_;mc<-if(finite)sqrt(sum((Js[[2]]-Js[[1]])^2))else NA_real_
    scale<-if(finite)max(1,sqrt(sum(Js[[3]]^2)))else NA_real_
    available<-finite&&fm/scale<=1e-3&&(mc<=1e-10*scale||fm<=.25*mc)
    status<-if(!base$ok)'base_unavailable'else if(!finite)'perturbation_unavailable'else if(!available)'derivative_not_converged'else 'available'
    O<-if(available&&!is.null(V))Js[[3]]%*%V%*%t(Js[[3]])else matrix(NA_real_,2,2)
    os<-study03_covariance_status(O);Omega[[j]]<-O
    derivative[[j]]<-data.frame(case_id=case$case_id,entity=model$target_ids[j],all_evaluations_finite=finite,fine_mid_norm=fm,mid_coarse_norm=mc,fine_scale=scale,
      relative_discrepancy=fm/scale,available=available,status=status,omega_available=os$valid,
      omega_status=if(case$scenario=='rare_axis')'not_applicable_non_gaussian'else if(!available)status else if(is.null(V))moment_status else if(!os$valid)os$reason else 'available')
  }
  list(case=case,model=model,Q=Q,basis_indices=basis$indices,scale=L,steps=steps,base=base,ledger=s07i_bind(ledger),perturbation_values=values,jacobians=jacobians,
    derivative=s07i_bind(derivative),Gamma=Gamma,V=V,Omega=Omega,moment_status=moment_status,moment_message=moment_message,
    population_input_md5=study05_object_md5(list(K=K,A=A,anchors=model$anchors,latent=model$layout$latent,scenario=model$scenario)))
}
s07i_influences<-function(g,reference){
  q<-reference$Q;ab<-reference$basis_indices;d<-nrow(ab);m<-ncol(g$X[[1]])
  h<-matrix(NA_real_,m,2L*d)
  for(t in 1:2){x<-crossprod(q,g$X[[t]]);K<-crossprod(q,reference$model$population_grams[[t]]%*%q)
    for(b in seq_len(d)){a<-ab[b,1];j<-ab[b,2];h[,(t-1L)*d+b]<-(x[a,]*x[j,]-K[a,j])*(if(a==j)1 else sqrt(2))}}
  psi<-lapply(seq_len(nrow(reference$derivative)),function(j)if(reference$derivative$available[j])h%*%t(reference$jacobians[[3L]][[j]])else matrix(NA_real_,m,2L))
  list(h=h,psi=psi)
}
s07i_dependence_factor<-function(m,rho){h<-seq_len(m-1L);1+2*sum((1-h/m)*rho^(2*h))}
