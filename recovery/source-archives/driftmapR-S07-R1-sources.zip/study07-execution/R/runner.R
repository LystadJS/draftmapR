s07i_engineering_jobs<-function()lapply(c(1:9,101:103),function(i)s07i_fixture(i,if(i==1L)799L else if(i>=101L)199L else 21L)$job)
s07i_identity<-function(jobs){f<-s07i_source_files();list(study='S07 engineering only',design=s07i_verify_design(),runtime=s07i_runtime(),jobs=jobs,source_files=f,implementation_files=unname(study05_md5(file.path(s07i_paths()$execution,f))))}
s07i_science_hash<-function(x){clean<-function(z){if(is.list(z)){z$elapsed_seconds<-NULL;z<-lapply(z,clean)};z};study05_object_md5(clean(x))}
s07i_json<-function(x,path){dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE);jsonlite::write_json(x,path,auto_unbox=TRUE,pretty=FALSE,digits=NA,na='string',null='null',matrix='rowmajor')}
s07i_refjob<-function(case){list(case_id=case$case_id,dataset_id=0L,stage='population_reference',case=case)}
s07i_reference_case<-function(case){case$B<-199L;case}
s07i_work<-function(job,identity,out,engineering){
  path<-file.path(out,'checkpoints',paste0(s07i_key(job),'.rds'));case<-s07i_case(job);permit<-if(engineering)NULL else identity
  tryCatch({r<-s06_checkpoint(path,identity,job);if(!is.null(r))return(path)
    plan<-s06_checkpoint(file.path(out,'draw-plans',paste0(s07i_key(job),'.rds')),identity,job);if(is.null(plan))stop('Missing pre-materialized plan.')
    g<-s07i_generate(job,case,permit);r<-list(job=job,case=case,plan=plan,generated=g)
    if(job$pipeline=='full_estimator'){
      rc<-s07i_reference_case(case);ref<-s06_checkpoint(file.path(out,'population',paste0(case$case_id,'.rds')),identity,s07i_refjob(rc));if(is.null(ref))stop('Missing population reference.');r$reference<-ref$reference
      r$full<-s07i_full(job,case,g,plan,permit,keep_values=engineering||job$dataset_id==1L);r$linear<-s07i_linear(job,g,r$reference,plan)
      r$mechanical_validation<-s07i_validate_full(r$full,permit);r$control_validation<-s07i_bind(lapply(r$linear$paths,s07i_validate_control,job=job,weights=plan$weights))
      r$stage<-study05_stage_accounting(r$full);r$control_stage<-s07i_control_accounting(r$linear$parents)
      if(engineering||job$dataset_id==1L){r$public_audit<-s07i_public_audit(r$full,g);r$control_audit<-s07i_bind(lapply(r$linear$paths,s07i_mean_physical_audit,job=job,weights=plan$weights,parents=0:2))}
    }else{r$normal<-s07i_normal(job,case,g,plan,permit);r$control_validation<-s07i_validate_control(r$normal$path,job,plan$weights);r$control_stage<-s07i_control_accounting(r$normal$parents);if(engineering||job$dataset_id<=2L)r$control_audit<-s07i_mean_physical_audit(r$normal$path,job,plan$weights)}
    # All matrix-based mechanical checks run above, before compact checkpoint storage.
    # Per-fit matrices can be regenerated exactly from retained X, weights and source identity.
    # Preserve every scalar geometry/deletion row and all population reference matrices.
    if(job$pipeline=='full_estimator'){r$full$geometry$matrices<-NULL;r$checkpoint_retention<-'Per-fit duplicate Gram/registration matrix cache omitted after mechanical validation; raw units, exact weights, scalar geometry, full deletions and all population matrices retained.'}
    r$science_md5<-s07i_science_hash(r);study05_checkpoint_save(r,path,identity);cat('Validated',s07i_key(job),'B',job$B_planned,'\n');flush.console();path
  },error=function(e){s06_incident(path,'uncompleted_job',conditionMessage(e));stop(e)})
}
s07i_export_reference<-function(r,path){
  z<-list(case=r$case,Q=r$Q,basis_indices=r$basis_indices,K=r$model$population_grams,A=r$model$population_points[[1]],anchors=r$model$anchors,targets=r$model$target_rows,truth=r$model$truth,latent=r$model$layout$latent,sigma=r$model$scenario$sigma,rho_time=r$model$scenario$rho_time,steps=r$steps,base_ok=r$base$ok,base_value=if(r$base$ok)r$base$value else NULL,ledger=r$ledger,derivative=r$derivative,jacobians=r$jacobians,Gamma=r$Gamma,V=r$V,Omega=r$Omega,population_input_md5=r$population_input_md5,
    perturbations=lapply(seq_len(306L),function(d)lapply(1:3,function(s)lapply(1:2,function(si)r$perturbation_values[d,s,si,,]))))
  s07i_json(z,path)
}
s07i_export_panel<-function(r,path){
  z<-list(job=r$job,weights=r$plan$weights,streams=r$plan$streams)
  control<-function(p)list(values=p$values,truth=p$truth,parents=p$parents,entity=p$entity)
  if(r$job$pipeline=='normal_mean_control'){z$controls<-list(control(r$normal$path));z$regions<-r$normal$regions}else{
    f<-r$full;z$X<-r$generated$X;z$controls<-lapply(r$linear$paths,control);z$linear_regions<-r$linear$regions;z$reference<-r$job$case_id;z$screen<-f$s07_screen
    z$frames<-lapply(c('core','frame'),function(n){a<-if(n=='core')f else f$frame;list(name=n,point=a$estimate,observed_success=a$observed_success,Q=if(n=='core')f$Q else diag(2),R0=if(n=='core'&&f$observed_core_fit_available)f$observed$reference else NULL,eval_values=lapply(seq_len(a$B),function(b)matrix(a$eval_values[b,,],ncol=2)),pivots=a$pivots,
      covariances=lapply(c(list(a$observed_jackknife),a$inner),function(j)list(S=unname(j$covariance),weighted_mean=j$weighted_mean,scatter=unname(j$weighted_scatter),all_required_success=j$all_required_success,covariance_ok=j$covariance_ok,reason=j$reason)),studentization=a$studentization)})
  };s07i_json(z,path)
}
s07i_collect<-function(paths,jobs,identity,out){
  if(length(paths)!=length(jobs)||anyDuplicated(paths))stop('Incomplete checkpoint grid.');s06_new_product_dir(out);compact<-list();index<-stages<-cstages<-audits<-caudits<-checks<-cchecks<-list();streams<-list();counts<-list()
  chunks<-list();chunk_dir<-file.path(dirname(out),paste0('csv-chunks-',s06_incident_id()));dir.create(chunk_dir,recursive=TRUE)
  write<-function(x,name){
    if(!is.data.frame(x)||!nrow(x))return(invisible(NULL))
    if(is.null(counts[[name]]))counts[[name]]<<-0
    serial<-length(chunks)+1L;dest<-file.path(chunk_dir,sprintf('%07d.csv',serial));tmp<-paste0(dest,'.writing')
    write.table(x,tmp,sep=',',row.names=FALSE,col.names=TRUE,quote=TRUE,qmethod='double',na='NA')
    # Validate before publication; failures are infrastructure, never statistical non-delivery.
    check<-read.csv(tmp,check.names=FALSE,stringsAsFactors=FALSE)
    if(nrow(check)!=nrow(x)||!identical(names(check),names(x)))stop('CSV chunk failed its read-back count/schema check.')
    if(!file.rename(tmp,dest))stop('Cannot commit CSV chunk.')
    chunks[[serial]]<<-data.frame(product=name,chunk=file.path(basename(chunk_dir),basename(dest)),rows=nrow(x),md5=study05_md5(dest))
    counts[[name]]<<-counts[[name]]+nrow(x)
  }
  for(i in seq_along(jobs)){
    j<-jobs[[i]];r<-s06_checkpoint(paths[i],identity,j);if(is.null(r)||!all(r$control_validation$status=='passed'))stop('Unvalidated/missing checkpoint.');t<-s07i_panel_tables(r);for(n in names(t))compact[[n]][[i]]<-t[[n]]
    stages[[i]]<-r$stage;cstages[[i]]<-r$control_stage;audits[[i]]<-r$public_audit;caudits[[i]]<-r$control_audit;checks[[i]]<-r$mechanical_validation;cchecks[[i]]<-r$control_validation
    write(data.frame(case_id=j$case_id,dataset_id=j$dataset_id,replicate_id=seq_len(j$B_planned),m=j$m,weights=apply(r$plan$weights,1,paste,collapse=';'),rng_stream=apply(r$plan$streams,1,paste,collapse=';')),'draws.csv.gz')
    s07i_export_panel(r,file.path(out,'panels',paste0(s07i_key(j),'.json')))
    if(j$pipeline=='full_estimator'){
      for(n in c('units','parents'))write(r$linear[[n]],paste0('linear/',n,'.csv.gz'))
      for(period in 1:2)write(data.frame(case_id=j$case_id,dataset_id=j$dataset_id,period=period,unit_id=seq_len(j$m),t(r$generated$X[[period]])),'full/units.csv.gz')
      for(n in c('embedding','registration')){g<-r$full$geometry[[n]];write(g,paste0('full/geometry-',n,'.csv.gz'))}
      for(frame in c('core','frame')){f<-if(frame=='core')r$full else r$full$frame
        for(n in c('outer','estimates','regions','attempts','studentization'))write(f[[n]],paste0('full/',frame,'/',n,'.csv.gz'))
        for(b in 0:j$B_planned){d<-if(b==0L)f$observed_jackknife$ledger else f$inner[[b]]$ledger;if(!'core_success'%in%names(d))d$core_success<-d$success;write(cbind(case_id=j$case_id,dataset_id=j$dataset_id,frame=frame,parent_id=b,required=d$multiplicity>0,d),'full/deletions.csv.gz')}
      }
      pp<-file.path(out,'population',paste0(j$case_id,'.json'));if(!file.exists(pp))s07i_export_reference(r$reference,pp)
    }else for(n in c('units','parents'))write(r$normal[[n]],paste0('normal/',n,'.csv.gz'))
    index[[i]]<-data.frame(case_id=j$case_id,dataset_id=j$dataset_id,B=j$B_planned,m=j$m,checkpoint=basename(paths[i]),md5=study05_md5(paths[i]),bytes=file.info(paths[i])$size,science_md5=r$science_md5,weights_md5=r$plan$weights_md5,streams_md5=r$plan$streams_md5)
  }
  tables<-lapply(compact,s07i_bind);for(n in names(tables))write(tables[[n]],paste0('compact/',n,'.csv.gz'))
  extra<-list('checkpoint-index'=index,'stage-accounting'=stages,'control-stage-accounting'=cstages,'public-audit'=audits,'control-audit'=caudits,'mechanical-validation'=checks,'control-validation'=cchecks)
  for(n in names(extra))write.csv(s07i_bind(extra[[n]]),file.path(out,paste0(n,'.csv')),row.names=FALSE,na='NA')
  write.csv(data.frame(path=names(counts),rows=unlist(counts)),file.path(out,'row-counts.csv'),row.names=FALSE)
  write.csv(s07i_bind(chunks),file.path(out,'csv-chunk-manifest.csv'),row.names=FALSE)
  status<-system2('python3',c(shQuote(file.path(s07i_paths()$execution,'scripts/compress-tables.py')),shQuote(out)));if(status!=0L)stop('CSV finalization failed.')
  saveRDS(tables,file.path(out,'analysis-inputs.rds'),version=2);saveRDS(list(identity=identity,jobs=jobs),file.path(out,'collection-identity.rds'));tables
}
s07i_inventory<-function(out){files<-sort(list.files(out,recursive=TRUE));files<-files[grepl('^(tables|analysis)/',files)&!grepl('content-manifest.csv$',files)];write.csv(data.frame(path=files,md5=unname(study05_md5(file.path(out,files))),bytes=file.info(file.path(out,files))$size),file.path(out,'content-manifest.csv'),row.names=FALSE)}
s07i_final_audit<-function(out,engineering){log<-system2('python3',c(shQuote(file.path(s07i_paths()$execution,'scripts/final-audit.py')),shQuote(normalizePath(out)),if(engineering)'--engineering'),stdout=TRUE,stderr=TRUE);writeLines(log,file.path(out,'independent-audit.log'));if(!is.null(attr(log,'status')))stop('Independent audit failed: ',paste(tail(log,20),collapse='\n'));cat(paste(log,collapse='\n'),'\n');invisible(TRUE)}
s07i_unresolved<-function(out,jobs,identity,complete=FALSE){z<-s07i_bind(lapply(jobs,function(j){p<-file.path(out,'checkpoints',paste0(s07i_key(j),'.rds'));r<-tryCatch(s06_checkpoint(p,identity,j),error=function(e)NULL);data.frame(case_id=j$case_id,dataset_id=j$dataset_id,B=j$B_planned,status=if(!is.null(r)&&all(r$control_validation$status=='passed'))'validated_checkpoint'else 'infrastructure_unresolved')}));if(complete&&any(z$status!='validated_checkpoint'))stop('Unresolved plan.');write.csv(z,file.path(out,'execution-job-status.csv'),row.names=FALSE);s07i_json(list(status=if(complete)'COMPLETE'else 'INCOMPLETE',planned=length(jobs),unresolved=sum(z$status!='validated_checkpoint'),meaning='Missing jobs are infrastructure incompleteness, not statistical non-delivery.'),file.path(out,'execution-status.json'));invisible(z)}
s07i_run<-function(out,workers=4L,engineering=TRUE){
  if(length(workers)!=1L||!workers%in%1:8)stop('Use 1 to 8 workers.');jobs<-if(engineering)s07i_engineering_jobs()else s07i_jobs();identity<-if(engineering)s07i_identity(jobs)else s07i_verify_implementation();permit<-if(engineering)NULL else identity
  dir.create(out,recursive=TRUE,showWarnings=FALSE);out<-normalizePath(out);sig<-file.path(out,'execution-identity.rds');if(file.exists(sig)&&!identical(readRDS(sig),identity))stop('Output identity mismatch; preserve original output.');if(!file.exists(sig))saveRDS(identity,sig,version=2)
  complete<-FALSE;on.exit(if(!complete)try(s07i_unresolved(out,jobs,identity),silent=TRUE),add=TRUE)
  if(file.exists(file.path(out,'execution-complete.json'))){s07i_final_audit(out,engineering);complete<-TRUE;return(invisible(out))}
  for(n in c('checkpoints','draw-plans','population'))dir.create(file.path(out,n),showWarnings=FALSE)
  if(file.exists(file.path(out,'seed-plan.rds'))&&!identical(readRDS(file.path(out,'seed-plan.rds')),jobs))stop('Changed seed plan.');if(!file.exists(file.path(out,'seed-plan.rds')))saveRDS(jobs,file.path(out,'seed-plan.rds'),version=2)
  write.csv(s07i_bind(lapply(jobs,function(j)data.frame(case_id=j$case_id,case_index=j$case_index,dataset_id=j$dataset_id,m=j$m,B=j$B_planned,B_primary=j$B_primary,extension=j$extension,pipeline=j$pipeline,stage=j$stage,bootstrap_seed=j$bootstrap_seed,data_stream=paste(j$data_stream,collapse=';')))),file.path(out,'job-manifest.csv'),row.names=FALSE)
  planwork<-function(j){p<-file.path(out,'draw-plans',paste0(s07i_key(j),'.rds'));if(is.null(s06_checkpoint(p,identity,j)))study05_checkpoint_save(s07i_draws(j,s07i_case(j),permit),p,identity);p};study05_execute_jobs(jobs,planwork,workers)
  writeLines('All exact planned weights materialized before measurement generation.',file.path(out,'draw-plans-complete.txt'))
  cases<-lapply(jobs[vapply(jobs,function(j)j$pipeline=='full_estimator',logical(1))],function(j)s07i_reference_case(s07i_case(j)));cases<-cases[!duplicated(vapply(cases,function(c)c$case_id,character(1)))]
  refwork<-function(case){j<-s07i_refjob(case);p<-file.path(out,'population',paste0(case$case_id,'.rds'));if(is.null(s06_checkpoint(p,identity,j))){ref<-s07i_reference(case);study05_checkpoint_save(list(job=j,reference=ref,validation=s07i_validate_reference(ref)),p,identity)};p};study05_execute_jobs(cases,refwork,workers)
  paths<-unlist(study05_execute_jobs(jobs,function(j)s07i_work(j,identity,out,engineering),workers),use.names=FALSE)
  tables<-s07i_collect(paths,jobs,identity,file.path(out,'tables'));s06_new_product_dir(file.path(out,'analysis'));s07i_analyze(tables,file.path(out,'analysis'),engineering);s07i_inventory(out);s07i_final_audit(out,engineering)
  if(!identical(identity,if(engineering)s07i_identity(jobs)else s07i_verify_implementation()))stop('Source/design/runtime changed during execution.')
  s07i_unresolved(out,jobs,identity,TRUE);s07i_json(list(engineering=engineering,panels=length(jobs),draws=sum(vapply(jobs,`[[`,integer(1),'B_planned')),completed_at=study05_utc(),independent_audit_passed=TRUE,reserved_measurement_panels_generated=if(engineering)0L else length(jobs),reserved_bootstrap_weight_vectors_generated=if(engineering)0L else sum(vapply(jobs,`[[`,integer(1),'B_planned'))),file.path(out,'execution-complete.json'));complete<-TRUE;invisible(out)
}
