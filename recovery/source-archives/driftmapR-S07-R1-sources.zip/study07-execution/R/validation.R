s07i_control_accounting<-function(parents){
  rows<-list();keys<-c('case_id','dataset_id','construction','entity')
  for(g in study05_analysis_groups(parents,keys))for(stage in c('covariance','pivot')){
    required<-g[[paste0(stage,'_required')]];attempted<-g[[paste0(stage,'_attempted')]];success<-g[[paste0(stage,'_ok')]]
    if(anyNA(c(required,attempted,success))||any(attempted&!required)||any(success&!attempted))stop('Invalid control stage dependencies.')
    rows[[length(rows)+1L]]<-data.frame(g[1,keys,drop=FALSE],stage=stage,count_kind='closed_algebra_control',planned=nrow(g),required=sum(required),not_required=sum(!required),attempted=sum(attempted),successful=sum(success),failed_after_attempt=sum(attempted&!success),unattempted_required=sum(required&!attempted),
      required_occurrences=if(stage=='covariance')sum(g$m[required])else NA_real_,attempted_occurrences=if(stage=='covariance')sum(g$m[attempted])else NA_real_,successful_occurrences=if(stage=='covariance')sum(g$m[success])else NA_real_,failed_occurrences=if(stage=='covariance')sum(g$m[attempted&!success])else NA_real_,unattempted_required_occurrences=if(stage=='covariance')sum(g$m[required&!attempted])else NA_real_,definition='Closed occurrence formula; represented occurrences are not separately executed deletion fits.')
  };s07i_bind(rows)
}
s07i_validate_control<-function(path,job,weights,tolerance=1e-9,allow_hooks=FALSE){
  p<-path$parents;checks<-0L;ck<-function(x,msg){checks<<-checks+1L;if(!isTRUE(x))stop(msg)}
  ck(identical(p$parent_id,0:job$B_planned),'Complete control parent grid');ck(!anyDuplicated(p$parent_id),'Unique control parents')
  for(b in 0:job$B_planned){r<-p[b+1L,,drop=FALSE];w<-if(b==0L)rep(1L,job$m)else weights[b,];ck(r$required_occurrences==sum(w)&&r$required_unique==sum(w>0),'Control counts')
    if(all(is.finite(path$values))){
      expanded<-path$values[rep(seq_len(job$m),w),,drop=FALSE];center<-colMeans(expanded);S<-cov(expanded)/job$m;ck(max(abs(center+path$truth-c(r$dx,r$dy)))<=tolerance,'Expanded mean')
      if(!allow_hooks){actual<-matrix(c(r$var_dx,r$cov_dx_dy,r$cov_dx_dy,r$var_dy),2);ck(max(abs(S-actual))<=tolerance,'Expanded covariance');cond<-matrix(c(r$conditional_var_dx,r$conditional_cov_dx_dy,r$conditional_cov_dx_dy,r$conditional_var_dy),2);ck(max(abs(cond-S*(job$m-1)/job$m))<=tolerance,'Conditional multinomial factor');st<-study03_covariance_status(S);ck(r$covariance_ok==st$valid,'Control SPD gate');if(b>0L&&st$valid){q<-study03_quadratic(center-colMeans(path$values),S);ck(r$pivot_ok==is.finite(q),'Control pivot availability');if(is.finite(q))ck(abs(r$pivot-q)<=tolerance*max(1,abs(q)),'Control scalar pivot')}}
    }else ck(!r$covariance_attempted&&!r$pivot_attempted&&!r$point_available,'Unavailable influence accounting')
  }
  a<-s07i_control_accounting(p);ck(all(a$required==a$attempted+a$unattempted_required),'Control required balance');ck(all(a$attempted==a$successful+a$failed_after_attempt),'Control attempted balance');data.frame(status='passed',checks=checks)
}
s07i_mean_physical_audit<-function(path,job,weights,parents=0:job$B_planned,tolerance=1e-9){
  rows<-lapply(parents,function(b){w<-if(b==0L)rep(1L,job$m)else weights[b,];ok<-all(is.finite(path$values));diff<-NA_real_;n<-0L
    if(ok){x<-path$values[rep(seq_len(job$m),w),,drop=FALSE];deleted<-t(vapply(seq_len(job$m),function(i)colMeans(x[-i,,drop=FALSE]),numeric(2)));S<-(job$m-1)/job$m*crossprod(sweep(deleted,2,colMeans(deleted),'-'));diff<-max(abs(S-path$covariances[[b+1L]]));n<-job$m}
    data.frame(case_id=job$case_id,dataset_id=job$dataset_id,entity=path$entity,construction=path$construction,parent_id=b,required=TRUE,attempted=ok,numerically_compared=ok,physical_occurrence_deletions=n,max_abs_covariance_difference=diff,status=if(ok)'compared'else 'dependency_blocked',passed=!ok||is.finite(diff)&&diff<=tolerance)
  });z<-s07i_bind(rows);if(any(!z$passed))stop('Physical control covariance disagreement.');z
}
s07i_public_audit<-function(result,g,tolerance=1e-9){
  inherited<-study05_public_audit(result,g,tolerance);rows<-list()
  for(b in seq_len(result$B)){
    attempted<-result$observed_success;z<-if(attempted)study05_public_expanded_fit(g,as.integer(result$weights[b,]),reference=result$observed$reference,method='cmds')else NULL;boundary<-study05_audit_boundary(g,result$weights[b,])
    for(frame in c('observed_reference','population_reference')){
      ok<-!is.null(z)&&z$ok;v<-if(ok&&frame=='observed_reference')z$value$vector else if(ok){direct<-study03_capture(study03_public_vectors(z$value$object,sqrt(result$job$m),g$model$population_points[[1]],g$model));ok<-direct$ok;if(ok)direct$value else NULL}else NULL
      fr<-if(frame=='observed_reference')result else result$frame;success<-fr$attempts$success[b];common<-ok&&success;difference<-if(common)max(abs(v-matrix(fr$values[b,,],ncol=2)))else NA_real_;class<-study05_audit_status(ok,success,boundary,attempted)
      rows[[length(rows)+1L]]<-data.frame(case_id=result$job$case_id,dataset_id=result$job$dataset_id,audit_type='full_bootstrap_classical_mds',estimator_frame=frame,replicate_id=b,unit_index=0L,B=result$B,n_attempted=as.integer(attempted),n_successful=as.integer(ok),public_success=ok,research_success=success,classification=class,max_vector_abs_diff=difference,max_covariance_abs_diff=NA_real_,numerically_compared=common,tolerance=tolerance,passed=class!='implementation_discrepancy'&&(!common||difference<=tolerance),message=if(!is.null(z))z$message else 'Observed comparison blocked.')
    }
  }
  inherited$numerically_compared<-is.finite(inherited$max_vector_abs_diff)|is.finite(inherited$max_covariance_abs_diff);records<-attr(inherited,'public_records');out<-s07i_bind(c(list(inherited),rows));attr(out,'public_records')<-records;if(any(!out$passed))stop('Public PCA/classical-MDS disagreement.');out
}
s07i_validate_reference<-function(z,tolerance=1e-9){
  stopifnot(nrow(z$ledger)==1836L,!anyDuplicated(z$ledger[c('direction','step_index','sign')]),all(z$ledger$required==z$ledger$attempted+z$ledger$unattempted_required),all(z$ledger$attempted==z$ledger$successful+z$ledger$failed_after_attempt))
  if(z$base$ok)stopifnot(max(abs(z$base$value-z$model$truth))<tolerance,all(z$ledger$attempted))
  for(j in seq_len(nrow(z$derivative))){finite<-all(is.finite(unlist(lapply(z$jacobians,`[[`,j))));stopifnot(z$derivative$all_evaluations_finite[j]==finite);if(z$derivative$available[j])stopifnot(finite,z$derivative$relative_discrepancy[j]<=1e-3);if(z$derivative$omega_available[j])stopifnot(max(abs(z$Omega[[j]]-z$jacobians[[3]][[j]]%*%z$V%*%t(z$jacobians[[3]][[j]])))<=tolerance)}
  data.frame(case_id=z$case$case_id,status='passed',planned_evaluations=1837L,attempted_evaluations=sum(z$ledger$attempted)+1L,derivative_targets_available=sum(z$derivative$available),omega_targets_available=sum(z$derivative$omega_available))
}
s07i_validate_full<-function(result,identity=NULL){s07i_validate_job(result$job,result$case,identity);out<-study05_validate_result(result);if(!identical(result$s07_screen,s06_observed_policy(result)))stop('Observed-only T1 changed.');a<-study05_stage_accounting(result);stopifnot(all(a$required==a$attempted+a$unattempted_required),all(a$attempted==a$successful+a$failed_after_attempt));out}
