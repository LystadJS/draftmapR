# driftmapR — Study 07 implementation (S07-I1)

This directory implements the frozen **S07-D1** mechanism study. It is a research runner layered over the unchanged `driftmapR` 0.0.7.9000 estimator and verified Study 05/06 ancestry. The design is in the adjacent `study07-specification/` directory. The implementation is frozen only when `implementation-freeze.rds` and `implementation-freeze.json` exist and both verification commands pass.

The implementation session uses **engineering seed 781 / dataset 999 only**. Its figures and single-panel-per-cell outcomes are engineering evidence, not coverage estimates or an independent calibration study. Reserved measurement panels and bootstrap draw vectors remain ungenerated at the implementation freeze.

## Restore and verify

Extract the supplied `driftmapR-S07-D1-specification.zip` and pinned runtime archive beside this directory. The runtime wrapper retains its original absolute installation location; restoration at a different path requires a separately documented relocation and revalidation rather than silently changing its fingerprint.

```sh
python3 study07-specification/scripts/freeze.py verify
r-runtime/bin/Rscript-local study07-execution/scripts/verify.R
python3 study07-execution/scripts/manifest.py verify study07-execution
```

The first command verifies S07-D1 and its entire vendored ancestry. The latter two require the completed I1 freeze and verify the exact source/evidence grid, byte identities, installed estimator, R numerical libraries, and Python/NumPy audit runtime. There are no new R package dependencies.

## Engineering workflow

```sh
r-runtime/bin/Rscript-local study07-execution/scripts/run.R engineering NEW_GRID 4
r-runtime/bin/Rscript-local study07-execution/scripts/test.R NEW_GRID NEW_TEST_EVIDENCE
python3 study07-execution/scripts/test-audit.py NEW_GRID NEW_TEST_EVIDENCE
```

The engineering grid is fixed: nine full-estimator cells and three normal controls, dataset 999, seed 781. The regular m=40 cell uses 799 draws, other full cells use 21, and normal controls use 199. This is 12 panels and 1,564 distinct weight vectors. Tests additionally use the same engineering domain to inject failures and independently fit the 199 prefix. No fixture becomes an empirical study result.

Inspect all four figures, retain a hash-bound `figure-review.rds`, and run:

```sh
r-runtime/bin/Rscript-local study07-execution/scripts/freeze.R NEW_GRID NEW_TEST_EVIDENCE
```

The freeze gate checks matching source/runtime identities, all tests, the complete engineering plan, independent arithmetic audit, and figure review. It refuses existing or partial locks. Do not edit the frozen directory; repairs require a separately named amendment retaining the original evidence.

## Reserved execution — separate subsequent work

The following executable command is provided for the later authorized study execution. It was **not run during implementation**:

```sh
r-runtime/bin/Rscript-local study07-execution/scripts/run.R reserved NEW_STUDY_OUTPUT 4
```

The reserved mode accepts only the exact 6,480 jobs in S07-D1. There are no case, seed, budget, or successful-fit-redraw overrides. It requires a verified I1 freeze before materializing weights or generating measurements. Workers may range from one to eight; changing worker count does not change streams. Repeating the same command resumes exact jobs after verifying identities. A different source identity refuses the old output directory. A missing/corrupted checkpoint is infrastructure incompleteness; it is preserved/quarantined and the identical original job may be recomputed. Completed runs are independently re-audited when resumed.

All draw plans are committed before measurements. Full-estimator checkpoints can be large; retain adequate disk space for raw units, original-unit deletion slots, checkpoint manifests and independent-audit products. Normal controls use closed occurrence algebra, not hundreds of millions of physical deletion fits. The independent audit streams the large deletion CSV, while retaining only small per-panel weight/covariance arrays. It performs no random-number generation.

## Estimator and diagnostics

The inherited full estimator refits both embeddings and the declared-anchor registrations for each bootstrap sample and each required occurrence deletion. Core and population-reference frames are distinct. The five inherited region constructions, targets, tolerances, .95 valid-pivot fraction, minimum 20 pivots, and type-7 quantiles are unchanged. T1 is an observed-core-only reporting policy. A policy-withheld result, an evaluation-only block, computational failure, diagnostic failure, structural inapplicability, and a missing infrastructure job remain separate states.

Population diagnostics differentiate the complete two-Gram functional in 306 normalized symmetric directions at three fixed central steps. All 1,836 signed roles per case are retained, including failures/blocks. Linear influence covariances use the occurrence formula; the conditional multinomial covariance differs by (m−1)/m. Gaussian fourth moments use the actual paired latent/noise law. The sparse model has no Gaussian analytic oracle. The AR(1) multiplier is a labeled dependence diagnostic and changes neither the candidate nor its iid support contract.

See `IMPLEMENTATION.md` for the implementation map, `PROVENANCE.md` for restored source identities, and `ROADMAP.md` for the bounded next target. Complete execution tables include raw data, all weights/states, both-frame fits and deletion ledgers, unmasked covariance/scatter arrays, population matrices, policy cohorts, finite-B pairings, and full non-delivery accounting. CSVs accompany every plot. Every unavailable cell is retained. No clipping or silent removal of infinite diagnostic tails is permitted.

## Scope

The descriptive package, alignment, movement, cluster correspondence and paired-unit research bootstrap already exist in the verified ancestry. S07-I1 does not establish calibrated coverage, bootstrap cluster stability, UMAP support, CRAN readiness or journal readiness. S07 is the last planned mechanism study before the v0.1 scope decision; it is not an automatic trigger for another calibration study.
