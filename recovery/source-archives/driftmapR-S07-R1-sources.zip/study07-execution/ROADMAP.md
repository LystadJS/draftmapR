# Roadmap after S07-I1

1. Verify the completed I1 freeze, then execute the original S07-D1 plan in a new output directory when authorized. Keep every planned denominator and distinguish infrastructure incompleteness, computational non-delivery, evaluation blocks, policy withholding, diagnostic non-delivery, and structural inapplicability.
2. Review the prespecified covariance/shape, nonlinear remainder/centering, finite-B, dependence and selection contrasts. Do not choose a screen by observed coverage and do not interpret engineering figures as calibration.
3. Make the v0.1 scope decision required by S07-D1: specify one concrete inferential revision for later independent validation, or release the descriptive/core package with uncertainty explicitly experimental and coverage claims deferred. Do not automatically schedule another calibration for a small secondary deficit.
4. Complete package-level release documentation, examples, install/check portability and API review within the chosen scope. Cluster correspondence already exists; bootstrap cluster stability is a separate future capability.

Progress should be reported as milestones, not a fabricated percentage: descriptive/core, cluster correspondence and research bootstrap are implemented in the verified ancestry; S07 implementation completion is determined by the I1 freeze gate. Reserved S07 execution, interpretation and the v0.1 release decision remain subsequent work.
