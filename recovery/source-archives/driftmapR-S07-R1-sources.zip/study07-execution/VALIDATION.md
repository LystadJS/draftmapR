# S07-I1 engineering validation

Final validation is bound to the complete current R/Python source grid and the
pinned numerical runtime. The immutable freeze files carry the exact identities.

| Validation layer | Final result |
|---|---:|
| Restored S07-D1 and vendored ancestry | 352 files verified |
| Inherited package assertions | 2,622 passed |
| S07 engineering assertions | 219 passed; zero failures, errors, warnings or skips |
| Independent Python/adversarial tests | 24 passed |
| Complete engineering grid | 12/12 panels; 1,564 planned draws |
| Full-estimator mechanical checks | 811,539 passed |
| Independent final audit | 729,443 assertions passed |
| Retained original-unit deletion slots | 124,368 |
| Population perturbation roles | 16,524, plus nine base roles |
| Public audit records | 10,381; 10,334 finite numerical comparisons |
| Physical control audit records | 681, with unavailable comparisons retained |
| Figures | Four PNGs and four exact-value CSVs; visually reviewed |
| Reserved S07 measurements / weight vectors | 0 / 0 |

The final grid uses only seed 781 / dataset 999. Its full-estimator draws are
967 and normal-control draws are 597. It tests the actual 799/199 nesting,
normal controls at m=40/160/640, sparse/dependence cases, public PCA and
classical-MDS adapters, physical deletions, population derivatives and Gaussian
moments, complete policy cohorts, covariance identities, outer-delete MCSE
failures, corrupted checkpoints and export corruption.

Unavailable public/physical comparisons are retained and are not described as
numerical agreements. Missing infrastructure work prevents completion; it is
not counted as statistical non-delivery. The source/runtime identity check
also rejected a pre-freeze draft after its figure source changed.

Pre-freeze engineering found and repaired prefix delivery metadata, empty-cohort
boolean handling, CSV quoting/schema inconsistencies and interrupted append
exports. The final collector uses verified immutable chunks and atomic gzip
publication. Final validation was rerun with the completed sources; earlier
failed runs are not counted as passing evidence.

The restored source package (0.0.8.9000) builds. Its ordinary package check was
blocked by missing documentation suggestions. With forced suggestions disabled
and manual/vignette building disabled, examples and tests passed; check status
was **2 WARNINGs and 1 NOTE**, all concerning unavailable documentation tools
or unbuilt vignettes. roxygen2, knitr and rmarkdown were unavailable. The pinned
installed estimator (0.0.7.9000) was not replaced.

These are engineering results, not calibrated-coverage evidence. Actual Study
07 execution and its v0.1 scope decision remain subsequent work. There is no
new claim of CRAN readiness, journal readiness or bootstrap cluster stability.
