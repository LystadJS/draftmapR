"""Independent S07 arithmetic. No random-number calls and no R invocation."""
import csv,gzip,math,statistics
from collections import defaultdict
from pathlib import Path
import numpy as np
class Checks:
    def __init__(self): self.count=0
    def check(self,ok,label):
        self.count+=1
        if not ok: raise AssertionError(label)
    def near(self,a,b,label,rtol=1e-8,atol=1e-10): self.check(np.allclose(arr(a),arr(b),rtol=rtol,atol=atol,equal_nan=True),label)
def number(x):
    if x is None or (isinstance(x,str) and x in ('NA','NaN','null','')):return float('nan')
    return float(x)
def arr(x):
    if isinstance(x,np.ndarray):return x.astype(float)
    if isinstance(x,(list,tuple)):return np.array([arr(v) for v in x],dtype=float)
    return number(x)
def integer(x):
    n=number(x)
    if not math.isfinite(n) or n!=int(n):raise AssertionError('Invalid integer')
    return int(n)
def boolean(x):
    if x is True or x=='TRUE':return True
    if x is False or x=='FALSE':return False
    if x is None or x=='NA':return None
    raise AssertionError('Invalid boolean')
def read(path):
    p=Path(path)
    with (gzip.open(p,'rt',newline='') if p.suffix=='.gz' else p.open(newline='')) as f:yield from csv.DictReader(f)
def groups(rows,keys):
    d=defaultdict(list)
    for r in rows:d[tuple(str(r[k]) for k in keys)].append(r)
    return d
def unique(rows,keys):
    d={}
    for r in rows:
        k=tuple(str(r[a]) for a in keys)
        if k in d:raise AssertionError('Duplicate identity '+str(k))
        d[k]=r
    return d
def spd(S):
    S=arr(S)
    if S.shape!=(2,2) or not np.all(np.isfinite(S)):return False
    e=np.linalg.eigvalsh(S)
    return e[1]>0 and e[0]>1e-8*e[1]
def covrow(r,prefix=''):return np.array([[number(r[prefix+'var_dx']),number(r[prefix+'cov_dx_dy'])],[number(r[prefix+'cov_dx_dy']),number(r[prefix+'var_dy'])]])
def quad(x,S):return float(np.asarray(x)@np.linalg.solve(S,np.asarray(x)))
def quantile(x,p):
    x=sorted(v for v in x if not math.isnan(v))
    if not x:return math.nan
    h=(len(x)-1)*p;l=int(math.floor(h));u=int(math.ceil(h))
    if l==u or x[l]==x[u]:return x[l]
    return (1-(h-l))*x[l]+(h-l)*x[u]
def distribution(x):
    z=[v for v in x if not math.isnan(v)];f=[v for v in z if math.isfinite(v)]
    return dict(n_planned=len(x),n_available=len(z),n_finite=len(f),n_pos_inf=sum(v==math.inf for v in z),n_neg_inf=sum(v==-math.inf for v in z),mean=sum(z)/len(z) if z else math.nan,sd=statistics.stdev(z) if len(z)>1 and len(z)==len(f) else math.nan,q10=quantile(z,.1),median=quantile(z,.5),q90=quantile(z,.9),q95=quantile(z,.95),maximum=max(z) if z else math.nan)
def proportion(k,n):
    z=statistics.NormalDist().inv_cdf(.975)
    p=k/n if n else math.nan;c=(p+z*z/(2*n))/(1+z*z/n) if n else math.nan;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n) if n else math.nan
    return dict(numerator=k,denominator=n,estimate=p,mcse=math.sqrt(p*(1-p)/n) if n else math.nan,wilson_lower=max(0,c-h) if n else math.nan,wilson_upper=min(1,c+h) if n else math.nan)
COHORTS=('all','eligible_pass','eligible_fail','eligible_unknown','outside_contract','assumptions_unknown')
def selected(r,c):
    if c=='all':return True
    if c=='outside_contract':return r['support_status']=='outside_contract'
    if c=='assumptions_unknown':return r['support_status']=='unknown'
    return r['support_status']=='eligible' and r['screen_status']==c.removeprefix('eligible_')
def scopes(rows):
    out=[]
    for r in rows:
        if 'budget' not in r:out.append(dict(r,budget='0',scope='budget_independent'))
        else:
            if integer(r['budget'])==integer(r['primary_budget']):out.append(dict(r,scope='primary'))
            if boolean(r['extension_planned']):out.append(dict(r,scope='prespecified_budget_subset'))
    return out
def points(K):
    K=arr(K);v,U=np.linalg.eigh((K+K.T)/2);v=v[::-1];U=U[:,::-1]
    if v[0]<=0 or v[1]<=1e-10*v[0] or v[-1]<-1e-10*v[0] or v[1]-v[2]<=1e-10*v[0]:raise ValueError('Unidentified population plane')
    return U[:,:2]*np.sqrt(v[:2])
def register(x,y,anchors):
    a=x[anchors];b=y[anchors];ma=a.mean(0);mb=b.mean(0);a=a-ma;b=b-mb;a=a/np.max(abs(a));b=b/np.max(abs(b))
    sa=np.linalg.svd(a,compute_uv=False);sb=np.linalg.svd(b,compute_uv=False);U,s,V=np.linalg.svd(a.T@b)
    if sa[1]<=1e-10*sa[0] or sb[1]<=1e-10*sb[0] or s[1]<=1e-10*s[0]:raise ValueError('Unidentified registration')
    return (x-ma)@(U@V)+mb
def functional(K,A,anchors,targets):
    x=register(points(K[0]),arr(A),anchors);y=register(points(K[1]),x,anchors);return (y-x)[targets]
def helmert():
    Q=np.zeros((18,17))
    for k in range(17):Q[:k+1,k]=-1;Q[k+1,k]=k+1;Q[:,k]/=np.sqrt((k+1)*(k+2))
    basis=[]
    for a in range(17):
        for b in range(a,17):
            E=np.zeros((17,17));E[a,b]=E[b,a]=1 if a==b else 1/np.sqrt(2);basis.append(E)
    return Q,np.array(basis)
