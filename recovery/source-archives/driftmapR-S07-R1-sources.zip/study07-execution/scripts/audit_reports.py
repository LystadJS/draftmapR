import math,statistics
import numpy as np
from audit_math import *
def audit_reports(A,out):
    out=Path(out);analysis=out/'analysis';compact=out/'tables/compact';keys=('case_id','frame','entity','method','scope','budget')
    for kind in ('full','linear','analytic','normal'):
        f=compact/(('regions' if kind=='full' else kind+'_regions')+'.csv.gz')
        if not f.exists():continue
        raw=list(read(f));rr=scopes(raw);G=groups(rr,keys);reports=unique(read(analysis/(kind+'-coverage.csv')),keys+('policy_cohort','policy'));expected=set()
        tails=unique(read(analysis/(kind+'-tails.csv')),keys+('policy_cohort','policy','metric','selection'))
        for k,g in G.items():
            cohorts=COHORTS if 'support_status' in g[0] else ('all',)
            for co in cohorts:
                z=[r for r in g if selected(r,co)]
                for policy in (('original','T1_restricted') if kind=='full' else ('diagnostic_original',)):
                    key=k+(co,policy);expected.add(key);r=reports[key];d=[a for a in z if boolean(a['delivered']) and (policy!='T1_restricted' or selected(a,'eligible_pass'))];M=len(z);D=len(d);C=sum(boolean(a['covered']) for a in d);Z=sum(boolean(a['rejects_zero']) for a in d)
                    for field,val in dict(N_unstratified=len(g),M=M,D=D,C=C,Z=Z).items():A.check(integer(r[field])==val,'Coverage denominator/count '+field)
                    for name,(n,den) in dict(delivery=(D,M),coverage=(C,D),covered_yield=(C,M),zero_exclusion=(Z,D),detected_yield=(Z,M)).items():
                        for fld,val in proportion(n,den).items():A.near(r[name+'_'+fld],val,'Wilson/count/MCSE '+name+' '+fld)
                    if kind=='full':
                        for fld,val in dict(candidate_unknown=sum(boolean(a['candidate_region_delivered']) is None for a in z),demonstrated_candidate_nondelivery=sum(boolean(a['candidate_region_delivered']) is False for a in z),evaluation_only_blocks=sum(boolean(a['evaluation_only_block']) for a in z),policy_withheld=sum(not selected(a,'eligible_pass') for a in z)).items():A.check(integer(r[fld])==val,'Non-delivery distinction '+fld)
                    for metric in ('area_raw','cutoff_raw'):
                        for selection,zz in (('all',z),('delivered',d)):
                            row=tails[key+(metric,selection)]
                            for field,val in distribution([number(a[metric]) for a in zz]).items():A.near(row[field],val,'Uncapped distribution '+field)
        A.check(set(reports)==expected,'Exact coverage grid with empty cohorts');A.check(len(tails)==len(expected)*4,'Exact tail grid')
        reasons=unique(read(analysis/(kind+'-nondelivery.csv')),keys+('policy_cohort','policy','reason'))
        for key,row in reasons.items():
            g=G[key[:len(keys)]];co,policy,why=key[len(keys):];z=[r for r in g if selected(r,co)];actual=[r['nondelivery_reason'] if kind=='full' else 'delivered' if boolean(r['delivered']) else r['reason'] for r in z];A.check(integer(row['M'])==len(z) and integer(row['count'])==actual.count(why),'Computational reasons kept separate from policy')

    if not (compact/'regions.csv.gz').exists():return
    # Matched error covariance, own/joint cohorts, cross terms, and all component RMSEs.
    G=groups(read(compact/'decomposition_inputs.csv.gz'),('case_id','frame','entity'));er=unique(read(analysis/'errors.csv'),('case_id','frame','entity','policy_cohort','availability_cohort','estimator'));de=unique(read(analysis/'error-decomposition.csv'),('case_id','frame','entity','policy_cohort'))
    for k,g in G.items():
        for co in COHORTS:
            z=[r for r in g if selected(r,co)];f=np.array([[number(r['full_error_dx']),number(r['full_error_dy'])] for r in z]).reshape(-1,2);l=np.array([[number(r['linear_error_dx']),number(r['linear_error_dy'])] for r in z]).reshape(-1,2);rem=f-l;ff=np.isfinite(f).all(1);lf=np.isfinite(l).all(1);joint=ff&lf;dr=de[k+(co,)];A.check(integer(dr['N_joint'])==sum(joint),'Exact joint decomposition cohort')
            if sum(joint)>1:
                S=np.cov(np.concatenate((f[joint],l[joint],rem[joint]),axis=1),rowvar=False);C=S[:2,:2];L=S[2:4,2:4];R=S[4:,4:];X=S[2:4,4:];A.near(C,L+R+X+X.T,'Covariance cross-term identity')
                for name,mat in dict(full=C,linear=L,remainder=R,cross=X).items():
                    for a in range(2):
                        for b in range(2):A.near(dr[name+'_cov_'+str(a+1)+str(b+1)],mat[a,b],'Reported covariance decomposition')
            for name,v,own in (('full',f,ff),('linear',l,lf),('remainder',rem,joint)):
                for avail,use in (('own_available',own),('joint',joint)):
                    r=er[k+(co,avail,name)];x=v[use];n=len(x);A.check(integer(r['n'])==n,'Error cohort count');mu=x.mean(0) if n else [np.nan]*2;rmse=np.sqrt(np.mean(x*x,axis=0)) if n else [np.nan]*2;S=np.cov(x,rowvar=False) if n>1 else np.full((2,2),np.nan)
                    for fld,val in dict(bias_dx=mu[0],bias_dy=mu[1],rmse_dx=rmse[0],rmse_dy=rmse[1],euclidean_rmse=np.sqrt(sum(np.array(rmse)**2)),var_dx=S[0,0],var_dy=S[1,1],cov_dx_dy=S[0,1]).items():A.near(r[fld],val,'Error/RMSE arithmetic '+fld)
    audit_covariance(A,compact,analysis)
    # Sparse bins are an explicit complete grid, including bins with zero panels.
    sk=('case_id','frame','entity','method','budget');sparse=unique(read(analysis/'sparse-delivery.csv'),sk+('rare_bin',));G=groups([r for r in read(compact/'regions.csv.gz') if r['rare_bin']!='not_sparse'],sk);expected_sparse=set()
    for k,g in G.items():
        for bin in ('0','1','2','3','4+'):
            key=k+(bin,);expected_sparse.add(key);r=sparse[key];z=[x for x in g if x['rare_bin']==bin];d=[x for x in z if boolean(x['delivered'])]
            for f,v in dict(M=len(g),N_in_bin=len(z),D=len(d),C=sum(boolean(x['covered']) for x in d),observed_available=sum(boolean(x['observed_success']) for x in z),evaluation_only_blocks=sum(boolean(x['evaluation_only_block']) for x in z),policy_withheld=sum(not selected(x,'eligible_pass') for x in z)).items():A.check(integer(r[f])==v,'Sparse bin accounting '+f)
    A.check(set(sparse)==expected_sparse,'Complete sparse bins, including empty bins')
    tails=unique(read(analysis/'remainder-tails.csv'),('case_id','frame','entity','policy_cohort'));G=groups(read(compact/'decomposition_inputs.csv.gz'),('case_id','frame','entity'))
    for k,g in G.items():
        for co in COHORTS:
            v=[math.hypot(number(r['remainder_dx']),number(r['remainder_dy'])) for r in g if selected(r,co)];row=tails[k+(co,)]
            for f,x in distribution(v).items():A.near(row[f],x,'Uncapped remainder tail '+f)

    # Paired comparisons use exactly the prescribed extension subset.
    raw=[r for r in read(compact/'regions.csv.gz') if boolean(r['extension_planned'])];G=groups(raw,('case_id','frame','entity','method'));pr=unique(read(analysis/'budget-comparisons.csv'),('case_id','frame','entity','method','policy_cohort','policy'))
    for k,g in G.items():
        low=unique([r for r in g if integer(r['budget'])==199],('dataset_id',));high=unique([r for r in g if integer(r['budget'])==799],('dataset_id',));A.check(set(low)==set(high),'Paired same-panel subset')
        for co in COHORTS:
            ids=[i for i in low if selected(low[i],co)]
            for policy in ('original','T1_restricted'):
                r=pr[k+(co,policy)];a=[low[i] for i in ids];b=[high[i] for i in ids];da=np.array([boolean(x['delivered']) and (policy=='original' or selected(x,'eligible_pass')) for x in a],dtype=bool);db=np.array([boolean(x['delivered']) and (policy=='original' or selected(x,'eligible_pass')) for x in b],dtype=bool);ca=np.array([boolean(x['covered']) is True for x in a],dtype=bool);cb=np.array([boolean(x['covered']) is True for x in b],dtype=bool);common=da&db
                vals=dict(delivery_difference=db.astype(int)-da.astype(int),covered_yield_difference=(db&cb).astype(int)-(da&ca).astype(int),common_coverage_difference=cb[common].astype(int)-ca[common].astype(int),log_area_ratio=[math.log(number(y['area'])/number(x['area'])) for x,y,u in zip(a,b,common) if u],log_cutoff_ratio=[math.log(number(y['cutoff'])/number(x['cutoff'])) for x,y,u in zip(a,b,common) if u])
                for fld,v in dict(M=len(ids),common_delivery=sum(common),delivery_gain=sum(~da&db),delivery_loss=sum(da&~db),coverage_gain_common=sum(common&~ca&cb),coverage_loss_common=sum(common&ca&~cb)).items():A.check(integer(r[fld])==v,'Paired discordance counts')
                for fld,v in vals.items():A.near(r[fld],np.mean(v) if len(v) else np.nan,'Paired mean');A.near(r[fld+'_mcse'],np.std(v,ddof=1)/np.sqrt(len(v)) if len(v)>1 and np.isfinite(v).all() else np.nan,'Paired MCSE')
    # Across-panel selection summaries (no within-bootstrap pseudo-replication).
    sk=('case_id','frame','entity','budget','metric','contrast');G=groups(read(compact/'selection_panel.csv.gz'),sk);summ=unique(read(analysis/'selection.csv'),sk+('policy_cohort','summary_metric'))
    for k,g in G.items():
        for co in COHORTS:
            z=[r for r in g if selected(r,co)]
            for metric in ('baseline_mean','selected_mean','failed_mean','difference','selected_minus_failed'):
                r=summ[k+(co,metric)];v=[number(x[metric]) for x in z];v=[x for x in v if math.isfinite(x)];A.check(integer(r['n_finite'])==len(v),'Selection finite count');A.near(r['mean'],np.mean(v) if v else np.nan,'Selected centering');A.near(r['mcse'],statistics.stdev(v)/math.sqrt(len(v)) if len(v)>1 else np.nan,'Across-panel selection MCSE')
def ratios(A,S):
    if not spd(S) or not np.isfinite(A).all():return dict(trace=math.nan,minimum=math.nan,maximum=math.nan)
    e,U=np.linalg.eigh(S);W=U/np.sqrt(e);v=np.linalg.eigvalsh(W.T@A@W);return dict(trace=np.trace(A)/np.trace(S),minimum=v[0],maximum=v[1])
def covstats(z):
    n=len(z);e=np.array([[number(r['error_dx']),number(r['error_dy'])] for r in z]);S=np.cov(e,rowvar=False) if n>1 else np.full((2,2),np.nan);A=np.mean([covrow(r) for r in z],axis=0) if n else np.full((2,2),np.nan);v={}
    for prefix,M in (('empirical_',S),('estimated_',A)):
        for fld,value in dict(var_dx=M[0,0],var_dy=M[1,1],cov_dx_dy=M[0,1]).items():v[prefix+fld]=value
    v.update({'estimated_to_empirical_'+k:x for k,x in ratios(A,S).items()})
    for kind in ('iid','dependence'):
        O=np.mean([[[number(r['oracle_'+kind+'_xx']),number(r['oracle_'+kind+'_xy'])],[number(r['oracle_'+kind+'_xy']),number(r['oracle_'+kind+'_yy'])]] for r in z],axis=0) if n else np.full((2,2),np.nan)
        for prefix,M in (('estimated_',A),('empirical_',S)):v.update({prefix+'to_oracle_'+kind+'_'+k:x for k,x in ratios(M,O).items()})
    return v
def audit_covariance(A,compact,analysis):
    keys=('case_id','frame','entity','covariance_source','scope','budget');G=groups(read(compact/'covariance_inputs.csv.gz'),keys);summary=unique(read(analysis/'covariance.csv'),keys+('policy_cohort',));deletions=unique(read(analysis/'covariance-outer-deletions.csv'),keys+('policy_cohort','deleted_dataset_id'));expected=set();outer=set()
    for k,g in G.items():
        for co in COHORTS:
            key=k+(co,);expected.add(key);r=summary[key];z=[x for x in g if selected(x,co) and all(math.isfinite(number(x[f])) for f in ('error_dx','error_dy','var_dx','var_dy','cov_dx_dy'))];n=len(z);A.check(integer(r['n_matched'])==n,'Matched covariance cohort');v=covstats(z)
            for f,x in v.items():A.near(r[f],x,'Covariance diagnostic '+f)
            loo=[]
            for i,x in enumerate(z):
                kk=key+(x['dataset_id'],);outer.add(kk);dr=deletions[kk];A.check(boolean(dr['attempted'])==(n>=20),'Outer-delete MCSE threshold');vals=covstats(z[:i]+z[i+1:]) if n>=20 else {f:math.nan for f in v};loo.append(vals)
                for f in v:
                    if '_to_' in f:A.near(dr[f],vals[f],'Independent outer deletion '+f)
            for f,value in v.items():
                if '_to_' not in f:continue
                a=[x[f] for x in loo];ok=n>=20 and math.isfinite(value) and all(math.isfinite(x) for x in a);se=math.sqrt((n-1)/n*sum((x-np.mean(a))**2 for x in a)) if ok else math.nan;A.near(r[f+'_mcse'],se,'Outer MCSE exact cohort '+f)
    A.check(set(summary)==expected,'Complete covariance cohort grid');A.check(set(deletions)==outer,'Complete unique outer deletions')
