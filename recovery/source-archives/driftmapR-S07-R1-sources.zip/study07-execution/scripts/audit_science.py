import json,math
import numpy as np
from audit_math import *
def audit_population(A,r):
    Q,E=helmert();A.near(r['Q'],Q,'Independent normalized Helmert basis');K=arr(r['K']);base=arr(r['A']);anchors=arr(r['anchors']).astype(int)-1;targets=arr(r['targets']).astype(int)-1
    L=max(1,np.sqrt(np.sum(K*K)));steps=L*2.**np.array([-12,-14,-16]);A.near(r['steps'],steps,'Frozen finite differences')
    ledger=unique(r['ledger'],('direction','step_index','sign'));A.check(len(ledger)==1836,'Population role grid')
    base_ok=True
    try:truth=functional(K,base,anchors,targets)
    except ValueError:base_ok=False;truth=np.full((3,2),np.nan)
    A.check(base_ok==r['base_ok'],'Independent base identification');A.near(r['truth'],truth,'Population target')
    vals=np.full((306,3,2,3,2),np.nan)
    for d in range(306):
        t=d//153;expanded=Q@E[d%153]@Q.T
        for s,step in enumerate(steps):
            for si,sign in enumerate((-1,1)):
                row=ledger[(str(d+1),str(s+1),str(sign))];A.check(boolean(row['attempted'])==base_ok,'All required population attempts')
                pair=K.copy();pair[t]+=sign*step*expanded;ok=False
                if base_ok:
                    try: vals[d,s,si]=functional(pair,base,anchors,targets);ok=True
                    except ValueError:pass
                A.check(boolean(row['successful'])==ok,'Population attempt status');A.near(r['perturbations'][d][s][si],vals[d,s,si],'Perturbed functional',1e-7,1e-9)
    J=np.array([[(vals[:,s,1,j,:]-vals[:,s,0,j,:]).T/(2*steps[s]) for j in range(3)] for s in range(3)])
    A.near(r['jacobians'],J,'Complete independently differentiated estimator',1e-6,1e-7)
    for j,d in enumerate(r['derivative']):
        finite=np.all(np.isfinite(J[:,j]));fm=np.linalg.norm(J[2,j]-J[1,j]);mc=np.linalg.norm(J[1,j]-J[0,j]);scale=max(1,np.linalg.norm(J[2,j]));ok=finite and fm/scale<=1e-3 and (mc<=1e-10*scale or fm<=.25*mc)
        A.check(boolean(d['available'])==ok,'Derivative convergence gate')
    if r['case'][0]['scenario']=='rare_axis':A.check(r['V'] is None and all(d['omega_status']=='not_applicable_non_gaussian' for d in r['derivative']),'Sparse Gaussian oracle is inapplicable');return
    latent=arr(r['latent']);H=np.eye(18)-np.ones((18,18))/18;sigma=number(r['sigma']);rho=number(r['rho_time']);G=np.array([[Q.T@(latent[t]@latent[s].T+sigma*sigma*(1 if t==s else rho)*H)@Q for s in range(2)] for t in range(2)])
    A.near(r['Gamma'],G,'Actual latent and temporal-noise covariance')
    V=np.zeros((306,306))
    for t in range(2):
        for s in range(2):
            # Matrix trace contraction independently from the indexed R formula.
            left=E@G[t,s];right=E@G[s,t];V[t*153:(t+1)*153,s*153:(s+1)*153]=2*np.einsum('aij,bji->ab',left,right)
    A.near(r['V'],V,'All Gaussian fourth moments')
    for j,d in enumerate(r['derivative']):
        expected=J[2,j]@V@J[2,j].T if boolean(d['available']) else np.full((2,2),np.nan);A.near(r['Omega'][j],expected,'Analytic covariance contraction',1e-6,1e-8)
def audit_panel(A,p,ref=None):
    job=p['job'];m=integer(job['m']);B=integer(job['B_planned']);W=arr(p['weights']);A.check(W.shape==(B,m) and np.all(W>=0) and np.all(W==np.floor(W)) and np.all(W.sum(1)==m),'Exact paired draw counts');A.check(arr(p['streams']).shape==(B,7),'All RNG states')
    if ref is not None:
        Q,E=helmert();X=arr(p['X']);K=arr(ref['K']);h=[]
        for t in range(2):
            x=Q.T@X[t];h.append(np.einsum('ai,kab,bi->ik',x,E,x)-np.einsum('kab,ab->k',E,Q.T@K[t]@Q))
        h=np.concatenate(h,axis=1)
        for j,c in enumerate(p['controls']):
            psi=h@arr(ref['jacobians'][2][j]).T if boolean(ref['derivative'][j]['available']) else np.full((m,2),np.nan);A.near(c['values'],psi,'Paired-unit population influence')
    for control in p['controls']:
        v=arr(control['values']);truth=arr(control['truth']);rows=unique(control['parents'],('parent_id',));A.check(set(rows)=={(str(i),) for i in range(B+1)},'Complete control parent grid');finite=np.all(np.isfinite(v));mu=v.mean(0)
        for b in range(B+1):
            r=rows[(str(b),)];w=np.ones(m) if b==0 else W[b-1];A.check(boolean(r['covariance_attempted'])==finite,'Control blocked accounting')
            if not finite:continue
            mean=w@v/m;d=v-mean;S=d.T@(d*w[:,None])/(m*(m-1));A.near([r['dx'],r['dy']],truth+mean,'Weighted paired mean');A.near(covrow(r),S,'Occurrence covariance');A.near(covrow(r,'conditional_'),S*(m-1)/m,'Conditional bootstrap finite-unit factor');A.check(boolean(r['covariance_ok'])==spd(S),'Control SPD gate')
            if b and spd(S):A.near(r['pivot'],quad(mean-mu,S),'Scalar control pivot')
        regions=p.get('regions',p.get('linear_regions',[]))
        for r in [r for r in regions if r['entity']==control['entity']]:
            budget=integer(r['budget']);S=covrow(rows[('0',)]);method=r['method'];piv=[number(rows[(str(b),)]['pivot']) for b in range(1,budget+1) if boolean(rows[(str(b),)]['pivot_ok'])];expected_n=len(piv)
            cutoff=(m-1)*(.05**(-2/(m-2))-1) if method=='normal_hotelling' else -2*math.log(.05) if method=='normal_chisquare_wald' else quantile(piv,.95) if len(piv)>=20 else math.nan
            A.near(r['cutoff_raw'],cutoff,'Control finite-B/Hotelling cutoff')
            delivered=finite and spd(S) and (not method.endswith('studentized') or expected_n>=max(20,math.ceil(.95*budget))) and math.isfinite(cutoff) and cutoff>0
            A.check(boolean(r['delivered'])==delivered,'Control delivery')
            if delivered:
                center=truth+mu;A.check(boolean(r['covered'])==(quad(-mu,S)<=cutoff*(1+1e-12)),'Control truth inclusion');A.check(boolean(r['rejects_zero'])==(quad(-center,S)>cutoff*(1+1e-12)),'Control null exclusion')
    if ref is None:return
    X=arr(p['X']);anchors=arr(ref['anchors']).astype(int)-1;targets=arr(ref['targets']).astype(int)-1;Aref=arr(ref['A'])
    for f in p['frames']:
        rotation=arr(f['Q']);reference=arr(f['R0']) if f['name']=='core' and f['R0'] is not None else Aref;point=arr(f['point']);pivs=arr(f['pivots'])
        for b in range(B+1):
            w=np.ones(m) if b==0 else W[b-1];K=[(x*w)@x.T/m for x in X];ok=False
            try:v=functional(K,reference,anchors,targets)@rotation;ok=True
            except ValueError:pass
            actual=point if b==0 else arr(f['eval_values'][b-1]);available=np.all(np.isfinite(actual))
            if available:A.check(ok,'Available full estimator independently identifiable');A.near(actual,v,'Independent full estimator',1e-7,1e-9)
            c=f['covariances'][b]
            for j in range(3):
                S=arr(c['S'][j]);scatter=arr(c['scatter'][j]);A.near(S,scatter*(m-1)/m,'Unmasked occurrence scatter identity');A.check(boolean(c['covariance_ok'][j])==(bool(c['all_required_success']) and spd(S)),'Full covariance gate')
                # Native core S must be rotated to the population evaluation chart.
                evalS=rotation.T@S@rotation if f['name']=='core' else S
                if b and math.isfinite(pivs[b-1,j]):A.near(pivs[b-1,j],quad(actual[j]-point[j],evalS),'Full studentized pivot',1e-7,1e-9)
            # Public R audits cover physical expansion. A separate NumPy refit checks parents 0,1,2.
            if b<=2 and available and c['all_required_success']:
                deleted=[];ww=[]
                for i in np.flatnonzero(w):
                    wd=w.copy();wd[i]-=1;Kd=[(x*wd)@x.T/(m-1) for x in X]
                    try:deleted.append(functional(Kd,reference,anchors,targets)@rotation);ww.append(w[i])
                    except ValueError:deleted=[];break
                if deleted:
                    dv=np.array(deleted);ww=np.array(ww);means=np.einsum('i,ijk->jk',ww,dv)/m
                    for j in range(3):
                        d=dv[:,j,:]-means[j];S=(m-1)/m*d.T@(d*ww[:,None]);saved=arr(c['S'][j]);saved=rotation.T@saved@rotation if f['name']=='core' else saved;A.near(saved,S,'Independent physical weighted-deletion covariance',1e-7,1e-9)
