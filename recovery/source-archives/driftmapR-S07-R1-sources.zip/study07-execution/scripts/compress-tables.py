#!/usr/bin/env python3
"""Commit CSV products only after independently validating every immutable chunk."""
import sys
sys.dont_write_bytecode=True
import csv,gzip,hashlib,os,io,shutil
from pathlib import Path
root=Path(sys.argv[1]);manifest=root/'csv-chunk-manifest.csv'
def md5(p):
    h=hashlib.md5()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
if manifest.exists():
    groups={}
    for r in csv.DictReader(manifest.open()):groups.setdefault(r['product'],[]).append(r)
    for name,parts in groups.items():
        dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);temp=dest.with_suffix(dest.suffix+'.committing');total=0;header=None
        with temp.open('wb') as raw:
            with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
                with io.TextIOWrapper(gz,encoding='utf-8',newline='') as text:
                    writer=csv.writer(text,lineterminator='\n')
                    for r in parts:
                        p=root.parent/r['chunk'];before=md5(p)
                        if before!=r['md5']:raise AssertionError('Chunk checksum changed: '+r['chunk'])
                        with p.open(newline='') as f:
                            reader=csv.reader(f);h=next(reader)
                            if header is None:header=h;writer.writerow(header)
                            if h!=header:raise AssertionError('Chunk schema differs')
                            n=0
                            for row in reader:
                                if len(row)!=len(header):raise AssertionError('Malformed CSV record in '+r['chunk'])
                                writer.writerow(row);n+=1
                        if n!=int(r['rows']) or md5(p)!=before:raise AssertionError('Incomplete or changed chunk: '+r['chunk'])
                        total+=n
        with gzip.open(temp,'rt',newline='') as f:
            reader=csv.reader(f);next(reader);n=sum(1 for _ in reader)
        if n!=total:raise AssertionError('Compressed row count differs')
        os.replace(temp,dest)
else:
    # Small standalone compression fixture used by the engineering tests.
    for p in sorted(root.rglob('*.csv.gz.pending')):
        dest=Path(str(p).removesuffix('.pending'));temp=Path(str(dest)+'.committing');before=p.read_bytes()
        with temp.open('wb') as raw:
            with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:gz.write(before)
        with gzip.open(temp,'rb') as f:
            if f.read()!=before:raise AssertionError('Compression round trip failed')
        os.replace(temp,dest);p.unlink()
counts=root/'row-counts.csv'
if counts.exists():
    for r in csv.DictReader(counts.open()):
        with gzip.open(root/r['path'],'rt',newline='') as f:n=sum(1 for _ in csv.DictReader(f))
        if n!=int(r['rows']):raise AssertionError('Product row count mismatch: '+r['path'])
