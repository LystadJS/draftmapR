#!/usr/bin/env python3
"""Read-only audit of an exact S07 execution. Does not generate data or weights."""
import sys
sys.dont_write_bytecode=True
import argparse,json,hashlib,traceback,itertools
from pathlib import Path
import numpy as np
from audit_math import *
from audit_science import audit_population,audit_panel
from audit_reports import audit_reports

def audit(out,engineering=False):
    out=Path(out);A=Checks();jobs=list(read(out/'job-manifest.csv'));J=unique(jobs,('case_id','dataset_id'));A.check(len(jobs)==(12 if engineering else 6480),'Complete job count');expected_cases=set(range(1,10))|set(range(101,104));A.check({integer(j['case_index']) for j in jobs}==expected_cases,'All frozen cases')
    if engineering:
        for j in jobs:A.check(integer(j['dataset_id'])==999 and integer(j['bootstrap_seed'])==781 and j['stage']=='s07_engineering_fixture' and j['data_stream']=='10407;-1342632488;-1644425735;1569052006;-2056777553;769474340;897868757','Engineering seed domain')
    else:
        for ci in sorted(expected_cases):
            g=[j for j in jobs if integer(j['case_index'])==ci];M=2000 if ci>=101 else [80,80,40,60,60,40,40,40,40][ci-1];A.check({integer(j['dataset_id']) for j in g}==set(range(1,M+1)),'Untouched reserved ID grid')
            for j in g:A.check(integer(j['bootstrap_seed'])==7400000+10000*ci+integer(j['dataset_id']),'Reserved bootstrap seed')
    for j in jobs:
        ci=integer(j['case_index']);m=[40,160,640][ci-101] if ci>=101 else [40,160,640,40,40,160,160,12,160][ci-1];B=(799 if ci==1 else 199 if ci>=101 else 21) if engineering else (799 if ci in (1,2) and integer(j['dataset_id'])<=20 else 199);A.check(integer(j['m'])==m and integer(j['B'])==B,'Frozen case/budget adapter')
    manifest=list(read(out/'content-manifest.csv'));expected={r['path'] for r in manifest};actual={str(p.relative_to(out)) for root in ('tables','analysis') for p in (out/root).rglob('*') if p.is_file()};A.check(len(expected)==len(manifest) and expected==actual,'Exact exported file grid')
    for r in manifest:
        p=out/r['path'];A.check(p.stat().st_size==integer(r['bytes']) and hashlib.md5(p.read_bytes()).hexdigest()==r['md5'],'Product checksum '+r['path'])
    index=unique(read(out/'tables/checkpoint-index.csv'),('case_id','dataset_id'));A.check(set(index)==set(J),'Complete checkpoint catalog')
    for k,r in index.items():p=out/'checkpoints'/r['checkpoint'];A.check(p.exists() and hashlib.md5(p.read_bytes()).hexdigest()==r['md5'],'Checkpoint identity bytes')
    refs={}
    for p in sorted((out/'tables/population').glob('*.json')):
        r=json.loads(p.read_text());audit_population(A,r);refs[p.stem]=r
    A.check(len(refs)==9,'All population reference diagnostics')
    draw_groups=iter(itertools.groupby(read(out/'tables/draws.csv.gz'),lambda r:(r['case_id'],r['dataset_id'])))
    full=0;normal=0;panels={}
    for key,j in J.items():
        p=out/'tables/panels'/f"{j['case_id']}-{integer(j['dataset_id']):04d}.json";z=json.loads(p.read_text());audit_panel(A,z,refs.get(j['case_id']));W=arr(z['weights']);drawkey,group=next(draw_groups);g=list(group);A.check(drawkey==key and len(g)==integer(j['B']),'Planned draw identities retained')
        for b,r in enumerate(g):A.check(integer(r['replicate_id'])==b+1,'Unique ordered draw IDs');A.near([int(x) for x in r['weights'].split(';')],W[b],'Draw ledger and checkpoint weights');A.near([int(x) for x in r['rng_stream'].split(';')],z['streams'][b],'Draw ledger and checkpoint states')
        if j['pipeline']=='full_estimator':
            panels[key]=dict(W=W,m=integer(j['m']),B=integer(j['B']));full+=integer(j['B'])
        else:normal+=integer(j['B'])
    # Stream complete deletion slots, preserving zero multiplicities and blocked work.
    A.check(next(draw_groups,None) is None,'No extra draw groups')
    n=0;seen=set();current=None;rows=[];core_success={}
    def deletion_group(k,rows):
        p=panels[k[:2]];b=integer(k[3]);m=p['m'];w=np.ones(m) if b==0 else p['W'][b-1];A.check(len(rows)==m and [integer(r['unit_index']) for r in rows]==list(range(1,m+1)),'Complete original-unit deletion slots');A.near([integer(r['multiplicity']) for r in rows],w,'Deletion multiplicities');A.check(all(boolean(r['required'])==(w[i]>0) and (not boolean(r['attempted']) or w[i]>0) and (not boolean(r['success']) or boolean(r['attempted'])) for i,r in enumerate(rows)),'Deletion dependency balances')
        # Required positive deletions must all be attempted together, even after failures.
        positive=[r for r in rows if boolean(r['required'])];attempts=[boolean(r['attempted']) for r in positive]
        kk=k[:2]+(k[3],)
        if k[2]=='core':
            A.check(not any(attempts) or all(attempts),'No early stopping of required core deletions');core_success[kk]=[boolean(r['success']) for r in rows]
        else:A.check([boolean(r['attempted']) for r in rows]==core_success[kk],'Frame deletion attempts follow each core success, including partial failures')
    for r in read(out/'tables/full/deletions.csv.gz'):
        k=(r['case_id'],r['dataset_id'],r['frame'],r['parent_id'])
        if k!=current:
            if rows:deletion_group(current,rows)
            A.check(k not in seen,'Unique deletion parent block');seen.add(k);current=k;rows=[]
        rows.append(r);n+=1
    if rows:deletion_group(current,rows)
    expected={(j['case_id'],j['dataset_id'],f,str(b)) for j in jobs if j['pipeline']=='full_estimator' for f in ('core','frame') for b in range(integer(j['B'])+1)};A.check(seen==expected,'Exact two-frame deletion grid')
    expected_n=sum(2*(integer(j['B'])+1)*integer(j['m']) for j in jobs if j['pipeline']=='full_estimator');A.check(n==expected_n,'All planned deletion slots')
    for f in ('stage-accounting','control-stage-accounting'):
        for r in read(out/'tables'/(f+'.csv')):
            A.check(integer(r['required'])==integer(r['attempted'])+integer(r['unattempted_required']),'Stage required balance');A.check(integer(r['attempted'])==integer(r['successful'])+integer(r['failed_after_attempt']),'Stage attempted balance')
    for r in read(out/'tables/row-counts.csv'):A.check(sum(1 for _ in read(out/'tables'/r['path']))==integer(r['rows']),'CSV row count')
    public=list(read(out/'tables/public-audit.csv'));A.check(all(boolean(r['passed']) for r in public),'All prescribed public audits')
    for j in jobs:
        if j['pipeline']!='full_estimator' or not(engineering or integer(j['dataset_id'])==1):continue
        g=[r for r in public if r['case_id']==j['case_id'] and r['dataset_id']==j['dataset_id'] and r['audit_type']=='full_bootstrap_classical_mds'];A.check(len(g)==2*integer(j['B']),'Every-draw two-frame classical-MDS audit')
    for r in public:A.check(not boolean(r['numerically_compared']) or boolean(r['passed']),'Blocked audit is not numeric agreement')
    control=list(read(out/'tables/control-audit.csv'));A.check(all(boolean(r['passed']) for r in control),'Physical control audit')
    for j in jobs:
        if j['pipeline']=='normal_mean_control' and (engineering or integer(j['dataset_id'])<=2):A.check(sum(r['case_id']==j['case_id'] and r['dataset_id']==j['dataset_id'] for r in control)==integer(j['B'])+1,'All normal physical audits')
    # Exact planned region identities: a whole missing method/target cannot disappear silently.
    for kind in ('full','linear','normal','analytic'):
        name='regions' if kind=='full' else kind+'_regions';raw=list(read(out/'tables/compact'/(name+'.csv.gz')))
        fields=('case_id','dataset_id','frame','entity','method')+(() if kind=='analytic' else ('budget',));actual=unique(raw,fields);expected=set()
        for j in jobs:
            is_normal=j['pipeline']=='normal_mean_control'
            if is_normal!=(kind=='normal'):continue
            budgets=sorted({integer(j['B']),integer(j['B_primary'])})
            targets=('mean',) if is_normal else ('E015','E003','E006')
            frames=('normal_mean',) if is_normal else ('population_linear',) if kind=='linear' else ('core','population_frame_oracle','population_linear') if kind=='analytic' else ('core','population_frame_oracle')
            methods=('normal_hotelling','normal_chisquare_wald','normal_bootstrap_studentized') if is_normal else ('linear_studentized',) if kind=='linear' else (('analytic_iid','analytic_dependence') if integer(j['case_index'])==9 else ('analytic_iid',)) if kind=='analytic' else ('wald','bootstrap_mahalanobis','bootstrap_ball','jackknife_wald','jackknife_studentized')
            for frame in frames:
                for entity in targets:
                    for method in methods:
                        base=(j['case_id'],j['dataset_id'],frame,entity,method)
                        if kind=='analytic':expected.add(base)
                        else:expected.update(base+(str(b),) for b in budgets)
        A.check(set(actual)==expected,'Exact '+kind+' region grid')
    audit_reports(A,out)
    for i in range(1,5):A.check((out/'analysis'/f'figure-{i:02d}.png').stat().st_size>1000 and sum(1 for _ in read(out/'analysis'/f'figure-{i:02d}-values.csv'))>0,'Four figures with exact scalar values')
    report=dict(status='passed',engineering=engineering,panels=len(jobs),planned_draws=full+normal,full_draws=full,normal_draws=normal,deletion_slot_rows=n,assertions=A.count,population_roles=9*1836,public_audit_rows=len(public),control_audit_rows=len(control),reserved_panels_generated=0,reserved_draws_generated=0,meaning='Read-only audit generated no measurements or draw weights.')
    (out/'final-audit.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');p.add_argument('--engineering',action='store_true');args=p.parse_args()
    try:print(json.dumps(audit(args.out,args.engineering)))
    except Exception as e:
        (Path(args.out)/'final-audit-failed.json').write_text(json.dumps(dict(status='failed',message=str(e)),indent=2)+'\n');raise
