#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
import hashlib,json
from pathlib import Path

def inventory(root):
    root=Path(root);return {str(p.relative_to(root)):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in sorted(root.rglob('*')) if p.is_file() and p.name not in ('implementation-freeze.json','implementation-freeze.rds')}
def verify(root):
    root=Path(root);lock=json.loads((root/'implementation-freeze.json').read_text());expected=lock['sha256_files'];actual=inventory(root)
    if expected!=actual:raise AssertionError('Frozen exact file grid or SHA256 mismatch')
    return dict(status='passed',freeze_id=lock['freeze_id'],files=len(actual),freeze_sha256=hashlib.sha256((root/'implementation-freeze.json').read_bytes()).hexdigest())
if __name__=='__main__':
    if sys.argv[1]=='inventory':print(json.dumps(inventory(sys.argv[2])))
    elif sys.argv[1]=='verify':print(json.dumps(verify(sys.argv[2])))
    else:raise SystemExit('Usage: manifest.py inventory|verify ROOT')
