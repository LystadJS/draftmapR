args<-commandArgs(TRUE);if(length(args)<2L||!args[1]%in%c('engineering','reserved'))stop('Usage: run.R engineering|reserved OUTPUT [WORKERS]')
script<-sub('^--file=','',commandArgs(FALSE)[grepl('^--file=',commandArgs(FALSE))][1]);p<-normalizePath(file.path(dirname(script),'..'));source(file.path(p,'R/load.R'));s07i_load(p)
s07i_run(args[2],if(length(args)>2L)as.integer(args[3])else 4L,engineering=args[1]=='engineering')
