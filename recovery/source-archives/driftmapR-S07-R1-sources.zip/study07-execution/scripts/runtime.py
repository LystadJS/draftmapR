import sys,json,hashlib,platform
sys.dont_write_bytecode=True
from pathlib import Path
import numpy as np
import numpy._core._multiarray_umath as core
print(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,files=[dict(name=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [Path(sys.executable).resolve(),Path(core.__file__).resolve()]]),sort_keys=True))
