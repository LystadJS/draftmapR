#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
import unittest,tempfile,json,hashlib,copy,importlib.util,subprocess,gzip
from pathlib import Path
import numpy as np
from audit_math import *
from audit_science import audit_panel
from audit_reports import audit_covariance
from manifest import inventory,verify
class Tests(unittest.TestCase):
    def test_integer_rejects_fraction(self):
        with self.assertRaises(AssertionError):integer('1.2')
    def test_boolean_rejects_ambiguous(self):
        with self.assertRaises(AssertionError):boolean('maybe')
    def test_duplicate_identity(self):
        with self.assertRaises(AssertionError):unique([{'id':'1'},{'id':'1'}],('id',))
    def test_mixed_width_keys(self):self.assertEqual(set(unique([{'id':'80'},{'id':'160'}],('id',))),{('80',),('160',)})
    def test_spd_rejects_singular(self):self.assertFalse(spd([[1,1],[1,1]]));self.assertFalse(spd([[1,0],[0,1e-9]]))
    def test_wilson_empty(self):self.assertTrue(math.isnan(proportion(0,0)['estimate']))
    def test_wilson_known(self):p=proportion(5,10);self.assertAlmostEqual(p['estimate'],.5);self.assertAlmostEqual(p['wilson_lower'],.2365930905,9)
    def test_infinite_tails(self):d=distribution([1,2,math.inf,math.inf,math.nan]);self.assertEqual(d['n_pos_inf'],2);self.assertEqual(d['q95'],math.inf)
    def test_fraction_interpolation(self):self.assertEqual(quantile([0,1,3,6],.5),2)
    def test_orthonormal_basis(self):Q,E=helmert();np.testing.assert_allclose(Q.T@Q,np.eye(17),atol=1e-14);np.testing.assert_allclose(np.einsum('aij,bij->ab',E,E),np.eye(153),atol=1e-14)
    def test_manifest_changes(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'a').write_text('original');lock=dict(freeze_id='test',sha256_files=inventory(p));(p/'implementation-freeze.json').write_text(json.dumps(lock));self.assertEqual(verify(p)['status'],'passed');(p/'a').write_text('changed')
            with self.assertRaises(AssertionError):verify(p)
    def test_manifest_missing(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'a').write_text('x');lock=dict(freeze_id='test',sha256_files=inventory(p));(p/'implementation-freeze.json').write_text(json.dumps(lock));(p/'a').unlink()
            with self.assertRaises(AssertionError):verify(p)
    def test_manifest_extra(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'implementation-freeze.json').write_text(json.dumps(dict(freeze_id='test',sha256_files={})));(p/'extra').write_text('x')
            with self.assertRaises(AssertionError):verify(p)
    def panel(self):return json.loads((GRID/'tables/panels/s07_normal_mean_m40-0999.json').read_text())
    def test_normal_independent_reconstruction(self):audit_panel(Checks(),self.panel())
    def test_corrupt_weight(self):
        p=self.panel();p['weights'][0][0]+=1
        with self.assertRaises(AssertionError):audit_panel(Checks(),p)
    def test_corrupt_pivot(self):
        p=self.panel();p['controls'][0]['parents'][1]['pivot']+=1
        with self.assertRaises(AssertionError):audit_panel(Checks(),p)
    def test_corrupt_covariance(self):
        p=self.panel();p['controls'][0]['parents'][1]['var_dx']*=1.2
        with self.assertRaises(AssertionError):audit_panel(Checks(),p)
    def test_missing_parent(self):
        p=self.panel();p['controls'][0]['parents'].pop()
        with self.assertRaises(AssertionError):audit_panel(Checks(),p)
    def test_corrupt_delivery(self):
        p=self.panel();p['regions'][0]['delivered']=not p['regions'][0]['delivered']
        with self.assertRaises(AssertionError):audit_panel(Checks(),p)
    def test_streamed_csv_finalization(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'large.csv.gz.pending';content='id,value\n'+''.join(f'{i},{i*i}\n' for i in range(100001));p.write_text(content);subprocess.run([sys.executable,str(Path(__file__).with_name('compress-tables.py')),td],check=True)
            with gzip.open(str(p).removesuffix('.pending'),'rt') as f:self.assertEqual(f.read(),content)
            self.assertFalse(p.exists())
    def test_immutable_chunks_and_changed_chunk_rejection(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);tables=root/'tables';chunks=root/'chunks';tables.mkdir();chunks.mkdir();records=[]
            expected=[['1','quoted "value"'],['2','embedded\nnewline'],['3','comma,value']]
            for i,rows in enumerate((expected[:2],expected[2:])):
                p=chunks/f'{i}.csv'
                with p.open('w',newline='') as f:w=csv.writer(f);w.writerow(['id','value']);w.writerows(rows)
                records.append(dict(product='combined.csv.gz',chunk='chunks/'+p.name,rows=len(rows),md5=hashlib.md5(p.read_bytes()).hexdigest()))
            with (tables/'csv-chunk-manifest.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=records[0]);w.writeheader();w.writerows(records)
            cmd=[sys.executable,str(Path(__file__).with_name('compress-tables.py')),str(tables)];subprocess.run(cmd,check=True)
            with gzip.open(tables/'combined.csv.gz','rt',newline='') as f:self.assertEqual(list(csv.reader(f))[1:],expected)
            (chunks/'0.csv').write_text('corrupt')
            failed=subprocess.run(cmd,capture_output=True,text=True);self.assertNotEqual(failed.returncode,0);self.assertIn('checksum changed',failed.stderr)
    def test_truncated_gzip_is_not_complete(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'x.csv.gz';b=gzip.compress(b'id,value\n1,2\n');p.write_bytes(b[:-5])
            with self.assertRaises(EOFError):list(read(p))
    def test_missing_job_is_infrastructure(self):
        spec=importlib.util.spec_from_file_location('s07_auditor',Path(__file__).with_name('final-audit.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            text=(GRID/'job-manifest.csv').read_text().splitlines();(Path(td)/'job-manifest.csv').write_text('\n'.join(text[:-1])+'\n')
            with self.assertRaisesRegex(AssertionError,'Complete job count'):mod.audit(td,True)
    def test_covariance_outer_engineering_fixture(self):audit_covariance(Checks(),EVIDENCE/'analysis-fixture/tables/compact',EVIDENCE/'analysis-fixture/analysis')
if __name__=='__main__':
    GRID=Path(sys.argv[1]);EVIDENCE=Path(sys.argv[2]);suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests);r=unittest.TextTestRunner(verbosity=2).run(suite);root=Path(__file__).resolve().parents[1];files=sorted(str(p.relative_to(root)) for d in ('R','scripts','tests') for p in (root/d).rglob('*') if p.suffix in ('.R','.py'))
    report=dict(status='passed' if r.wasSuccessful() else 'failed',tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped),source_files=files,source_md5=[hashlib.md5((root/f).read_bytes()).hexdigest() for f in files],reserved_panels_generated=0,reserved_draws_generated=0)
    (EVIDENCE/'independent-audit-tests.json').write_text(json.dumps(report,indent=2)+'\n');sys.exit(0 if r.wasSuccessful() else 1)
