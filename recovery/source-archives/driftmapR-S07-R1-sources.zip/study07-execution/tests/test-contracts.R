testthat::test_that('only exact engineering or verified frozen jobs are allowed',{
  f<-s07i_fixture();testthat::expect_true(s07i_validate_job(f$job,f$case));j<-f$job;j$dataset_id<-1L;testthat::expect_error(s07i_generate(j),'exact seed');j<-s07i_jobs()[[1L]];testthat::expect_error(s07i_generate(j),'frozen S07-I1');testthat::expect_error(s07i_hooks(j,list(fit=function(...)NULL)),'forbidden')
  for(b in c(0,800,1.5,NA))testthat::expect_error(s07i_fixture(1,b));testthat::expect_error(s07i_fixture(10,21));testthat::expect_equal(length(s07i_jobs()),6480)
  for(i in c(1:9,101:103)){f<-s07i_fixture(i,2);set.seed(7123);before<-.Random.seed;g<-s07i_generate(f$job);p<-s07i_draws(f$job);testthat::expect_identical(before,.Random.seed);testthat::expect_equal(dim(p$weights),c(2,f$job$m));testthat::expect_true(all(rowSums(p$weights)==f$job$m));if(i<100){testthat::expect_equal(dim(g$X[[1]]),c(18,f$job$m));testthat::expect_lt(max(abs(colSums(g$X[[1]]))),1e-12);testthat::expect_equal(g$model$population_grams,study05_model(s07i_parent_case(f$case))$population_grams)}}
})
testthat::test_that('serial/parallel jobs and caller RNG agree exactly',{
  jobs<-lapply(c(1,3,8,101,103),function(i)s07i_fixture(i,3)$job);work<-function(j)list(g=s07i_generate(j),p=s07i_draws(j));set.seed(817);before<-.Random.seed;a<-lapply(jobs,work);b<-parallel::mclapply(jobs,work,mc.cores=2,mc.set.seed=FALSE);testthat::expect_identical(a,b);testthat::expect_identical(before,.Random.seed)
})
testthat::test_that('population roles continue after failures; no rescue or Gaussian sparse oracle',{
  for(i in c(1,5,6)){
    ref<-s07i_reference(s07i_fixture(i)$case);testthat::expect_equal(nrow(ref$ledger),1836);testthat::expect_true(all(ref$ledger$attempted));testthat::expect_true(all(ref$derivative$available));
    E<-s07_centered_basis()$basis[[31]];h<-ref$scale*2^-17;d<-ref$Q%*%E%*%t(ref$Q);plus<-minus<-ref$model$population_grams;plus[[2]]<-plus[[2]]+h*d;minus[[2]]<-minus[[2]]-h*d;v<-(s07i_functional(plus,ref$model$population_points[[1]],ref$model$anchors,ref$model$target_rows)-s07i_functional(minus,ref$model$population_points[[1]],ref$model$anchors,ref$model$target_rows))/(2*h)
    for(j in 1:3)testthat::expect_equal(unname(v[j,]),unname(ref$jacobians[[3]][[j]][,184]),tolerance=1e-5)
  }
  f<-s07i_fixture();r<-s07i_reference(f$case,hook=function(c)if(c$direction==1L&&c$step_index==3L&&c$sign==1L)stop('forced'));testthat::expect_equal(sum(r$ledger$failed_after_attempt),1);testthat::expect_equal(sum(r$ledger$attempted),1836);testthat::expect_false(any(r$derivative$available));testthat::expect_true(all(r$ledger$attempted[tail(seq_len(nrow(r$ledger)),3)]))
  r<-s07i_reference(f$case,hook=function(c)if(c$role=='base')stop('forced base'));testthat::expect_true(all(r$ledger$unattempted_required));testthat::expect_false(any(r$derivative$available))
  r<-s07i_reference(f$case,moment_hook=function()stop('forced moment'));testthat::expect_true(all(r$derivative$available));testthat::expect_false(any(r$derivative$omega_available));testthat::expect_equal(r$moment_status,'moment_computation_failed')
  r<-s07i_reference(s07i_fixture(8)$case);testthat::expect_null(r$V);testthat::expect_true(all(r$derivative$omega_status=='not_applicable_non_gaussian'))
  for(m in c(12,40,160,640)){C<-.5^abs(outer(seq_len(m),seq_len(m),'-'));testthat::expect_equal(s07i_dependence_factor(m,.5),sum(C^2)/m,tolerance=1e-12)}
})
testthat::test_that('closed occurrence algebra matches physical normal deletions at all m',{
  for(i in 101:103){f<-s07i_fixture(i,21);z<-s07i_normal(f$job);a<-s07i_mean_physical_audit(z$path,f$job,z$plan$weights);testthat::expect_true(all(a$passed));testthat::expect_true(all(a$numerically_compared));testthat::expect_lt(max(a$max_abs_covariance_difference),1e-9);testthat::expect_equal(s07_hotelling_cutoff(f$job$m),(f$job$m-1)*(.05^(-2/(f$job$m-2))-1),tolerance=1e-12);testthat::expect_equal(s07i_validate_control(z$path,f$job,z$plan$weights)$status,'passed')}
  f<-s07i_fixture(101,21);z<-s07i_normal(f$job,hooks=list(pivot=function(ctx,p)Inf));testthat::expect_false(any(z$parents$pivot_ok));testthat::expect_true(all(z$parents$pivot_attempted[-1]));testthat::expect_true(all(is.infinite(z$parents$pivot_raw[-1])));testthat::expect_false(z$regions$delivered[z$regions$method=='normal_bootstrap_studentized'])
  testthat::expect_equal(study05_nondelivery(TRUE,TRUE,TRUE,189L,199L,TRUE),'valid_fraction_below_095');testthat::expect_equal(study05_nondelivery(TRUE,TRUE,TRUE,759L,799L,TRUE),'valid_fraction_below_095')
})
testthat::test_that('forced full failures retain all work and distinguish evaluation blocks',{
  f<-s07i_fixture(1,2);inject<-list(observed=list(fit=function(c)if(c$role=='core'&&c$parent_id==0L&&c$unit_index==0L)stop('forced')),evaluation=list(evaluation_register=function(...)stop('forced')),deletion=list(fit=function(c)if(c$role=='core'&&c$parent_id==0L&&c$unit_index==1L)stop('forced')),covariance=list(covariance=function(values,counts)rep(list(matrix(0,2,2)),dim(values)[2])),pivot=list(quadratic=function(error,S)Inf))
  for(n in names(inject)){r<-s07i_full(f$job,hooks=inject[[n]]);a<-study05_stage_accounting(r);testthat::expect_equal(a$required,a$attempted+a$unattempted_required);testthat::expect_equal(a$attempted,a$successful+a$failed_after_attempt);testthat::expect_equal(nrow(r$attempts),2);testthat::expect_equal(nrow(r$studentization),6)
    for(j in c(list(r$observed_jackknife),r$inner)){testthat::expect_equal(nrow(j$ledger),40);testthat::expect_false(any(j$ledger$attempted[j$ledger$multiplicity==0]))}
    if(n=='evaluation'){testthat::expect_true(r$evaluation_only_block);testthat::expect_true(all(is.na(r$regions$candidate_region_delivered)))}
    if(n=='deletion'){testthat::expect_true(all(r$observed_jackknife$ledger$attempted));testthat::expect_false(r$observed_jackknife$all_required_success)}
  }
})
testthat::test_that('observed T1 excludes truth, population and bootstrap information',{
  r<-s07i_full(s07i_fixture(1,2)$job);expected<-r$s07_screen;z<-r;z$truth[,]<-1e6;z$case$g<-0;z$case$a<-1e6;z$pivots[,]<-NA
  for(kind in c('embedding','registration')){g<-z$geometry[[kind]];u<-g$role!='core'|g$parent_id!=0L|g$unit_index!=0L;for(n in intersect(c('gap_relative1','source_ratio','target_ratio','cross_ratio'),names(g)))g[[n]][u]<- -1e9;z$geometry[[kind]]<-g}
  testthat::expect_identical(s06_observed_policy(z),expected);at<-which(z$geometry$embedding$role=='core'&z$geometry$embedding$parent_id==0L&z$geometry$embedding$unit_index==0L)[1];z$geometry$embedding<-z$geometry$embedding[-at,];testthat::expect_identical(s06_observed_policy(z)$screen_status,'unknown');z<-r;z$geometry$embedding<-rbind(z$geometry$embedding,z$geometry$embedding[at,]);testthat::expect_error(s06_observed_policy(z),'Duplicate')
})
testthat::test_that('immutable checkpoints quarantine corruption and refuse different identities',{
  dir<-tempfile();dir.create(dir);p<-file.path(dir,'checkpoint.rds');j<-s07i_fixture(101,2)$job;id<-list(source='fixture');z<-list(job=j,value=42);study05_checkpoint_save(z,p,id);testthat::expect_identical(s06_checkpoint(p,id,j),z);testthat::expect_error(s06_checkpoint(p,list(source='wrong'),j),'identity');testthat::expect_identical(s06_checkpoint(p,id,j),z);writeBin(as.raw(1:8),p);testthat::expect_null(s06_checkpoint(p,id,j));testthat::expect_true(length(list.files(file.path(dir,'infrastructure-incidents')))>0);study05_checkpoint_save(z,p,id);testthat::expect_identical(s06_checkpoint(p,id,j),z)
})
