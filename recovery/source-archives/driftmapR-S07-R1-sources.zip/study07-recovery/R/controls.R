# S07-R1 control-only numerical overlay. No covariance gate or estimator change.
# The original functions are retained by the recovery loader before overrides.
s07r1_factor_input <- function(values, weights, delta, covariance) {
  if (!is.matrix(values) || !is.numeric(values) || ncol(values) != 2L ||
      any(!is.finite(values)) || length(weights) != nrow(values) ||
      any(!is.finite(weights)) || any(weights < 0 | weights != floor(weights)) ||
      sum(weights) < 3L || length(delta) != 2L || any(!is.finite(delta)))
    stop('Invalid S07-R1 finite occurrence factor input.')
  status <- study03_covariance_status(covariance)
  if (!status$valid) stop('S07-R1 factor blocked by unchanged covariance gate: ', status$reason)
  invisible(sum(weights))
}

s07r1_weighted_qr <- function(values, weights, delta, covariance) {
  m <- s07r1_factor_input(values, weights, delta, covariance)
  keep <- weights > 0
  x <- values[keep, , drop = FALSE]
  shifted <- sweep(x, 2L, x[1L, ], '-')
  center <- colSums(shifted * weights[keep]) / m
  A <- sweep(shifted, 2L, center, '-') * sqrt(weights[keep])
  magnitude <- max(abs(A))
  if (!is.finite(magnitude) || magnitude <= 0) stop('S07-R1 weighted factor unavailable.')
  fit <- qr(A / magnitude, LAPACK = TRUE)
  R <- qr.R(fit)[1:2, 1:2, drop = FALSE]
  if (any(!is.finite(R)) || any(diag(R) == 0)) stop('S07-R1 weighted triangular factor unavailable.')
  delta_magnitude <- max(abs(delta))
  if (delta_magnitude == 0) return(0)
  z <- forwardsolve(t(R), (delta / delta_magnitude)[fit$pivot])
  whitened <- z * (delta_magnitude / magnitude) * sqrt(m) * sqrt(m - 1)
  statistic <- sum(whitened^2)
  if (length(statistic) != 1L || !is.finite(statistic) || statistic < 0)
    stop('S07-R1 weighted factor produced a nonfinite statistic.')
  statistic
}

s07r1_expanded_svd <- function(values, weights, delta, covariance) {
  m <- s07r1_factor_input(values, weights, delta, covariance)
  # Independent centering and decomposition on physically expanded occurrences.
  x <- values[rep(seq_len(nrow(values)), weights), , drop = FALSE]
  shifted <- sweep(x, 2L, x[nrow(x), ], '-')
  A <- sweep(shifted, 2L, colMeans(shifted), '-')
  magnitude <- max(abs(A))
  if (!is.finite(magnitude) || magnitude <= 0) stop('S07-R1 expanded factor unavailable.')
  fit <- svd(A / magnitude, nu = 0L, nv = 2L)
  if (length(fit$d) != 2L || any(!is.finite(fit$d)) || any(fit$d <= 0))
    stop('S07-R1 expanded singular factor unavailable.')
  delta_magnitude <- max(abs(delta))
  if (delta_magnitude == 0) return(0)
  projected <- drop(crossprod(fit$v, delta / delta_magnitude))
  whitened <- (projected / fit$d) * (delta_magnitude / magnitude) * sqrt(m) * sqrt(m - 1)
  statistic <- sum(whitened^2)
  if (length(statistic) != 1L || !is.finite(statistic) || statistic < 0)
    stop('S07-R1 expanded factor produced a nonfinite statistic.')
  statistic
}

s07r1_mean_path <- function(values, truth, weights, job, construction, entity, hooks = list()) {
  s07i_hooks(job, hooks)
  original_hooks <- hooks
  original_hooks$pivot <- NULL
  path <- s07r1_original_mean_path(values, truth, weights, job, construction, entity, original_hooks)
  if (!all(is.finite(values))) return(path)
  if (!is.null(hooks$covariance)) {
    for (b in 0:job$B_planned) {
      S <- path$covariances[[b + 1L]]
      w <- if (b == 0L) rep(1L, job$m) else as.numeric(weights[b, ])
      if (study03_covariance_status(S)$valid &&
          !identical(S, s07_linear_covariance(values, w)$jackknife))
        stop('S07-R1 finite covariance-changing hooks are unsupported; use failure-injection hooks.')
    }
  }
  observed_mean <- colMeans(values)
  for (b in seq_len(job$B_planned)) {
    i <- b + 1L
    if (!path$parents$pivot_attempted[i]) next
    w <- as.numeric(weights[b, ])
    S <- path$covariances[[i]]
    delta <- colSums(values * w) / job$m - observed_mean
    ctx <- list(parent_id = b, entity = entity, construction = construction)
    result <- study03_capture({
      p <- s07r1_weighted_qr(values, w, delta, S)
      if (!is.null(hooks$pivot)) p <- hooks$pivot(ctx, p)
      p
    })
    raw <- if (result$ok) result$value else NA_real_
    ok <- result$ok && length(raw) == 1L && is.finite(raw) && raw >= 0
    path$parents$pivot_ok[i] <- ok
    path$parents$pivot[i] <- if (ok) raw else NA_real_
    path$parents$pivot_raw[i] <- if (length(raw) == 1L) raw else NA_real_
    path$parents$message[i] <- if (result$ok) '' else paste0('S07-R1 control factor: ', result$message)
    if (nzchar(result$warnings)) path$parents$warnings[i] <- paste(
      Filter(nzchar, c(path$parents$warnings[i], result$warnings)), collapse = '; ')
  }
  path
}

s07r1_mean_regions <- function(path, job, normal = FALSE) {
  out <- s07r1_original_mean_regions(path, job, normal)
  S <- path$covariances[[1L]]
  if (!all(is.finite(path$values)) || !all(is.finite(path$observed)) ||
      !all(is.finite(path$truth)) || !study03_covariance_status(S)$valid) return(out)
  result <- study03_capture(c(
    truth = s07r1_weighted_qr(path$values, rep(1L, job$m), path$truth - path$observed, S),
    null = s07r1_weighted_qr(path$values, rep(1L, job$m), -path$observed, S)))
  # A new arithmetic failure is explicit, not a covariance repair or fallback.
  if (!result$ok) {
    eligible <- out$available
    out$available[eligible] <- out$delivered[eligible] <- FALSE
    out$covered[eligible] <- out$rejects_zero[eligible] <- NA
    out$truth_statistic[eligible] <- out$null_statistic[eligible] <- NA_real_
    for (n in intersect(c('relaxed_covered', 'relaxed_rejects_zero'), names(out))) out[[n]][eligible] <- NA
    out$reason[eligible] <- 's07r1_control_factor_failed'
    return(out)
  }
  for (i in seq_len(nrow(out))) {
    if (!out$available[i]) next
    out$truth_statistic[i] <- result$value[['truth']]
    out$null_statistic[i] <- result$value[['null']]
    covered <- result$value[['truth']] <= out$cutoff[i] * (1 + 1e-12)
    rejects <- result$value[['null']] > out$cutoff[i] * (1 + 1e-12)
    if (out$delivered[i]) { out$covered[i] <- covered; out$rejects_zero[i] <- rejects }
    if ('relaxed_covered' %in% names(out) && !is.na(out$relaxed_covered[i])) out$relaxed_covered[i] <- covered
    if ('relaxed_rejects_zero' %in% names(out) && !is.na(out$relaxed_rejects_zero[i])) out$relaxed_rejects_zero[i] <- rejects
  }
  out
}

s07r1_validate_control <- function(path, job, weights, tolerance = 1e-9, allow_hooks = FALSE) {
  # Copy of I1 checks with only the unstable scalar check replaced. Covariance
  # checks continue to use the expanded cov()/m matrix and its original gate.
  p <- path$parents
  checks <- 0L
  ck <- function(x, msg) { checks <<- checks + 1L; if (!isTRUE(x)) stop(msg) }
  ck(identical(p$parent_id, 0:job$B_planned), 'Complete control parent grid')
  ck(!anyDuplicated(p$parent_id), 'Unique control parents')
  for (b in 0:job$B_planned) {
    r <- p[b + 1L, , drop = FALSE]
    w <- if (b == 0L) rep(1L, job$m) else weights[b, ]
    ck(r$required_occurrences == sum(w) && r$required_unique == sum(w > 0), 'Control counts')
    if (all(is.finite(path$values))) {
      expanded <- path$values[rep(seq_len(job$m), w), , drop = FALSE]
      center <- colMeans(expanded)
      S <- cov(expanded) / job$m
      ck(max(abs(center + path$truth - c(r$dx, r$dy))) <= tolerance, 'Expanded mean')
      if (!allow_hooks) {
        actual <- matrix(c(r$var_dx, r$cov_dx_dy, r$cov_dx_dy, r$var_dy), 2L)
        ck(max(abs(S - actual)) <= tolerance, 'Expanded covariance')
        conditional <- matrix(c(r$conditional_var_dx, r$conditional_cov_dx_dy,
                                r$conditional_cov_dx_dy, r$conditional_var_dy), 2L)
        ck(max(abs(conditional - S * (job$m - 1) / job$m)) <= tolerance, 'Conditional multinomial factor')
        status <- study03_covariance_status(S)
        ck(r$covariance_ok == status$valid, 'Control SPD gate')
        if (b > 0L && status$valid) {
          independent <- study03_capture(s07r1_expanded_svd(path$values, w,
            center - colMeans(path$values), S))
          q <- if (independent$ok) independent$value else NA_real_
          ck(r$pivot_ok == (independent$ok && is.finite(q)), 'Control pivot availability')
          if (independent$ok && is.finite(q))
            ck(abs(r$pivot - q) <= tolerance * max(1, abs(q)), 'Control scalar pivot')
        }
      }
    } else ck(!r$covariance_attempted && !r$pivot_attempted && !r$point_available, 'Unavailable influence accounting')
  }
  accounting <- s07i_control_accounting(p)
  ck(all(accounting$required == accounting$attempted + accounting$unattempted_required), 'Control required balance')
  ck(all(accounting$attempted == accounting$successful + accounting$failed_after_attempt), 'Control attempted balance')
  data.frame(status = 'passed', checks = checks)
}
