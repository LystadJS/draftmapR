# S07-R1 guards never generate observations or bootstrap weight vectors.
s07r1_manifest <- function(operation, paths = s07r1_paths()$recovery) {
  script <- file.path(s07r1_paths()$recovery, "scripts/manifest.py")
  output <- system2("python3", c(shQuote(script), operation, shQuote(paths)),
                    stdout = TRUE, stderr = TRUE)
  if (!is.null(attr(output, "status"))) stop(paste(output, collapse = "\n"))
  jsonlite::fromJSON(paste(output, collapse = "\n"), simplifyVector = FALSE)
}

s07r1_file_sha256 <- function(path) {
  if (!length(path)) return(character())
  unname(unlist(s07r1_manifest("sha256", path), use.names = FALSE))
}

s07r1_source_identity <- function() {
  paths <- s07r1_paths()
  original <- s07i_verify_implementation()
  implementation_sha <- s07r1_file_sha256(
    file.path(paths$execution, "implementation-freeze.json"))
  if (!identical(implementation_sha,
      "f9d2ce830c8e8cde52ad22d995fdf343b3df7f7430dcf7df0ee11a169f32dd7e")) {
    stop("Wrong S07-I1 ancestor.")
  }
  # Independently check the ancestor SHA256 inventory, as well as its R guards.
  checked <- system2("python3", c(shQuote(file.path(paths$execution,
    "scripts/manifest.py")), "verify", shQuote(paths$execution)),
    stdout = TRUE, stderr = TRUE)
  if (!is.null(attr(checked, "status"))) stop(paste(checked, collapse = "\n"))
  catalog <- file.path(paths$recovery, "evidence/original-checkpoint-catalog.csv")
  catalog_sha <- s07r1_file_sha256(catalog)
  if (!identical(catalog_sha,
      "64e7b5d059ef95141e1784c39038b46540f59d7c647a3308dc8c10bf3c70960f")) {
    stop("Wrong original checkpoint catalog.")
  }
  contract <- file.path(paths$recovery, "SPECIFICATION.md")
  if (!file.exists(contract)) stop("S07-R1 contract is required.")
  source <- s07r1_manifest("sources")
  list(study = "S07", freeze_id = "S07-R1 engineering", engineering = TRUE,
       original_identity = original, design = original$design,
       runtime = original$runtime, ancestor_sha256 = implementation_sha,
       input_catalog_sha256 = catalog_sha,
       contract_sha256 = s07r1_file_sha256(contract),
       jobs = s07i_engineering_jobs(),
       source_files = names(source),
       source_sha256 = unname(vapply(source, `[[`, character(1), "sha256")))
}

s07r1_context <- local({
  value <- NULL
  function(set = NULL, clear = FALSE) {
    if (clear) value <<- NULL
    if (!is.null(set)) value <<- set
    value
  }
})

s07r1_verify <- function() {
  # Clear an earlier successful verification before attempting a new one.
  s07r1_context(clear = TRUE)
  root <- s07r1_paths()$recovery
  locks <- file.path(root, c("implementation-freeze.rds", "implementation-freeze.json"))
  if (!all(file.exists(locks))) stop("S07-R1 is not completely frozen.")
  lock <- readRDS(locks[1])
  if (!identical(lock$freeze_id, "S07-R1") || !isTRUE(lock$ready_for_recovery) ||
      !identical(lock$reserved_measurement_panels_generated, 0L) ||
      !identical(lock$reserved_bootstrap_weight_vectors_generated, 0L)) {
    stop("Invalid S07-R1 freeze contract.")
  }
  if (!identical(s07r1_file_sha256(locks[2]), lock$json_sha256)) {
    stop("S07-R1 JSON lock changed.")
  }
  manifest <- s07r1_manifest("verify")
  files <- names(s07r1_manifest("inventory"))
  if (!identical(files, lock$files) ||
      !identical(unname(study05_md5(file.path(root, files))), lock$md5)) {
    stop("S07-R1 exact file grid or bytes changed.")
  }
  source <- s07r1_source_identity()
  if (!identical(source, lock$source_identity)) stop("S07-R1 source or ancestry changed.")
  identity <- source
  identity$freeze_id <- "S07-R1"
  identity$engineering <- FALSE
  identity$jobs <- NULL
  identity$freeze_sha256 <- manifest$freeze_sha256
  identity$ready_for_recovery <- TRUE
  s07r1_context(identity)
  identity
}

s07r1_identity <- function(engineering = FALSE) {
  if (!is.logical(engineering) || length(engineering) != 1L || is.na(engineering)) {
    stop("engineering must be one nonmissing logical value.")
  }
  if (engineering) s07r1_source_identity() else s07r1_verify()
}

s07r1_validate_recovery_identity <- function(recovery_identity) {
  verified <- s07r1_context()
  if (is.null(verified) || !identical(verified, recovery_identity) ||
      !identical(recovery_identity$freeze_id, "S07-R1") ||
      !identical(recovery_identity$engineering, FALSE) ||
      !isTRUE(recovery_identity$ready_for_recovery)) {
    stop("Current verified frozen S07-R1 identity is required for reserved recovery.")
  }
  invisible(TRUE)
}
