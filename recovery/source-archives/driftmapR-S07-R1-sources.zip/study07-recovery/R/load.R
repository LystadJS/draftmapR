# Explicit overlay: ancestors are sourced, never edited on disk.
s07r1_paths <- local({ value <- NULL; function(recovery = NULL) {
  if (!is.null(recovery)) {
    p <- normalizePath(recovery)
    value <<- list(recovery = p, execution = normalizePath(file.path(p, '../study07-execution')),
                   specification = normalizePath(file.path(p, '../study07-specification')))
  }
  if (is.null(value)) stop('Load S07-R1 first.')
  value
}})
s07r1_load <- function(recovery_dir) {
  p <- s07r1_paths(recovery_dir)
  source(file.path(p$execution, 'R/load.R'), local = .GlobalEnv)
  s07i_load(p$execution, p$specification)
  for (name in c('mean_path', 'mean_regions', 'validate_control', 'export_panel'))
    assign(paste0('s07r1_original_', name), get(paste0('s07i_', name)), envir = .GlobalEnv)
  for (name in c('guards', 'controls', 'runner', 'orchestration'))
    source(file.path(p$recovery, 'R', paste0(name, '.R')), local = .GlobalEnv)
  for (name in c('mean_path', 'mean_regions', 'validate_control', 'export_panel'))
    assign(paste0('s07i_', name), get(paste0('s07r1_', name)), envir = .GlobalEnv)
  invisible(p)
}
