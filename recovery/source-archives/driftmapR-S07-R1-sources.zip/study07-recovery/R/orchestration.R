# Collection/reporting reuse is explicit; the sole statistical overlay is the
# control quadratic-form arithmetic in controls.R.
s07r1_export_panel <- function(result, path) {
  s07r1_original_export_panel(result, path)
  panel <- jsonlite::read_json(path, simplifyVector = FALSE)
  panel$recovery <- result$recovery
  panel$recovery$amendment <- 'S07-R1'
  panel$recovery$control_arithmetic <- 'weighted_centered_qr'
  s07i_json(panel, path)
}

s07r1_final_audit <- function(out, engineering) {
  command <- file.path(s07r1_paths()$recovery, 'audit/final-audit.py')
  log <- system2('python3', c(shQuote(command), shQuote(normalizePath(out)),
                             if (engineering) '--engineering'), stdout = TRUE, stderr = TRUE)
  writeLines(log, file.path(out, 'independent-audit.log'))
  if (!is.null(attr(log, 'status')))
    stop('Independent recovery audit failed: ', paste(tail(log, 20), collapse = '\n'))
  cat(paste(log, collapse = '\n'), '\n')
  invisible(TRUE)
}

s07r1_catalog_check <- function(source_out) {
  frozen <- file.path(s07r1_paths()$recovery, 'evidence/original-checkpoint-catalog.csv')
  catalog <- read.csv(frozen, stringsAsFactors = FALSE)
  if (!identical(names(catalog), c('path', 'md5', 'bytes')) ||
      nrow(catalog) != 25939L || anyDuplicated(catalog$path) ||
      any(grepl('(^/|(^|/)\\.\\.(/|$))', catalog$path)))
    stop('Invalid original checkpoint catalog.')
  source_out <- normalizePath(source_out)
  actual <- sort(list.files(source_out, recursive = TRUE, all.files = TRUE, no.. = TRUE))
  # The catalog deliberately covers checkpoint payloads, sidecars, plans, refs,
  # and incident records. Operational root-level logs do not enter it.
  controlled <- actual[grepl('^(checkpoints|draw-plans|population)/', actual)]
  expected_controlled <- catalog$path[grepl('^(checkpoints|draw-plans|population)/', catalog$path)]
  if (!setequal(controlled, expected_controlled)) stop('Original catalog file grid mismatch.')
  paths <- file.path(source_out, catalog$path)
  info <- file.info(paths)
  if (anyNA(info$size) || any(info$isdir) || any(info$size != catalog$bytes) ||
      !identical(unname(study05_md5(paths)), catalog$md5))
    stop('Original catalog bytes or checksums changed; input preserved.')
  invisible(catalog)
}

s07r1_export_provenance <- function(paths, jobs, identity, source_out, out, engineering) {
  rows <- lapply(seq_along(jobs), function(i) {
    result <- s07r1_checkpoint_read(paths[i], identity, jobs[[i]])
    row <- result$recovery
    row$checkpoint_md5 <- study05_md5(paths[i])
    row
  })
  s07i_json(list(schema_version = 1L, amendment = 'S07-R1', engineering = engineering,
    source_output = normalizePath(source_out), rows = rows),
    file.path(out, 'recovery-provenance.json'))
  invisible(rows)
}

s07r1_status <- function(out, jobs, identity, complete = FALSE) {
  rows <- s07i_bind(lapply(jobs, function(job) {
    path <- file.path(out, 'checkpoints', paste0(s07i_key(job), '.rds'))
    value <- tryCatch(s07r1_checkpoint_read(path, identity, job, TRUE),
                      error = function(e) NULL)
    valid <- !is.null(value) && isTRUE(value$recovery$controls_recomputed) &&
      nrow(value$control_validation) > 0L && all(value$control_validation$status == 'passed')
    data.frame(case_id = job$case_id, dataset_id = job$dataset_id,
      B = job$B_planned, status = if (valid) 'validated_checkpoint' else 'infrastructure_unresolved')
  }))
  if (complete && any(rows$status != 'validated_checkpoint')) stop('Unresolved recovery plan.')
  write.csv(rows, file.path(out, 'execution-job-status.csv'), row.names = FALSE)
  s07i_json(list(status = if (complete) 'COMPLETE' else 'INCOMPLETE', amendment = 'S07-R1',
    planned = length(jobs), unresolved = sum(rows$status != 'validated_checkpoint'),
    meaning = 'Missing or invalid jobs are infrastructure incompleteness, never statistical non-delivery.'),
    file.path(out, 'execution-status.json'))
  invisible(rows)
}

s07r1_run <- function(source_out, out, workers = 4L, engineering = TRUE) {
  if (length(workers) != 1L || !workers %in% 1:8) stop('Use 1 to 8 workers.')
  # Verification precedes all writes, generators, and checkpoint operations.
  ancestor <- s07i_verify_implementation()
  identity <- s07r1_identity(engineering)
  jobs <- if (engineering) s07i_engineering_jobs() else s07i_jobs()
  original <- if (engineering) s07i_identity(jobs) else ancestor
  source_out <- normalizePath(source_out, mustWork = TRUE)
  out <- s07r1_output_path(out)
  if (identical(source_out, out) || startsWith(out, paste0(source_out, '/')) ||
      startsWith(source_out, paste0(out, '/')))
    stop('Original and recovery output trees must be separate.')
  if (!engineering) s07r1_catalog_check(source_out)
  preflight <- s07r1_preflight(source_out, jobs, original)
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  out <- normalizePath(out)
  signature <- file.path(out, 'execution-identity.rds')
  if (file.exists(signature) && !identical(readRDS(signature), identity))
    stop('Recovery output identity mismatch; preserve prior output.')
  if (!file.exists(signature)) saveRDS(identity, signature, version = 2)
  binding <- list(source_out = source_out, original_identity = original, preflight = preflight)
  bp <- file.path(out, 'source-binding.rds')
  if (file.exists(bp) && !identical(readRDS(bp), binding)) stop('Changed source provenance.')
  if (!file.exists(bp)) saveRDS(binding, bp, version = 2)
  write.csv(preflight, file.path(out, 'source-preflight.csv'), row.names = FALSE, na = 'NA')
  complete <- FALSE
  on.exit(if (!complete) try(s07r1_status(out, jobs, identity), silent = TRUE), add = TRUE)
  if (file.exists(file.path(out, 'execution-complete.json'))) {
    s07r1_final_audit(out, engineering)
    s07r1_status(out, jobs, identity, TRUE)
    complete <- TRUE
    return(invisible(out))
  }
  seed <- file.path(out, 'seed-plan.rds')
  if (file.exists(seed) && !identical(readRDS(seed), jobs)) stop('Changed seed plan.')
  if (!file.exists(seed)) saveRDS(jobs, seed, version = 2)
  write.csv(s07i_bind(lapply(jobs, function(j) data.frame(case_id = j$case_id,
    case_index = j$case_index, dataset_id = j$dataset_id, m = j$m, B = j$B_planned,
    B_primary = j$B_primary, extension = j$extension, pipeline = j$pipeline,
    stage = j$stage, bootstrap_seed = j$bootstrap_seed,
    data_stream = paste(j$data_stream, collapse = ';')))),
    file.path(out, 'job-manifest.csv'), row.names = FALSE)
  # Preserve all saved plans/references under the new wrapper identity. No RNG.
  for (job in jobs) {
    rel <- file.path('draw-plans', paste0(s07i_key(job), '.rds'))
    old <- s07r1_checkpoint_read(file.path(source_out, rel), original, job)
    new <- s07r1_checkpoint_read(file.path(out, rel), identity, job, TRUE)
    if (is.null(new)) study05_checkpoint_save(old, file.path(out, rel), identity)
    else if (!identical(old, new)) stop('Changed recovered draw plan.')
  }
  writeLines('Every original saved plan was verified and retained; zero replacement draws.',
             file.path(out, 'draw-plans-complete.txt'))
  seen <- character()
  for (job in jobs) if (job$pipeline == 'full_estimator' && !job$case_id %in% seen) {
    case <- s07i_reference_case(s07i_case(job)); rjob <- s07i_refjob(case)
    rel <- file.path('population', paste0(case$case_id, '.rds'))
    old <- s07r1_checkpoint_read(file.path(source_out, rel), original, rjob)
    new <- s07r1_checkpoint_read(file.path(out, rel), identity, rjob, TRUE)
    if (is.null(new)) study05_checkpoint_save(old, file.path(out, rel), identity)
    else if (!identical(old, new)) stop('Changed recovered reference.')
    seen <- c(seen, job$case_id)
  }
  paths <- unlist(study05_execute_jobs(jobs, function(job) s07r1_work(job,
    source_out = source_out, new_out = out, original_identity = original,
    recovery_identity = identity), workers), use.names = FALSE)
  # Strict read-back precedes inherited collection (so its quarantine path is
  # never used for source inputs and is not a corruption-repair mechanism).
  for (i in seq_along(jobs)) s07r1_checkpoint_read(paths[i], identity, jobs[[i]])
  s07r1_export_provenance(paths, jobs, identity, source_out, out, engineering)
  tables <- s07i_collect(paths, jobs, identity, file.path(out, 'tables'))
  s06_new_product_dir(file.path(out, 'analysis'))
  s07i_analyze(tables, file.path(out, 'analysis'), engineering)
  s07i_inventory(out)
  s07r1_final_audit(out, engineering)
  if (!identical(identity, s07r1_identity(engineering))) stop('Recovery source identity changed.')
  if (!identical(ancestor, s07i_verify_implementation())) stop('Ancestor identity changed.')
  s07r1_status(out, jobs, identity, TRUE)
  s07i_json(list(amendment = 'S07-R1', engineering = engineering,
    panels = length(jobs), draws = sum(vapply(jobs, `[[`, integer(1), 'B_planned')),
    controls_recomputed_panels = length(jobs), migrated_panels = if (engineering) 12L else 6475L,
    full_estimator_refitted_panels = if (engineering) 0L else 5L,
    completed_at = study05_utc(), independent_audit_passed = TRUE,
    reserved_measurement_panels_generated = if (engineering) 0L else 5L,
    reserved_bootstrap_weight_vectors_generated = 0L), file.path(out, 'execution-complete.json'))
  complete <- TRUE
  invisible(out)
}
