# S07-R1 recovery orchestration. Original inputs are read-only; missing and
# corrupt inputs are distinct states, and neither is a statistical failure.

s07r1_payload_sha256 <- function(x) {
  path <- tempfile('s07r1-payload-')
  on.exit(unlink(path), add = TRUE)
  saveRDS(x, path, version = 2L, compress = FALSE)
  value <- system2('sha256sum', shQuote(path), stdout = TRUE, stderr = TRUE)
  if (!is.null(attr(value, 'status')) || length(value) != 1L ||
      !grepl('^[0-9a-f]{64} ', value)) stop('Cannot compute payload SHA256.')
  substr(value, 1L, 64L)
}

s07r1_preserved_payload <- function(result) {
  slots <- c('job', 'case', 'generated', 'plan')
  if (identical(result$job$pipeline, 'full_estimator'))
    slots <- c(slots, 'full', 'reference')
  if (any(!slots %in% names(result))) stop('Incomplete preserved payload.')
  slots <- c(slots, intersect(c('mechanical_validation', 'stage', 'public_audit',
                                'checkpoint_retention'), names(result)))
  result[slots]
}

# Resolve existing ancestors (including symlinks) without creating directories.
# This lets callers reject a new directory nested in the immutable source tree
# before the first filesystem mutation.
s07r1_output_path <- function(path) {
  if (!is.character(path) || length(path) != 1L || is.na(path) || !nzchar(path))
    stop('Invalid recovery output path.')
  path <- path.expand(path)
  if (!startsWith(path, '/')) path <- file.path(getwd(), path)
  tail <- character()
  ancestor <- path
  while (!file.exists(ancestor)) {
    parent <- dirname(ancestor)
    if (identical(parent, ancestor)) stop('Cannot resolve recovery output ancestor.')
    tail <- c(basename(ancestor), tail)
    ancestor <- parent
  }
  resolved <- normalizePath(ancestor, mustWork = TRUE)
  for (part in tail) {
    if (part == '..') resolved <- dirname(resolved)
    else if (part != '.') resolved <- file.path(resolved, part)
    if (file.exists(resolved)) resolved <- normalizePath(resolved, mustWork = TRUE)
  }
  resolved
}

s07r1_checkpoint_read <- function(path, identity, job, allow_missing = FALSE) {
  sidecar <- paste0(path, '.manifest.rds')
  present <- file.exists(c(path, sidecar))
  if (!any(present) && isTRUE(allow_missing)) return(NULL)
  fail <- function(message) stop(message, ': ', path, call. = FALSE)
  if (!all(present)) fail('Missing or partial checkpoint; input preserved')
  manifest <- tryCatch(readRDS(sidecar), error = function(e) NULL)
  if (is.null(manifest)) fail('Unreadable checkpoint manifest; input preserved')
  if (!identical(manifest$identity, identity) || !identical(manifest$job, job))
    fail('Checkpoint identity or job mismatch; input preserved')
  if (!identical(study05_md5(path), manifest$content_md5))
    fail('Checkpoint checksum mismatch; input preserved')
  if (!is.null(manifest$bytes) && file.info(path)$size != manifest$bytes)
    fail('Checkpoint byte count mismatch; input preserved')
  payload <- tryCatch(readRDS(path), error = function(e) NULL)
  if (is.null(payload) || !identical(payload$identity, identity) ||
      !identical(payload$job, job) || !identical(payload$result$job, job))
    fail('Checkpoint payload identity or job mismatch; input preserved')
  payload$result
}

s07r1_missing_keys <- function() paste0('s07_sparse_m12-',
                                       sprintf('%04d', c(18L, 20L, 30L, 32L, 37L)))

s07r1_missing_allowed <- function(job, engineering_refit = FALSE) {
  if (identical(job$stage, 's07_engineering_fixture')) {
    s07i_validate_job(job, s07i_case(job))
    return(isTRUE(engineering_refit))
  }
  identical(job$stage, 'reserved_method_development') &&
    identical(job$pipeline, 'full_estimator') && s07i_key(job) %in% s07r1_missing_keys()
}

s07r1_validate_plan <- function(plan, job) {
  if (!identical(plan$job, job) || !is.matrix(plan$weights) ||
      !identical(dim(plan$weights), c(job$B_planned, job$m)) ||
      any(!is.finite(plan$weights)) || any(plan$weights < 0) ||
      any(plan$weights != floor(plan$weights)) ||
      any(rowSums(plan$weights) != job$m) ||
      !is.matrix(plan$streams) || nrow(plan$streams) != job$B_planned ||
      !identical(study05_object_md5(plan$weights), plan$weights_md5) ||
      !identical(study05_object_md5(plan$streams), plan$streams_md5))
    stop('Invalid original draw plan; redraw forbidden.')
  invisible(TRUE)
}

s07r1_source_inputs <- function(source_out, job, case, original_identity,
                                engineering_refit = FALSE) {
  key <- s07i_key(job)
  source_path <- file.path(source_out, 'checkpoints', paste0(key, '.rds'))
  plan_path <- file.path(source_out, 'draw-plans', paste0(key, '.rds'))
  old <- s07r1_checkpoint_read(source_path, original_identity, job, TRUE)
  if (is.null(old) && !s07r1_missing_allowed(job, engineering_refit))
    stop('Unexpected missing original checkpoint; refitting forbidden: ', key)
  plan <- s07r1_checkpoint_read(plan_path, original_identity, job)
  s07r1_validate_plan(plan, job)
  reference <- NULL
  reference_path <- NA_character_
  if (identical(job$pipeline, 'full_estimator')) {
    reference_case <- s07i_reference_case(case)
    reference_path <- file.path(source_out, 'population', paste0(case$case_id, '.rds'))
    ref <- s07r1_checkpoint_read(reference_path, original_identity,
                                s07i_refjob(reference_case))
    if (is.null(ref$reference)) stop('Missing original population reference.')
    reference <- ref$reference
  }
  if (!is.null(old)) {
    if (!identical(old$case, case) || !identical(old$plan, plan) ||
        (job$pipeline == 'full_estimator' && !identical(old$reference, reference)))
      stop('Checkpoint disagrees with original case, plan, or population reference.')
    if (!is.data.frame(old$control_validation) || !nrow(old$control_validation) ||
        !all(old$control_validation$status == 'passed'))
      stop('Original checkpoint lacks passed control validation.')
    if (job$pipeline == 'full_estimator' &&
        (!is.data.frame(old$mechanical_validation) || !nrow(old$mechanical_validation) ||
         !all(old$mechanical_validation$status == 'passed')))
      stop('Original full estimator lacks passed mechanical validation.')
    if (is.null(old$generated)) stop('Original generated units are missing.')
    s07r1_preserved_payload(old)
  }
  list(old = old, plan = plan, reference = reference, source_path = source_path,
       plan_path = plan_path, reference_path = reference_path)
}

# The caller additionally verifies the frozen reserved input catalog, including
# the five infrastructure incidents. This scan verifies every serialized object
# and the exact job grid before any recovery computation starts.
s07r1_preflight <- function(source_out, jobs, original_identity,
                            engineering_refit_keys = character()) {
  if (!length(jobs) || anyDuplicated(vapply(jobs, s07i_key, character(1))))
    stop('Missing or duplicated recovery job grid.')
  stages <- unique(vapply(jobs, `[[`, character(1), 'stage'))
  if (length(stages) != 1L) stop('Mixed engineering and reserved job domains.')
  engineering <- identical(stages, 's07_engineering_fixture')
  if (length(engineering_refit_keys) && !engineering)
    stop('Engineering refit overrides are forbidden in reserved execution.')
  keys <- vapply(jobs, s07i_key, character(1))
  if (anyDuplicated(engineering_refit_keys) || any(!engineering_refit_keys %in% keys))
    stop('Invalid engineering missing-key declaration.')
  if (!identical(readRDS(file.path(source_out, 'execution-identity.rds')), original_identity))
    stop('Original execution identity mismatch.')
  if (!identical(readRDS(file.path(source_out, 'seed-plan.rds')), jobs))
    stop('Original seed plan mismatch.')
  if (!engineering && !identical(jobs, s07i_jobs()))
    stop('Reserved recovery requires the entire unchanged frozen job grid.')
  rows <- lapply(jobs, function(job) {
    case <- s07i_case(job)
    s07i_validate_job(job, case, if (engineering) NULL else original_identity)
    input <- s07r1_source_inputs(source_out, job, case, original_identity,
                                s07i_key(job) %in% engineering_refit_keys)
    data.frame(case_id = job$case_id, dataset_id = job$dataset_id,
      source_checkpoint = file.path('checkpoints', paste0(s07i_key(job), '.rds')),
      source_checkpoint_md5 = if (is.null(input$old)) NA_character_ else study05_md5(input$source_path),
      plan_md5 = study05_md5(input$plan_path),
      reference_md5 = if (is.na(input$reference_path)) NA_character_ else study05_md5(input$reference_path),
      mode = if (is.null(input$old)) 'refit_missing' else 'migrate_verified',
      B = job$B_planned, m = job$m, stringsAsFactors = FALSE)
  })
  catalog <- s07i_bind(rows)
  missing <- keys[catalog$mode == 'refit_missing']
  expected <- if (engineering) engineering_refit_keys else s07r1_missing_keys()
  if (!setequal(missing, expected))
    stop('Actual missing original jobs differ from the explicit recovery contract.')
  catalog
}

s07r1_work <- function(job, case = s07i_case(job), source_out, new_out,
                       original_identity, recovery_identity, hooks = list(),
                       engineering_refit = FALSE) {
  engineering <- identical(job$stage, 's07_engineering_fixture')
  permit <- if (engineering) NULL else original_identity
  s07i_validate_job(job, case, permit)
  s07i_hooks(job, hooks)
  if (!engineering) {
    s07r1_validate_recovery_identity(recovery_identity)
    if (!identical(recovery_identity$original_identity, original_identity))
      stop('Recovery identity does not bind the original S07-I1 identity.')
  }
  if (!engineering && isTRUE(engineering_refit))
    stop('Engineering refit override forbidden in reserved execution.')
  if (identical(original_identity, recovery_identity))
    stop('Recovery checkpoints require a distinct implementation identity.')
  source_root <- normalizePath(source_out, mustWork = TRUE)
  output_root <- s07r1_output_path(new_out)
  if (identical(source_root, output_root) ||
      startsWith(output_root, paste0(source_root, '/')) ||
      startsWith(source_root, paste0(output_root, '/')))
    stop('Original and recovery output trees must be separate.')
  dir.create(output_root, recursive = TRUE, showWarnings = FALSE)
  output_root <- normalizePath(output_root, mustWork = TRUE)
  key <- s07i_key(job)
  path <- file.path(output_root, 'checkpoints', paste0(key, '.rds'))
  tryCatch({
    input <- s07r1_source_inputs(source_root, job, case, original_identity,
                                 engineering_refit)
    before <- if (!is.null(input$old)) s07r1_preserved_payload(input$old) else NULL
    parent_md5 <- if (is.null(input$old)) '' else study05_md5(input$source_path)
    existing <- s07r1_checkpoint_read(path, recovery_identity, job, TRUE)
    if (!is.null(existing)) {
      provenance <- existing$recovery
      expected_mode <- if (is.null(input$old)) 'refit_missing' else 'migrate_verified'
      after <- s07r1_preserved_payload(existing)
      hash <- s07r1_payload_sha256(after)
      science <- existing
      recorded_science <- science$science_md5
      science$science_md5 <- NULL
      source_reference_md5 <- if (is.na(input$reference_path)) NA_character_ else
        study05_md5(input$reference_path)
      if (!is.list(provenance) || !isTRUE(provenance$controls_recomputed) ||
          !identical(provenance$amendment, 'S07-R1') ||
          !identical(provenance$control_arithmetic, 'weighted_centered_qr') ||
          !identical(provenance$mode, expected_mode) ||
          !identical(provenance$source_checkpoint_md5, parent_md5) ||
          !identical(provenance$source_plan_md5, study05_md5(input$plan_path)) ||
          !identical(provenance$source_reference_md5, source_reference_md5) ||
          !identical(provenance$original_identity_sha256,
                     s07r1_payload_sha256(original_identity)) ||
          !identical(provenance$recovery_identity_sha256,
                     s07r1_payload_sha256(recovery_identity)) ||
          !identical(provenance$preserved_payload_before_sha256, hash) ||
          !identical(provenance$preserved_payload_after_sha256, hash) ||
          !identical(recorded_science, s07i_science_hash(science)) ||
          (!is.null(before) && !identical(before, after)) ||
          !is.data.frame(existing$control_validation) ||
          !nrow(existing$control_validation) ||
          !all(existing$control_validation$status == 'passed'))
        stop('Recovery checkpoint provenance or validation mismatch.')
      return(path)
    }
    fresh <- is.null(input$old)
    result <- if (fresh) list(job = job, case = case, plan = input$plan,
       generated = s07i_generate(job, case, permit)) else input$old
    if (job$pipeline == 'full_estimator') {
      if (fresh) {
        result$reference <- input$reference
        result$full <- s07i_full(job, case, result$generated, result$plan, permit,
                                 keep_values = engineering || job$dataset_id == 1L)
        result$mechanical_validation <- s07i_validate_full(result$full, permit)
        result$stage <- study05_stage_accounting(result$full)
        if (engineering || job$dataset_id == 1L)
          result$public_audit <- s07i_public_audit(result$full, result$generated)
        result$full$geometry$matrices <- NULL
        result$checkpoint_retention <- paste('Per-fit duplicate Gram/registration matrix cache omitted after mechanical validation;',
          'raw units, exact weights, scalar geometry, full deletions and all population matrices retained.')
      }
      if (fresh) before <- s07r1_preserved_payload(result)
      result$linear <- s07i_linear(job, result$generated, result$reference,
                                    result$plan, hooks)
      result$control_validation <- s07i_bind(lapply(result$linear$paths,
        s07i_validate_control, job = job, weights = result$plan$weights,
        allow_hooks = length(hooks) > 0L))
      result$control_stage <- s07i_control_accounting(result$linear$parents)
      if (engineering || job$dataset_id == 1L)
        result$control_audit <- s07i_bind(lapply(result$linear$paths,
          s07i_mean_physical_audit, job = job, weights = result$plan$weights,
          parents = 0:2))
    } else {
      if (fresh) before <- s07r1_preserved_payload(result)
      result$normal <- s07i_normal(job, case, result$generated, result$plan, permit, hooks)
      result$control_validation <- s07i_validate_control(result$normal$path, job,
        result$plan$weights, allow_hooks = length(hooks) > 0L)
      result$control_stage <- s07i_control_accounting(result$normal$parents)
      if (engineering || job$dataset_id <= 2L)
        result$control_audit <- s07i_mean_physical_audit(result$normal$path, job,
                                                        result$plan$weights)
    }
    after <- s07r1_preserved_payload(result)
    if (!identical(before, after)) stop('Recovery changed a preserved estimator payload.')
    before_hash <- s07r1_payload_sha256(before)
    after_hash <- s07r1_payload_sha256(after)
    if (!identical(before_hash, after_hash)) stop('Preserved payload SHA256 mismatch.')
    result$recovery <- list(amendment = 'S07-R1',
      control_arithmetic = 'weighted_centered_qr',
      case_id = job$case_id, dataset_id = job$dataset_id,
      mode = if (fresh) 'refit_missing' else 'migrate_verified',
      source_checkpoint = if (fresh) '' else file.path('checkpoints', paste0(key, '.rds')),
      source_checkpoint_md5 = parent_md5,
      source_plan_md5 = study05_md5(input$plan_path),
      source_reference_md5 = if (is.na(input$reference_path)) NA_character_ else study05_md5(input$reference_path),
      checkpoint = file.path('checkpoints', paste0(key, '.rds')),
      preserved_payload_before_sha256 = before_hash,
      preserved_payload_after_sha256 = after_hash,
      controls_recomputed = TRUE,
      full_estimator_reused = job$pipeline == 'full_estimator' && !fresh,
      full_estimator_recomputed = job$pipeline == 'full_estimator' && fresh,
      original_identity_sha256 = s07r1_payload_sha256(original_identity),
      recovery_identity_sha256 = s07r1_payload_sha256(recovery_identity))
    result$science_md5 <- NULL
    result$science_md5 <- s07i_science_hash(result)
    study05_checkpoint_save(result, path, recovery_identity)
    s07r1_checkpoint_read(path, recovery_identity, job)
    cat('Recovered', key, result$recovery$mode, 'B', job$B_planned, '\n')
    flush.console()
    path
  }, error = function(e) {
    # The incident is written only in the new tree. Original inputs stay intact.
    s06_incident(path, 's07r1_uncompleted_job', conditionMessage(e))
    stop(e)
  })
}
