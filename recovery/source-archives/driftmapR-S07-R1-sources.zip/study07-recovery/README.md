# S07-R1 recovery runner for driftmapR

This is a bounded numerical recovery of the frozen Study 07 implementation.
It uses the pinned driftmapR engine; it is not a new package release or a new
calibration design. Read `SPECIFICATION.md` for the exact scope and accounting
contract and the final implementation lock for executed validation evidence.

The repair evaluates linear/normal control quadratic forms from weighted
centered-data QR factors and independently checks them with expanded-sample
SVD. Original covariance entries and selection thresholds are preserved. All
controls are recomputed uniformly. Existing full-estimator payloads are reused
with equality checks; only the five originally uncommitted sparse jobs may
refit under their exact original plans.

## Layout and dependencies

Restore these sibling directories in the original pinned workspace:

- `r-runtime/`: the Study 06 pinned runtime, R 4.5.3 and driftmapR 0.0.7.9000;
- `study07-execution/`: immutable S07-I1;
- `study07-specification/`: immutable S07-D1 and its vendors;
- `study07-recovery/`: this amendment;
- `study07-engineering/S07-I1-final/`: original engineering input grid;
- the complete original Study 07 checkpoint chain for reserved recovery.

No new R dependency is required. The inherited independent audits use Python
and NumPy; `sha256sum` fingerprints serialized preserved payloads. The runtime
identity retains its original path binding. The supplied source/runtime archive
hashes and the original checkpoint catalog are retained in the handoff/evidence.

## Engineering validation

Run from the workspace root:

```sh
r-runtime/bin/Rscript-local study07-recovery/scripts/test.R study07-recovery-validation/tests
r-runtime/bin/Rscript-local study07-recovery/scripts/run.R engineering study07-engineering/S07-I1-final study07-recovery-validation/grid 4
python3 study07-recovery/audit/final-audit.py study07-recovery-validation/grid --engineering
```

The engineering domain is seed 781 / dataset 999. It cannot substitute reserved
IDs. The test runner captures R assertions and independent Python tests. Its
full-grid run retains all twelve original engineering panels, 1,564 planned
draw vectors, all nine population references, all failure/deletion ledgers,
and four explicitly engineering-only figures. Exact figure hashes must be
reviewed before `scripts/freeze.R GRID TEST_EVIDENCE_DIR` can seal the runner.

After a freeze, use `scripts/verify.R` to verify all source/evidence bytes and
ancestral identities. Frozen sources must not be edited. Engineering reruns
use a new output directory if the source identity differs.

## Reserved recovery command

After restoring and checking the full original 25-part checkpoint chain:

```sh
r-runtime/bin/Rscript-local study07-recovery/scripts/verify.R
r-runtime/bin/Rscript-local study07-recovery/scripts/run.R reserved study07-results/S07-D1 study07-results/S07-R1 4
```

The reserved command refuses an unfrozen implementation, unexpected missing
inputs, changed source checkpoints/plans/references, or a partial or corrupt
new checkpoint. It preserves incidents as infrastructure exceptions and never
silently redraws. Repeating the command resumes validated checkpoints under
the same identity. A run becomes complete only after all 6,480 panels and the
full independent accounting/report audit pass.

## Evidence and limits

The source output remains immutable and distinct from the recovery output.
`recovery-provenance.json` records source and recovered fingerprints, preserved
payload equality, and the exact migration/refit mode per panel. Engineering
provenance also independently compares original exported full panel fields.
Python verifies RDS bytes and paired hashes but does not decode RDS; the R
runner enforces object equality, while inherited Python audits reconstruct
the full-estimator arithmetic from its exported scalar/matrix evidence.

This freeze uses engineering fixtures only. It does not resolve the five
reserved exceptions by itself or establish coverage calibration. Final study
conclusions remain pending complete frozen recovery. The next development
decision is the S07-D1 v0.1 scope assessment, not an automatic new calibration.
