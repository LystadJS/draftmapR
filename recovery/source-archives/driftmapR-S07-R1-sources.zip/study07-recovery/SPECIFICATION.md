# S07-R1: numerical recovery amendment

Status: amendment contract; execution requires the completed implementation
freeze and its passing evidence. This amendment does not replace S07-D1 or
S07-I1. Their source trees, seed plan, runtime, and original execution evidence
remain immutable. The authorization is to implement, validate, and freeze the
recovery. No reserved measurements or weights are generated during that work.

## Reason and scope

The original run attempted all 6,480 planned panels. It committed 6,475 validated
checkpoints and recorded five implementation-validation exceptions:
`s07_sparse_m12` datasets 18, 20, 30, 32, and 37. Independent weighted-versus-
expanded control calculations disagreed above the frozen relative scalar
tolerance near the existing covariance condition boundary. These exceptions are
infrastructure incompleteness, not statistical non-delivery. They cannot be
deleted from the denominator or interpreted as statistical failures.

R1 changes only the numerical evaluation and validation of quadratic forms for
the population-linear and independent-normal controls. The repair applies
uniformly to every control path in all 6,480 panels. It does not selectively
repair the five exceptions. Full-estimator fits, covariance estimators, pivots,
regions, population references, and screening rules are unchanged.

## Numerical contract

For m paired units with integer weights w summing to m, let mu_w be the original
weighted mean and A have rows sqrt(w_i)(x_i - mu_w). The existing stored
jackknife covariance is S = A' A / [m(m-1)]. Its original matrix entries, means,
conditional covariance, and eligibility decision are retained. In particular,
positive definiteness still requires the smallest eigenvalue to exceed 1e-8
times the largest. No ridge, pseudoinverse, condition relaxation, or fallback
to another statistical estimator is introduced.

After that gate passes, factor the centered data using a pivoted QR:
A[,p] = Q R. Evaluate the quadratic form at displacement d as

    q = ||sqrt(m) sqrt(m-1) solve(t(R), d[p])||^2.

Zero-weight rows are omitted from the factor, while all original values must
still satisfy the original finite-input contract. The displacement uses the
same recorded means as S07-I1. A singular or nonfinite factor/solve is an
explicit unsuccessful attempted pivot, never a replacement draw. Observed
control-region truth and zero-inclusion statistics use the same observed-unit
factor. Cutoffs, type-7 quantiles, area formulas, and delivery gates retain
their original definitions. Normal Hotelling and chi-square control inclusion
statistics use this arithmetic too. Full-estimator and analytic diagnostic
regions retain S07-I1 arithmetic.

Independent validation physically expands the multiplicities and uses the SVD
of its centered data: if A_expanded = U diag(s) V', evaluate
q = m(m-1) sum((V' d / s)^2). Compare scalar pivots using the original criterion
abs(q_QR - q_SVD) <= 1e-9 max(1, abs(q_SVD)). Means, covariance matrices, gates,
required counts, physical deletions, and all inherited independent audits
remain checked. Successful engineering hooks that substitute a different
covariance while keeping original unit values are outside this factor contract
and must be rejected; failure-injection hooks remain engineering-only.

## Reuse, recovery, and provenance

Before reserved recovery, verify the original D1 and I1 freezes and pinned
runtime, then verify every file in the original checkpoint-12 catalog, including
6,480 draw plans, 6,475 checkpoints, nine references, and recorded incidents.
Reject missing or corrupt source files, mismatched identities, unexpected job
grids, changed plans, or additional committed source jobs. Original files are
read-only: no quarantine, repair in place, or destructive resume operation.

Every validated original checkpoint is migrated into a new output directory.
Its exact generated units, saved plan, full-estimator payload, reference, and
full-estimator validation evidence are retained. All linear/normal controls and
their validation/accounting are recomputed. R checks identical preserved
payloads before and after, records serialized SHA-256 fingerprints, and records
the original source checkpoint MD5. The independent Python audit verifies the
source bytes, recovered bytes, identity grid, and paired payload hashes. For
engineering fixtures it additionally compares the original and recovered full
panel exports. The Python audit does not claim to decode RDS independently.

Only the five named uncommitted jobs may regenerate their exact original
measurements and full fits, using their already saved draw plans and population
references. No new seed, redraw, reduced B, replacement dataset, early stopping,
or post-outcome cohort is permitted. Any other source incompleteness blocks
recovery as infrastructure failure. Partial new output is preserved and may be
resumed only under the identical R1 freeze and source provenance.

The reserved target remains 6,480 panels, 1,313,520 planned draw vectors,
31,232,000 two-frame full-estimator deletion slots, 15,600 full-estimator region
rows, and 18,000 independent-normal region rows. Failed, unavailable, blocked,
and policy-withheld outputs remain explicit. Preserve D/M, C/D, C/M, Z/D, Z/M,
Wilson intervals, outer-panel MCSEs, sparse-unit non-delivery, and the separate
AR(1) dependence-stress interpretation. The paired B=199/799 subset remains
separate from each complete primary panel set. No completed marker or final
scientific conclusion is permitted until the entire grid and independent audit
pass.

## Engineering gate and freeze

Use only the frozen engineering domain (seed 781, dataset 999) and deterministic
numerical fixtures. Do not load the five reserved diagnostic-replay matrices to
tune or certify the repair. Exercise the twelve archived engineering panels,
forced engineering-only reconstruction, failed-pivot accounting, strict input
corruption/missing-file refusal, resume identity checks, serial/parallel
agreement, inherited report/figure audits, and negative audit mutations.

Retain exact test outputs and inspect all four engineering figures. Verify the
ancestor freezes again. Seal all recovery source, specification, provenance
locks, and retained evidence in a new immutable S07-R1 manifest. The original
sources stay byte-identical. This engineering freeze generates zero reserved
measurement panels and zero reserved bootstrap weights; it makes no coverage
calibration or release-readiness claim.

After a frozen recovery is executed, assess the complete mechanism evidence
under S07-D1 and make the planned v0.1 scope decision. Do not automatically add
another calibration study in response to a small secondary deficit.
