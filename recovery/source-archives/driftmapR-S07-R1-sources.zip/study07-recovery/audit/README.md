# Independent S07-R1 audit

`final-audit.py OUTPUT --engineering` audits the recovered twelve engineering
fixtures. Omit `--engineering` only for the complete reserved 6,480-panel run
after the recovery implementation is frozen and execution is authorized.

The entry point imports the frozen S07-I1 `final-audit.py`. Its complete job,
draw, deletion, population, full-estimator, public-adapter, reporting,
non-delivery, product-hash, and figure checks run unchanged. Only the panel
control component is replaced. The original full-estimator panel auditor runs
with an empty control list, then the replacement checks the original influence
construction and each control parent and region.

The numerical reference physically expands the retained multiplicities,
centers the expanded sample, and computes an SVD of that sample divided by
`sqrt(m * (m - 1))`. Scalar pivots and observed-region statistics use the
singular factors. Production uses weighted QR. The original scalar comparison
bound is retained: absolute discrepancy at most `1e-9 * max(1, abs(reference))`.
No covariance regularization, altered SPD gate, pivot clipping, changed
resampling, or changed region acceptance thresholds are introduced.

Provenance verification requires the entire planned job grid. Engineering has
twelve migrated checkpoints and no refits. Reserved execution has 6,475
migrations and exactly five original missing sparse jobs: 18, 20, 30, 32, and
37. Source checkpoint bytes, new checkpoint bytes, preservation hashes, and
per-panel recovery markers are checked. Engineering also compares all
unchanged exported payload fields against the retained original panel JSON.
For reserved migration, Python verifies source bytes and the hashes of the
preserved R payload before and after recovery; R enforces exact object identity
before serialization. Python does not decode the RDS payload. The independent
numerical full-estimator audit still reconstructs its exported calculations.

Successful execution writes `final-audit.json`, `recovery-final-audit.json`,
and `recovery-audit.json`. A failed run preserves a separate failure JSON.
These are read-only audits with respect to measurements and resampling plans.

Run deterministic audit tests from the workspace root:

```sh
PYTHONPATH=study07-execution/scripts:study07-recovery/audit \
  python3 study07-recovery/audit/test_recovery_audit.py --report AUDIT-TESTS.json
```

The tests use synthetic engineering arrays and temporary provenance fixtures.
They never access reserved observations or generate random samples. Their
machine-readable report records the exact audit source hashes.
