#!/usr/bin/env python3
"""Run every frozen S07-I1 final audit with the S07-R1 control overlay."""
import sys
sys.dont_write_bytecode = True
import argparse
import importlib.util
import json
from pathlib import Path

from recovery_science import FROZEN, audit_panel
from recovery_provenance import audit_provenance, digest
from audit_math import Checks


def load_frozen():
    spec = importlib.util.spec_from_file_location('s07_i1_frozen_final_audit', FROZEN / 'final-audit.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def audit(out, engineering=False):
    A = Checks(); provenance = audit_provenance(A, out, engineering)
    frozen = load_frozen()
    frozen.audit_panel = audit_panel
    # All original complete-grid, full-estimator, physical-deletion, population,
    # reporting, failure-accounting, product-hash and figure assertions execute.
    report = frozen.audit(out, engineering)
    report.update(amendment='S07-R1', control_reference='physically_expanded_centered_svd',
                  control_scalar_tolerance=1e-9, recovery_provenance=provenance,
                  recovery_provenance_assertions=A.count,
                  provenance_checks=A.count,
                  original_final_audit_sha256=digest(FROZEN / 'final-audit.py'))
    report['assertions'] += A.count
    for name in ('final-audit.json', 'recovery-final-audit.json', 'recovery-audit.json'):
        (Path(out) / name).write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('out')
    parser.add_argument('--engineering', action='store_true')
    args = parser.parse_args()
    try:
        print(json.dumps(audit(args.out, args.engineering)))
    except Exception as e:
        (Path(args.out) / 'recovery-final-audit-failed.json').write_text(
            json.dumps(dict(status='failed', amendment='S07-R1', message=str(e)), indent=2) + '\n')
        raise
