"""Read-only chain-of-custody checks for the separate S07-R1 products."""
import hashlib
import json
import re
from pathlib import Path

from audit_math import boolean, integer, read, unique


def digest(path, algorithm='sha256'):
    h = hashlib.new(algorithm)
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def contained(root, name):
    root = Path(root).resolve(); p = (root / name).resolve()
    if not p.is_relative_to(root):
        raise AssertionError('Provenance path outside its stated output')
    return p


def check_payload(A, before, after):
    fields = ('job', 'weights', 'streams', 'X', 'reference', 'screen', 'frames')
    for field in fields:
        A.check((field in before) == (field in after), 'Preserved panel field presence ' + field)
        if field in before:
            A.check(before[field] == after[field], 'Exact preserved panel payload ' + field)
    old = {c['entity']: c for c in before['controls']}
    new = {c['entity']: c for c in after['controls']}
    A.check(set(old) == set(new), 'Preserved control target grid')
    for entity in old:
        for field in ('values', 'truth'):
            A.check(old[entity][field] == new[entity][field], 'Exact preserved control input ' + field)


def audit_provenance(A, out, engineering=False):
    out = Path(out).resolve()
    path = out / 'recovery-provenance.json'
    p = json.loads(path.read_text())
    A.check(p.get('schema_version') == 1 and p.get('amendment') == 'S07-R1',
            'Recovery provenance schema and amendment')
    A.check(p.get('engineering') is engineering, 'Recovery execution domain')
    source = Path(p['source_output']).resolve()
    A.check(source != out and source.is_dir(), 'Separate retained S07-I1 source output')
    jobs = unique(read(out / 'job-manifest.csv'), ('case_id', 'dataset_id'))
    rows = unique(p['rows'], ('case_id', 'dataset_id'))
    A.check(set(rows) == set(jobs), 'Complete recovery provenance job grid')
    A.check(len(rows) == (12 if engineering else 6480), 'Full original plan recovery count')
    refits = set(); migrated = 0
    for key, row in rows.items():
        job = jobs[key]
        A.check(boolean(row['controls_recomputed']) is True, 'Every control uniformly recomputed')
        key_name = f"{job['case_id']}-{integer(job['dataset_id']):04d}"
        source_plan = source / 'draw-plans' / (key_name + '.rds')
        A.check(source_plan.is_file() and digest(source_plan, 'md5') == row['source_plan_md5'],
                'Exact retained source draw-plan bytes')
        if job['pipeline'] == 'full_estimator':
            reference = source / 'population' / (job['case_id'] + '.rds')
            A.check(reference.is_file() and digest(reference, 'md5') == row['source_reference_md5'],
                    'Exact retained population-reference bytes')
        else:
            A.check(row.get('source_reference_md5') in (None, '', 'NA'),
                    'Normal controls have no invented population reference')
        after = contained(out, row['checkpoint'])
        A.check(after.is_file() and digest(after, 'md5') == row['checkpoint_md5'],
                'Recovered checkpoint identity bytes')
        for field in ('preserved_payload_before_sha256', 'preserved_payload_after_sha256'):
            A.check(isinstance(row[field], str) and re.fullmatch('[0-9a-f]{64}', row[field]) is not None,
                    'Explicit serialized preserved-payload SHA256')
        A.check(row['preserved_payload_before_sha256'] == row['preserved_payload_after_sha256'],
                'Preserved payload before/after SHA256 equality')
        if row['mode'] == 'migrate_verified':
            migrated += 1; before = contained(source, row['source_checkpoint'])
            A.check(before.is_file() and digest(before, 'md5') == row['source_checkpoint_md5'],
                    'Original verified checkpoint identity bytes')
        else:
            A.check(row['mode'] == 'refit_missing' and not engineering,
                    'Only explicitly registered missing reserved jobs may refit')
            refits.add((integer(job['case_index']), integer(job['dataset_id'])))
            A.check(row.get('source_checkpoint') in (None, '') and
                    row.get('source_checkpoint_md5') in (None, '', 'NA'), 'No invented source checkpoint for missing job')
        panel_name = f"{job['case_id']}-{integer(job['dataset_id']):04d}.json"
        new_panel = json.loads((out / 'tables' / 'panels' / panel_name).read_text())
        marker = new_panel.get('recovery', {})
        A.check(marker.get('amendment') == 'S07-R1' and
                marker.get('control_arithmetic') == 'weighted_centered_qr', 'Exported panel recovery marker')
        for field in ('mode', 'source_checkpoint', 'source_checkpoint_md5',
                      'source_plan_md5', 'source_reference_md5',
                      'preserved_payload_before_sha256', 'preserved_payload_after_sha256', 'controls_recomputed'):
            A.check(marker.get(field) == row.get(field), 'Panel and ledger provenance agree: ' + field)
        if engineering:
            old_panel = json.loads((source / 'tables' / 'panels' / panel_name).read_text())
            check_payload(A, old_panel, new_panel)
    A.check(refits == (set() if engineering else {(8, n) for n in (18, 20, 30, 32, 37)}),
            'Exact five authorized missing-job identities; no outcome-dependent subset')
    A.check(migrated == (12 if engineering else 6475), 'Exact verified checkpoint migration count')
    return dict(status='passed', amendment='S07-R1', migrated=migrated, refitted=len(refits),
                engineering=engineering, provenance_sha256=digest(path),
                preserved_payload_verification=('Independent equality of all preserved exported panel fields, '
                    'plus exact source checkpoint bytes and R-enforced serialized payload hash equality.' if engineering else
                    'Exact source checkpoint bytes and R-enforced serialized payload hash equality. '
                    'Python does not decode RDS; unchanged full-estimator arithmetic is independently audited from exports.'))
