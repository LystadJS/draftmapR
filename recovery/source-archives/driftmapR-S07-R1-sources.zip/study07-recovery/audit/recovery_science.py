"""S07-R1 independent expanded-sample control arithmetic.

The frozen S07-I1 full-estimator audit is called unchanged.  Only its control
arithmetic is replaced.  No measurements, weights, or random states are made.
"""
import math
from pathlib import Path
import sys
sys.dont_write_bytecode = True

FROZEN = Path(__file__).resolve().parents[2] / 'study07-execution' / 'scripts'
sys.path.insert(0, str(FROZEN))
import numpy as np
import audit_science as legacy_science
from audit_math import arr, boolean, covrow, helmert, integer, number, quantile, spd, unique

AMENDMENT = 'S07-R1'
SCALAR_TOLERANCE = 1e-9


def scalar_near(A, actual, expected, label):
    """The original R engineering bound; no conditioning-dependent relaxation."""
    actual, expected = number(actual), number(expected)
    A.check(math.isfinite(actual) and math.isfinite(expected) and
            abs(actual - expected) <= SCALAR_TOLERANCE * max(1., abs(expected)), label)


def expanded_factor(values, weights):
    """Physically duplicate units, independently center, and take the SVD.

    The production implementation uses a weighted QR factor.  This audit uses
    an expanded m-by-2 matrix and its right singular vectors instead.
    """
    values, weights = arr(values), arr(weights)
    if values.ndim != 2 or values.shape[1] != 2 or weights.shape != (len(values),):
        raise ValueError('Invalid control dimensions')
    if (not np.isfinite(values).all() or not np.isfinite(weights).all() or
            np.any(weights < 0) or np.any(weights != np.floor(weights))):
        raise ValueError('Nonfinite control or invalid multiplicities')
    expanded = np.repeat(values, weights.astype(int), axis=0)
    m = len(expanded)
    if m < 2:
        raise ValueError('At least two occurrences required')
    mean = expanded.mean(axis=0)
    centered = expanded - mean
    _, singular, right = np.linalg.svd(centered / math.sqrt(m * (m - 1)), full_matrices=False)
    covariance = centered.T @ centered / (m * (m - 1))
    return mean, covariance, singular, right


def factor_pivot(displacement, factor):
    _, _, singular, right = factor
    if not np.isfinite(singular).all() or np.any(singular <= 0):
        return math.nan
    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
        standardized = right @ arr(displacement) / singular
        return float(standardized @ standardized)


def audit_controls(A, p, ref=None):
    job = p['job']; m = integer(job['m']); B = integer(job['B_planned'])
    W = arr(p['weights'])
    if ref is not None:
        Q, E = helmert(); X = arr(p['X']); K = arr(ref['K']); h = []
        for t in range(2):
            x = Q.T @ X[t]
            h.append(np.einsum('ai,kab,bi->ik', x, E, x) -
                     np.einsum('kab,ab->k', E, Q.T @ K[t] @ Q))
        h = np.concatenate(h, axis=1)
        A.check(len(p['controls']) == 3, 'Complete population influence target set')
        for j, c in enumerate(p['controls']):
            psi = (h @ arr(ref['jacobians'][2][j]).T if
                   boolean(ref['derivative'][j]['available']) else np.full((m, 2), np.nan))
            A.near(c['values'], psi, 'Paired-unit population influence')
    else:
        A.check(len(p['controls']) == 1, 'One normal mean control')

    for control in p['controls']:
        v = arr(control['values']); truth = arr(control['truth'])
        A.check(v.shape == (m, 2) and truth.shape == (2,), 'Control input dimensions')
        rows = unique(control['parents'], ('parent_id',))
        A.check(set(rows) == {(str(i),) for i in range(B + 1)}, 'Complete control parent grid')
        finite = np.isfinite(v).all(); mu = v.mean(0)
        observed_factor = expanded_factor(v, np.ones(m)) if finite else None
        expected_pivots = {}
        for b in range(B + 1):
            r = rows[(str(b),)]; w = np.ones(m) if b == 0 else W[b-1]
            A.check(boolean(r['covariance_required']) is True, 'Every control covariance required')
            A.check(boolean(r['covariance_attempted']) == finite, 'Control blocked accounting')
            A.check(boolean(r['point_available']) == finite, 'Control point availability')
            A.check(boolean(r['pivot_required']) == (b > 0), 'Bootstrap-only pivot requirement')
            A.check(integer(r['required_occurrences']) == m and
                    integer(r['required_unique']) == np.count_nonzero(w) and
                    integer(r['distinct_units']) == np.count_nonzero(w) and
                    integer(r['max_multiplicity']) == int(max(w)), 'Control multiplicity accounting')
            if not finite:
                A.check(not boolean(r['covariance_ok']) and not boolean(r['pivot_attempted']) and
                        not boolean(r['pivot_ok']), 'Blocked controls cannot deliver pivots')
                A.check(math.isnan(number(r['pivot'])), 'Blocked pivot retained as unavailable')
                continue
            factor = expanded_factor(v, w); mean, S = factor[:2]
            A.near([r['dx'], r['dy']], truth + mean, 'Expanded paired mean')
            A.near(covrow(r), S, 'Expanded occurrence covariance')
            A.near(covrow(r, 'conditional_'), S * (m-1) / m,
                   'Conditional bootstrap finite-unit factor')
            covariance_ok = spd(S)
            A.check(boolean(r['covariance_ok']) == covariance_ok, 'Unchanged control SPD gate')
            pivot_attempted = b > 0 and covariance_ok
            A.check(boolean(r['pivot_attempted']) == pivot_attempted, 'Control pivot attempt accounting')
            q = factor_pivot(mean - mu, factor) if pivot_attempted else math.nan
            pivot_ok = pivot_attempted and math.isfinite(q) and q >= 0
            A.check(boolean(r['pivot_ok']) == pivot_ok, 'Stable scalar pivot availability')
            if pivot_ok:
                scalar_near(A, r['pivot'], q, 'Expanded SVD scalar control pivot')
                scalar_near(A, r['pivot_raw'], q, 'Expanded SVD raw control pivot')
                expected_pivots[b] = q
            else:
                A.check(math.isnan(number(r['pivot'])), 'Unavailable pivot is not replaced')

        regions = p.get('regions', p.get('linear_regions', []))
        for r in [r for r in regions if r['entity'] == control['entity']]:
            budget = integer(r['budget']); S = covrow(rows[('0',)]); method = r['method']
            pivots = [expected_pivots[b] for b in range(1, budget + 1) if b in expected_pivots]
            n = len(pivots); studentized = method.endswith('studentized')
            cutoff = ((m-1) * (.05 ** (-2 / (m-2)) - 1) if method == 'normal_hotelling' else
                      -2 * math.log(.05) if method == 'normal_chisquare_wald' else
                      quantile(pivots, .95) if n >= 20 else math.nan)
            A.near(r['cutoff_raw'], cutoff, 'Control finite-B/Hotelling cutoff')
            A.check(integer(r['pivot_n']) == n, 'Control valid pivot count')
            A.check(integer(r['required_valid_pivots']) == max(20, math.ceil(.95 * budget)),
                    'Unchanged minimum and 95-percent pivot gate')
            ts = factor_pivot(-mu, observed_factor) if finite and spd(S) else math.nan
            ns = factor_pivot(-truth-mu, observed_factor) if finite and spd(S) else math.nan
            delivered = (finite and spd(S) and math.isfinite(ts) and math.isfinite(ns) and
                         (not studentized or n >= max(20, math.ceil(.95 * budget))) and
                         math.isfinite(cutoff) and cutoff > 0)
            A.check(boolean(r['delivered']) == delivered, 'Control delivery')
            if delivered:
                scalar_near(A, r['truth_statistic'], ts, 'Expanded SVD control truth statistic')
                scalar_near(A, r['null_statistic'], ns, 'Expanded SVD control null statistic')
                A.check(boolean(r['covered']) == (ts <= cutoff * (1 + 1e-12)), 'Control truth inclusion')
                A.check(boolean(r['rejects_zero']) == (ns > cutoff * (1 + 1e-12)), 'Control null exclusion')


def audit_panel(A, p, ref=None):
    marker = p.get('recovery', {})
    A.check(marker.get('amendment') == AMENDMENT, 'Explicit S07-R1 control provenance')
    A.check(marker.get('control_arithmetic') == 'weighted_centered_qr', 'Frozen recovery arithmetic')
    # Original frozen full-estimator, weight, frame, and physical-deletion checks.
    legacy_science.audit_panel(A, dict(p, controls=[]), ref)
    audit_controls(A, p, ref)
