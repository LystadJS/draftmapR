"""Deterministic engineering tests; no reserved jobs or RNG access."""
import copy
import math
import unittest
import sys
sys.dont_write_bytecode = True
import csv
import json
from pathlib import Path
import tempfile
import argparse
import numpy as np
from audit_math import Checks, spd
from recovery_science import audit_panel, expanded_factor, factor_pivot, scalar_near
from recovery_provenance import audit_provenance, check_payload, contained, digest


def fixture(values=None, B=21):
    """Synthetic normal-control payload made with weighted QR arithmetic."""
    if values is None:
        values = np.array([[-3., 1.], [-2., -2.], [-1., 3.], [0., -1.],
                           [1., -3.], [2., 2.], [3., 0.], [4., 1.]])
    m = len(values); mu = values.mean(0)
    weights = np.array([np.roll(np.array([2, 0] + [1] * (m-2)), b % m) for b in range(B)])
    parents = []; all_q = []
    for b in range(B + 1):
        w = np.ones(m) if not b else weights[b-1]
        mean = w @ values / m; d = values - mean
        S = d.T @ (d * w[:, None]) / (m * (m-1))
        Q, R = np.linalg.qr(d * np.sqrt(w[:, None]) / math.sqrt(m * (m-1)), mode='reduced')
        ok = bool(spd(S)); q = float(np.linalg.norm(np.linalg.solve(R.T, mean - mu)) ** 2) if b and ok else math.nan
        parents.append(dict(parent_id=b, covariance_required=True, covariance_attempted=True,
            covariance_ok=ok, point_available=True, dx=mean[0], dy=mean[1],
            var_dx=S[0, 0], var_dy=S[1, 1], cov_dx_dy=S[0, 1],
            conditional_var_dx=S[0, 0]*(m-1)/m, conditional_var_dy=S[1, 1]*(m-1)/m,
            conditional_cov_dx_dy=S[0, 1]*(m-1)/m, pivot_required=b > 0,
            pivot_attempted=bool(b and ok), pivot_ok=math.isfinite(q), pivot=q, pivot_raw=q,
            required_occurrences=m, required_unique=np.count_nonzero(w), distinct_units=np.count_nonzero(w),
            max_multiplicity=int(max(w))))
        if b and math.isfinite(q): all_q.append(q)
    factor = expanded_factor(values, np.ones(m)); ts = factor_pivot(-mu, factor)
    cutoff = float(np.quantile(all_q, .95)) if len(all_q) >= 20 else math.nan
    delivered = spd(factor[1]) and len(all_q) >= max(20, math.ceil(.95*B)) and math.isfinite(cutoff) and cutoff > 0
    region = dict(entity='mean', budget=B, method='normal_bootstrap_studentized', cutoff_raw=cutoff,
        pivot_n=len(all_q), required_valid_pivots=max(20, math.ceil(.95*B)), delivered=bool(delivered),
        truth_statistic=ts, null_statistic=ts, covered=bool(ts <= cutoff*(1+1e-12)) if delivered else None,
        rejects_zero=bool(ts > cutoff*(1+1e-12)) if delivered else None)
    return dict(job=dict(m=m, B_planned=B), weights=weights, streams=np.zeros((B, 7)),
        controls=[dict(values=values, truth=[0., 0.], entity='mean', parents=parents)],
        regions=[region], recovery=dict(amendment='S07-R1', control_arithmetic='weighted_centered_qr'))


class RecoveryScienceTests(unittest.TestCase):
    def test_expanded_svd_matches_independent_weighted_qr(self):
        A = Checks(); audit_panel(A, fixture()); self.assertGreaterEqual(A.count, 300)

    def test_high_conditioning_inside_unchanged_gate(self):
        t = np.arange(16.); x = np.sin(t); y = np.cos(t)
        v = np.column_stack((x, x + .001*y))
        p = fixture(v); A = Checks(); audit_panel(A, p)
        self.assertTrue(spd(expanded_factor(v, np.ones(len(v)))[1]))

    def test_duplicate_units_and_zero_weights(self):
        v = np.array([[1., 2.], [3., -1.], [2., 4.]])
        f = expanded_factor(v, [2, 0, 2]); expanded = v[[0, 0, 2, 2]]
        np.testing.assert_allclose(f[0], expanded.mean(0))
        np.testing.assert_allclose(f[1], np.cov(expanded, rowvar=False)/4)

    def test_invalid_weights_rejected(self):
        for w in ([1, -.5, 2.5], [1, .5, 1.5], [1, 1, math.nan]):
            with self.subTest(w=w), self.assertRaises(ValueError): expanded_factor(np.ones((3, 2)), w)

    def test_invalid_value_rejected(self):
        with self.assertRaises(ValueError): expanded_factor([[1, math.nan], [2, 1]], [1, 1])

    def test_degenerate_covariance_not_rescued(self):
        p = fixture(np.column_stack((np.arange(8.), np.arange(8.))))
        A = Checks(); audit_panel(A, p)
        self.assertFalse(p['regions'][0]['delivered'])
        self.assertTrue(all(not r['covariance_ok'] for r in p['controls'][0]['parents']))

    def test_pivot_corruption_detected(self):
        p = fixture(); p['controls'][0]['parents'][1]['pivot'] += 1e-5
        with self.assertRaisesRegex(AssertionError, 'scalar control pivot'): audit_panel(Checks(), p)

    def test_region_statistic_corruption_detected(self):
        p = fixture(); p['regions'][0]['truth_statistic'] += 1e-5
        with self.assertRaisesRegex(AssertionError, 'truth statistic'): audit_panel(Checks(), p)

    def test_unavailable_pivot_cannot_be_masked(self):
        p = fixture(); p['controls'][0]['parents'][1]['pivot_ok'] = False
        with self.assertRaisesRegex(AssertionError, 'availability'): audit_panel(Checks(), p)

    def test_gate_corruption_detected(self):
        p = fixture(); p['regions'][0]['required_valid_pivots'] = 19
        with self.assertRaisesRegex(AssertionError, 'pivot gate'): audit_panel(Checks(), p)

    def test_minimum_twenty_pivots_is_preserved(self):
        p = fixture(B=19); audit_panel(Checks(), p)
        self.assertFalse(p['regions'][0]['delivered'])

    def test_marker_required(self):
        p = fixture(); p.pop('recovery')
        with self.assertRaisesRegex(AssertionError, 'provenance'): audit_panel(Checks(), p)

    def test_original_scalar_tolerance_exact(self):
        scalar_near(Checks(), 1 + 5e-10, 1, 'bound')
        with self.assertRaisesRegex(AssertionError, 'bound'): scalar_near(Checks(), 1 + 2e-9, 1, 'bound')

    def test_original_full_audit_is_delegated(self):
        p = fixture(); p['weights'][0, 0] += 1
        with self.assertRaisesRegex(AssertionError, 'Exact paired draw counts'): audit_panel(Checks(), p)

    def test_nonfinite_observed_factor_is_nondelivery(self):
        p = fixture(); p['controls'][0]['truth'] = [1e200, 1e200]
        for row in p['controls'][0]['parents']:
            row['dx'] += 1e200; row['dy'] += 1e200
        p['regions'][0].update(delivered=False, covered=None, rejects_zero=None,
                               reason='s07r1_control_factor_failed')
        audit_panel(Checks(), p)


class ProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
        self.old = self.root/'old'; self.new = self.root/'new'
        for root in (self.old, self.new):
            (root/'checkpoints').mkdir(parents=True)
            (root/'tables'/'panels').mkdir(parents=True)
        (self.old/'draw-plans').mkdir()
        (self.old/'population').mkdir()
        self.rows = []; jobs = []
        for ci in list(range(1, 10)) + [101, 102, 103]:
            case = f'fixture_{ci}'; name = f'{case}-0999'
            job = dict(case_id=case, case_index=ci, dataset_id=999,
                       pipeline='full_estimator' if ci < 100 else 'normal_mean_control')
            jobs.append(job)
            for root in (self.old, self.new):
                (root/'checkpoints'/f'{name}.rds').write_bytes(f'fixture checkpoint {ci}'.encode())
            (self.old/'draw-plans'/f'{name}.rds').write_bytes(f'fixture plan {ci}'.encode())
            if ci < 100:
                (self.old/'population'/f'{case}.rds').write_bytes(f'fixture reference {ci}'.encode())
            old = dict(job=job, weights=[[1, 1]], streams=[[0]*7],
                       controls=[dict(entity='mean', values=[[0, 1], [1, 0]], truth=[0, 0])])
            row = dict(case_id=case, dataset_id=999, mode='migrate_verified',
                       source_checkpoint=f'checkpoints/{name}.rds',
                       source_checkpoint_md5=digest(self.old/'checkpoints'/f'{name}.rds', 'md5'),
                       checkpoint=f'checkpoints/{name}.rds',
                       checkpoint_md5=digest(self.new/'checkpoints'/f'{name}.rds', 'md5'),
                       source_plan_md5=digest(self.old/'draw-plans'/f'{name}.rds', 'md5'),
                       source_reference_md5=digest(self.old/'population'/f'{case}.rds', 'md5') if ci < 100 else None,
                       preserved_payload_before_sha256='a'*64, preserved_payload_after_sha256='a'*64,
                       controls_recomputed=True)
            marker = dict(row, amendment='S07-R1', control_arithmetic='weighted_centered_qr')
            (self.old/'tables'/'panels'/f'{name}.json').write_text(json.dumps(old))
            (self.new/'tables'/'panels'/f'{name}.json').write_text(json.dumps(dict(old, recovery=marker)))
            self.rows.append(row)
        with (self.new/'job-manifest.csv').open('w') as f:
            writer = csv.DictWriter(f, fieldnames=list(jobs[0])); writer.writeheader(); writer.writerows(jobs)
        self.save()

    def tearDown(self): self.temp.cleanup()

    def save(self):
        (self.new/'recovery-provenance.json').write_text(json.dumps(dict(schema_version=1,
            amendment='S07-R1', engineering=True, source_output=str(self.old), rows=self.rows)))

    def test_complete_fixture_provenance(self):
        result = audit_provenance(Checks(), self.new, engineering=True)
        self.assertEqual(result['migrated'], 12); self.assertEqual(result['refitted'], 0)

    def test_source_byte_corruption_detected(self):
        (self.old/self.rows[0]['source_checkpoint']).write_bytes(b'changed')
        with self.assertRaisesRegex(AssertionError, 'Original verified checkpoint'): audit_provenance(Checks(), self.new, True)

    def test_draw_plan_corruption_detected(self):
        (self.old/'draw-plans'/'fixture_1-0999.rds').write_bytes(b'changed')
        with self.assertRaisesRegex(AssertionError, 'source draw-plan'): audit_provenance(Checks(), self.new, True)

    def test_reference_corruption_detected(self):
        (self.old/'population'/'fixture_1.rds').write_bytes(b'changed')
        with self.assertRaisesRegex(AssertionError, 'population-reference'): audit_provenance(Checks(), self.new, True)

    def test_preserved_serialization_mismatch_detected(self):
        self.rows[0]['preserved_payload_after_sha256'] = 'b'*64; self.save()
        with self.assertRaisesRegex(AssertionError, 'SHA256 equality'): audit_provenance(Checks(), self.new, True)

    def test_missing_job_detected(self):
        self.rows.pop(); self.save()
        with self.assertRaisesRegex(AssertionError, 'job grid'): audit_provenance(Checks(), self.new, True)

    def test_engineering_cannot_refit_reserved_exception(self):
        self.rows[0]['mode'] = 'refit_missing'; self.save()
        with self.assertRaisesRegex(AssertionError, 'Only explicitly registered'): audit_provenance(Checks(), self.new, True)

    def test_exported_payload_changes_detected(self):
        path = self.new/'tables'/'panels'/'fixture_1-0999.json'
        p = json.loads(path.read_text()); p['weights'][0][0] = 2; path.write_text(json.dumps(p))
        with self.assertRaisesRegex(AssertionError, 'preserved panel payload'): audit_provenance(Checks(), self.new, True)

    def test_marker_disagreement_detected(self):
        path = self.new/'tables'/'panels'/'fixture_1-0999.json'
        p = json.loads(path.read_text()); p['recovery']['controls_recomputed'] = False; path.write_text(json.dumps(p))
        with self.assertRaisesRegex(AssertionError, 'ledger provenance'): audit_provenance(Checks(), self.new, True)

    def test_provenance_cannot_escape_output(self):
        with self.assertRaisesRegex(AssertionError, 'outside'): contained(self.new, '../old/file')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        report = dict(status='passed' if result.wasSuccessful() else 'failed',
            tests=result.testsRun, tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
            skipped=len(result.skipped), reserved_panels_generated=0, reserved_draws_generated=0,
            audit_source_sha256={p.name: digest(p) for p in sorted(Path(__file__).parent.glob('*.py'))})
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    sys.exit(0 if result.wasSuccessful() else 1)
