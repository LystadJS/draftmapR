# Independent numerical review for S07-R1

This review uses deterministic arithmetic fixtures only. It reads no reserved
Study 07 measurement matrices and generates no random numbers. It does not
modify either frozen S07 tree.

## Recommended bounded amendment

Retain the original control means, covariance entries, covariance statuses,
eigenratio threshold, required work, seeds, budgets, and comparison tolerance.
Replace the control scalar-pivot calculation after the existing SPD gate with
a square-root factor calculation. Use an independently expanded-sample SVD
calculation as its engineering/production validation reference. No covariance
regularization, eigenvalue clipping, pseudoinverse, or new successful-fit redraw
is appropriate.

Let occurrence weights be nonnegative integers, with m = sum(w), and let
mu = sum(w_i*x_i)/m. For A_i = sqrt(w_i)*(x_i-mu), the retained covariance is

    S = A' A / [m(m-1)].

For a column-pivoted thin QR factorization A[,p] = Q R, a displacement d has

    d' S^(-1) d = || sqrt(m)*sqrt(m-1)*solve(R', d[p]) ||^2.

This preserves the mathematical statistic but avoids extracting the smallest
eigenvalue after forming A' A. That matrix formation squares the condition
number: covariance ratio near 1e-8 corresponds to a factor singular ratio near
1e-4. Forming/inverting or eigendecomposing the covariance can lose about
1e-8 relative precision in the relevant narrow direction even when the
factor-based calculation remains accurate to the frozen 1e-9 tolerance.

For the independent check, enumerate rows according to w, center the expanded
matrix using independent arithmetic, and compute its thin SVD U diag(s) V'.
The equivalent statistic is

    sum((sqrt(m)*sqrt(m-1) * (V' d) / s)^2).

Zero-multiplicity rows do not enter the factor. Keep the existing whole-input
finite-value validation and m >= 3 rule: this review does not authorize a new
missing-value policy. Degenerate or gate-rejected covariances retain their
original status. An exact zero displacement returns zero only after that gate
has passed. Retain nonfinite arithmetic as failure, never rescue it.

Origin-shifted centering (subtract one represented row before summation) is
numerically preferable within the factor builder. Keep the actual displacement
and reported means consistent with the unchanged estimator. The optional
Python zero-weight-NaN mechanics check is not a change to input acceptance.

## Executed deterministic fixtures

Both R 4.5.3 in the pinned runtime and Python/NumPy 2.3.5 checked 945 fixtures:
three weight patterns (including zeros and concentration), covariance ratios
from 1.001e-8 through 1, five rotation angles, scales 1e-7, 1, and 1e7,
three displacement patterns including zero. No RNG is used.

| Quantity | R | Python |
|---|---:|---:|
| Weighted QR versus expanded SVD: largest relative error | 2.772409e-12 | 3.991614e-12 |
| Covariance-based method: largest relative error | 1.234247e-8 | 1.194253e-8 |
| Covariance-based discrepancies above 1e-9 | 73 / 945 | 66 / 945 |
| QR/SVD comparisons below 1e-9 | 945 / 945 | 945 / 945 |

The R covariance comparison uses the original covariance-spectrum arithmetic;
the Python comparison uses a covariance linear solve. These results establish
a concrete deterministic failure mechanism and validate the proposed remedy
for the tested engineering domain. They are not a reserved-data replay, proof
of complete recovery, or coverage-calibration result.

Commands:

    r-runtime/bin/Rscript-local s07r1-review/deterministic_factor_review.R
    python3 s07r1-review/deterministic_factor_review.py

Both complete with exit code zero. See their machine-readable output files for
all fixture rows and summaries. The parent implementation should incorporate
these files in its saved review/freeze evidence rather than treat scratch as
durable storage.
