list(fixtures = 945L, rng_calls = 0L, study_measurements_generated = 0L, 
    max_weighted_qr_vs_expanded_svd_relative = 2.77240856534254e-12, 
    max_legacy_covariance_spectrum_vs_expanded_svd_relative = 1.23424715305158e-08, 
    legacy_failures_at_1e_minus_9 = 73L, all_qr_svd_fixtures_pass_1e_minus_9 = TRUE)
