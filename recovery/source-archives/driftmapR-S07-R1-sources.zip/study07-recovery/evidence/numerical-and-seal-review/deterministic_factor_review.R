# Independent engineering arithmetic check; no study RNG or reserved input.
weighted_qr <- function(x, w, d) {
  stopifnot(is.matrix(x), ncol(x) == 2L, all(is.finite(x)),
            length(w) == nrow(x), all(is.finite(w)), all(w >= 0),
            all(w == floor(w)), sum(w) >= 3L, length(d) == 2L,
            all(is.finite(d)))
  m <- sum(w)
  z <- x[w > 0, , drop = FALSE]
  a <- sweep(z, 2L, z[1L, ], "-")
  c <- colSums(a * w[w > 0]) / m
  a <- sweep(a, 2L, c, "-") * sqrt(w[w > 0])
  q <- qr(a, LAPACK = TRUE)
  R <- qr.R(q)[1:2, 1:2, drop = FALSE]
  stopifnot(all(is.finite(R)), all(diag(R) != 0))
  scaled <- forwardsolve(t(R), d[q$pivot])
  m * (m - 1) * sum(scaled^2)
}
expanded_svd <- function(x, w, d) {
  expanded <- x[rep(seq_len(nrow(x)), w), , drop = FALSE]
  a <- sweep(expanded, 2L, expanded[nrow(expanded), ], "-")
  a <- sweep(a, 2L, colMeans(a), "-")
  s <- svd(a, nu = 0L, nv = 2L)
  m <- nrow(expanded)
  m * (m - 1) * sum((drop(crossprod(s$v, d)) / s$d)^2)
}
legacy_spectrum <- function(x, w, d) {
  m <- sum(w)
  a <- sweep(x, 2L, colSums(x * w) / m, "-")
  S <- crossprod(a, a * w) / (m * (m - 1))
  scale <- max(abs(S))
  es <- eigen((S / 2 + t(S) / 2) / scale, symmetric = TRUE)
  sum((drop(crossprod(es$vectors, d)) / sqrt(es$values * scale))^2)
}
make_basis <- function(w) {
  k <- seq_along(w) - 1
  u <- cos(k + .3) + k / 17
  v <- sin(k * 1.7 + .2) + k * k / 113
  u <- u - sum(w * u) / sum(w)
  v <- v - sum(w * v) / sum(w)
  u <- u / sqrt(sum(w * u^2))
  v <- v - u * sum(w * u * v)
  v <- v / sqrt(sum(w * v^2))
  cbind(u, v)
}
weight_cases <- list(rep(1L, 12L), c(0L,3L,1L,0L,2L,1L,1L,1L,1L,1L,1L,0L),
                     c(0L,1L,0L,0L,7L,0L,0L,1L,0L,2L,1L,0L))
rows <- list()
for (wi in seq_along(weight_cases)) {
  w <- weight_cases[[wi]]
  basis <- make_basis(w)
  for (ratio in c(1.001e-8, 1.015e-8, 2e-8, 5.531e-8, 1e-6, .1, 1)) {
    for (angle in c(0, .17, pi/4, 1.33, 2.67)) {
      rotation <- matrix(c(cos(angle),sin(angle),-sin(angle),cos(angle)),2,2)
      for (scale in c(1e-7,1,1e7)) {
        x <- sweep(basis, 2L, c(1,sqrt(ratio)), "*") %*% rotation * scale
        ds <- list(drop(c(.25,.125*sqrt(ratio)) %*% rotation)*scale,
                   c(.1,-.07)*scale,c(0,0))
        for (di in seq_along(ds)) {
          d <- ds[[di]]
          a <- weighted_qr(x,w,d)
          b <- expanded_svd(x,w,d)
          old <- legacy_spectrum(x,w,d)
          relative <- abs(a-b)/max(abs(a),abs(b),1e-300)
          old_relative <- abs(old-b)/max(abs(old),abs(b),1e-300)
          stopifnot(is.finite(a), a >= 0, relative < 1e-9)
          rows[[length(rows)+1L]] <- data.frame(weights=wi,ratio=ratio,angle=angle,
            scale=scale,displacement=di,qr_svd_relative=relative,
            legacy_spectrum_relative=old_relative)
        }
      }
    }
  }
}
out <- do.call(rbind,rows)
write.csv(out,"s07r1-review/deterministic-factor-review-R.csv",row.names=FALSE)
summary <- list(fixtures=nrow(out),rng_calls=0L,study_measurements_generated=0L,
  max_weighted_qr_vs_expanded_svd_relative=max(out$qr_svd_relative),
  max_legacy_covariance_spectrum_vs_expanded_svd_relative=max(out$legacy_spectrum_relative),
  legacy_failures_at_1e_minus_9=sum(out$legacy_spectrum_relative > 1e-9),
  all_qr_svd_fixtures_pass_1e_minus_9=TRUE)
dput(summary,"s07r1-review/deterministic-factor-review-R-summary.R")
print(summary)
