"""Independent engineering fixtures; no Study 07 random seeds or data.

QR weighted factor versus physically expanded sample SVD.  This is a numerical
review artifact, not an amendment to frozen study sources or eligibility rules.
"""

import json
import math
from pathlib import Path

import numpy as np


def weighted_qr(x, weights, displacement):
    w = np.asarray(weights)
    if w.ndim != 1 or len(w) != len(x) or not np.isfinite(w).all():
        raise ValueError("finite one-dimensional occurrence weights required")
    if np.any(w < 0) or np.any(w != np.floor(w)):
        raise ValueError("nonnegative integer occurrence weights required")
    m = int(sum(w))
    if m <= 1:
        raise ValueError("at least two represented occurrences required")
    represented = np.asarray(x)[w > 0]
    rw = w[w > 0]
    if represented.shape[1:] != (2,) or not np.isfinite(represented).all():
        raise ValueError("finite two-dimensional represented values required")
    # Subtract an existing point before summation to avoid gratuitous large
    # translation cancellation. Zero-multiplicity rows have no numerical role.
    shifted = represented - represented[0]
    center = np.array([math.fsum(rw * shifted[:, j]) / m for j in range(2)])
    factor = np.sqrt(rw)[:, None] * (shifted - center)
    _, triangular = np.linalg.qr(factor, mode="reduced")
    z = np.linalg.solve(triangular.T, displacement)
    return m * (m - 1) * float(np.dot(z, z))


def expanded_svd(x, weights, displacement):
    # Physically enumerate each occurrence, use independent mean arithmetic,
    # and a different matrix factorization. No weighted covariance reuse.
    expanded = np.array([row.copy() for row, w in zip(x, weights) for _ in range(int(w))])
    shifted = expanded - expanded[-1]
    centered = shifted - shifted.mean(axis=0)
    _, singular, right = np.linalg.svd(centered, full_matrices=False)
    z = (right @ displacement) / singular
    m = len(expanded)
    return m * (m - 1) * float(np.dot(z, z))


def covariance_inverse(x, weights, displacement):
    m = sum(weights)
    centered = x - (weights[:, None] * x).sum(axis=0) / m
    cov = (centered * weights[:, None]).T @ centered / (m * (m - 1))
    return float(displacement @ np.linalg.solve(cov, displacement))


def build_basis(weights):
    n = len(weights)
    k = np.arange(n, dtype=float)
    u = np.cos(k + 0.3) + k / 17
    v = np.sin(k * 1.7 + 0.2) + k * k / 113
    u -= np.dot(weights, u) / sum(weights)
    v -= np.dot(weights, v) / sum(weights)
    u /= np.sqrt(np.dot(weights, u * u))
    v -= u * np.dot(weights, u * v)
    v /= np.sqrt(np.dot(weights, v * v))
    return np.column_stack([u, v])


def main():
    rows = []
    weight_cases = [
        np.ones(12, dtype=int),
        np.array([0, 3, 1, 0, 2, 1, 1, 1, 1, 1, 1, 0]),
        np.array([0, 1, 0, 0, 7, 0, 0, 1, 0, 2, 1, 0]),
    ]
    for wi, weights in enumerate(weight_cases):
        basis = build_basis(weights)
        for ratio in [1.001e-8, 1.015e-8, 2e-8, 5.531e-8, 1e-6, 0.1, 1.0]:
            for angle in [0.0, 0.17, math.pi / 4, 1.33, 2.67]:
                rotation = np.array([[math.cos(angle), -math.sin(angle)],
                                     [math.sin(angle), math.cos(angle)]])
                for scale in [1e-7, 1.0, 1e7]:
                    x = (basis * [1, math.sqrt(ratio)]) @ rotation * scale
                    for di, d in enumerate([
                        np.array([0.25, 0.125 * math.sqrt(ratio)]) @ rotation * scale,
                        np.array([0.1, -0.07]) * scale,
                        np.array([0.0, 0.0]),
                    ]):
                        q = weighted_qr(x, weights, d)
                        ref = expanded_svd(x, weights, d)
                        inv = covariance_inverse(x, weights, d)
                        rel = abs(q - ref) / max(abs(q), abs(ref), 1e-300)
                        inv_rel = abs(inv - ref) / max(abs(inv), abs(ref), 1e-300)
                        rows.append({"weights": wi, "ratio": ratio, "angle": angle,
                                     "scale": scale, "displacement": di,
                                     "qr_svd_relative": rel,
                                     "covariance_inverse_relative": inv_rel})
                        assert np.isfinite(q) and q >= 0
                        assert rel < 1e-9, rows[-1]
                    # Zero-weight values can be absent/nonfinite: they must not
                    # enter the factor if the upstream contract permits them.
                    if np.any(weights == 0):
                        x0 = x.copy()
                        x0[weights == 0] = np.nan
                        d = np.array([0.1, -0.07]) * scale
                        assert weighted_qr(x0, weights, d) == weighted_qr(x, weights, d)
    degenerate = np.array([[0., 0.], [1., 2.], [2., 4.]])
    # Degenerate covariance stays an upstream SPD-gate rejection. It must not
    # acquire a pseudo-inverse fallback; the factor routine alone is no gate.
    singular = np.linalg.svd(degenerate - degenerate.mean(axis=0), compute_uv=False)
    assert (singular[-1] / singular[0]) ** 2 < 1e-8
    summary = {
        "purpose": "deterministic engineering fixtures only",
        "study_measurements_generated": 0,
        "rng_calls": 0,
        "fixtures": len(rows),
        "max_weighted_qr_vs_expanded_svd_relative": max(r["qr_svd_relative"] for r in rows),
        "max_covariance_inverse_vs_expanded_svd_relative": max(r["covariance_inverse_relative"] for r in rows),
        "inverse_failures_at_1e_minus_9": sum(r["covariance_inverse_relative"] > 1e-9 for r in rows),
        "all_qr_svd_fixtures_pass_1e_minus_9": True,
        "worst_factor_fixture": max(rows, key=lambda r: r["qr_svd_relative"]),
    }
    path = Path(__file__).with_name("deterministic-factor-review.json")
    path.write_text(json.dumps({"summary": summary, "fixtures": rows}, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
