#!/usr/bin/env python3
"""Engineering-only S07-R1 sealing tests using isolated synthetic trees.

Production source files are copied, never modified. The R verification tests
stub ancestry lookup with a fixed synthetic identity so they isolate freeze
guard behavior; integrated engineering checks verify the actual ancestry.
"""
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / "study07-recovery"
RSCRIPT = WORKSPACE / "r-runtime/bin/Rscript-local"
SPEC = importlib.util.spec_from_file_location("s07r1_manifest_test_target", SOURCE / "scripts/manifest.py")
MANIFEST = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MANIFEST)


class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        (self.root / "R").mkdir()
        (self.root / "R/a.R").write_text("x <- 1\n")
        (self.root / "evidence").mkdir()
        (self.root / "evidence/proof.json").write_text("{}\n")

    def tearDown(self):
        self.temporary.cleanup()

    def seal(self):
        lock = dict(freeze_id="S07-R1", ready_for_recovery=True,
                    sha256_files=MANIFEST.inventory(self.root))
        (self.root / "implementation-freeze.json").write_text(json.dumps(lock))
        (self.root / "implementation-freeze.rds").write_bytes(b"synthetic-lock")

    def test_exact_grid(self):
        self.assertEqual(set(MANIFEST.inventory(self.root)), {"R/a.R", "evidence/proof.json"})

    def test_source_identity_excludes_evidence(self):
        self.assertEqual(set(MANIFEST.inventory(self.root, sources=True)), {"R/a.R"})

    def test_locks_excluded_from_manifest(self):
        self.seal()
        self.assertEqual(MANIFEST.verify(self.root)["files"], 2)

    def test_altered_bytes_refused(self):
        self.seal()
        (self.root / "R/a.R").write_text("x <- 2\n")
        with self.assertRaisesRegex(AssertionError, "SHA256 mismatch"):
            MANIFEST.verify(self.root)

    def test_extra_file_refused(self):
        self.seal()
        (self.root / "extra.txt").write_text("extra\n")
        with self.assertRaisesRegex(AssertionError, "file grid"):
            MANIFEST.verify(self.root)

    def test_symlink_refused(self):
        (self.root / "link").symlink_to(self.root / "R/a.R")
        with self.assertRaisesRegex(ValueError, "Symlinks"):
            MANIFEST.inventory(self.root)

    def test_missing_file_refused(self):
        self.seal()
        (self.root / "R/a.R").unlink()
        with self.assertRaisesRegex(AssertionError, "file grid"):
            MANIFEST.verify(self.root)


class FreezeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        for name in ("R", "scripts", "grid", "test-evidence"):
            (self.root / name).mkdir()
        shutil.copy2(SOURCE / "scripts/freeze.R", self.root / "scripts/freeze.R")
        (self.root / "R/load.R").write_text(
            "s07r1_load <- function(root) invisible(root)\n"
            "s07r1_source_identity <- function() list(synthetic='current')\n"
            "s07i_engineering_jobs <- function() list(synthetic='jobs')\n")

    def tearDown(self):
        self.temporary.cleanup()

    def run_freeze(self):
        return subprocess.run([str(RSCRIPT), str(self.root / "scripts/freeze.R"),
                               str(self.root / "grid"), str(self.root / "test-evidence")],
                              text=True, capture_output=True, check=False)

    def test_partial_json_lock_refused(self):
        (self.root / "implementation-freeze.json").write_text("{}")
        result = self.run_freeze()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Existing or partial freeze refused", result.stderr)

    def test_partial_rds_lock_refused(self):
        (self.root / "implementation-freeze.rds").write_bytes(b"partial")
        result = self.run_freeze()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Existing or partial freeze refused", result.stderr)

    def test_stale_engineering_identity_refused(self):
        result = subprocess.run([str(RSCRIPT), "-e",
            "saveRDS(list(synthetic='stale'),commandArgs(TRUE)[1])",
            str(self.root / "grid/execution-identity.rds")], text=True,
            capture_output=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        result = self.run_freeze()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Engineering execution identity differs", result.stderr)
        self.assertFalse((self.root / "implementation-freeze.json").exists())

    def test_stale_test_identity_refused(self):
        code = "saveRDS(list(synthetic='current'),commandArgs(TRUE)[1]);saveRDS(list(synthetic='jobs'),commandArgs(TRUE)[2])"
        result = subprocess.run([str(RSCRIPT), "-e", code,
            str(self.root / "grid/execution-identity.rds"), str(self.root / "grid/seed-plan.rds")],
            text=True, capture_output=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        evidence = dict(status="passed", failed=0, error=0, warning=0, skipped=0,
            assertions=1, reserved_panels_generated=0, reserved_draws_generated=0,
            source_identity={"synthetic": "stale"})
        (self.root / "test-evidence/implementation-tests.json").write_text(json.dumps(evidence))
        result = self.run_freeze()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Implementation test evidence is incomplete or stale", result.stderr)
        self.assertFalse((self.root / "implementation-freeze.json").exists())

    def test_r_verify_guards_and_cache(self):
        for name in ("R/guards.R", "scripts/manifest.py"):
            shutil.copy2(SOURCE / name, self.root / name)
        check = self.root / "check.R"
        check.write_text(r'''
root <- commandArgs(TRUE)[1]
source(file.path(root, "R/guards.R"))
s07r1_paths <- function() list(recovery=root)
study05_md5 <- function(path) unname(tools::md5sum(path))
current <- list(study="synthetic",freeze_id="S07-R1 engineering",engineering=TRUE)
s07r1_source_identity <- function() current
expect_error <- function(expr, pattern) {
  error <- tryCatch({force(expr);NULL},error=identity)
  stopifnot(inherits(error,"error"),grepl(pattern,conditionMessage(error),fixed=TRUE))
}
writeLines("x <- 1",file.path(root,"R/synthetic.R"))
seal <- function() {
  inventory <- s07r1_manifest("inventory")
  lock <- list(freeze_id="S07-R1",ready_for_recovery=TRUE,
    reserved_measurement_panels_generated=0L,reserved_bootstrap_weight_vectors_generated=0L,
    source_identity=current,files=names(inventory),
    md5=study05_md5(file.path(root,names(inventory))),sha256_files=inventory)
  jsonlite::write_json(lock,file.path(root,"implementation-freeze.json"),auto_unbox=TRUE)
  lock$json_sha256 <- s07r1_file_sha256(file.path(root,"implementation-freeze.json"))
  saveRDS(lock,file.path(root,"implementation-freeze.rds"))
}
expect_error(s07r1_verify(),"not completely frozen")
seal()
id <- s07r1_verify()
stopifnot(isTRUE(s07r1_validate_recovery_identity(id)))
different <- id;different$freeze_sha256 <- "wrong"
expect_error(s07r1_validate_recovery_identity(different),"Current verified frozen")
json_path <- file.path(root,"implementation-freeze.json")
json_bytes <- readBin(json_path,"raw",n=file.info(json_path)$size)
writeLines("{}",json_path)
expect_error(s07r1_verify(),"JSON lock changed")
expect_error(s07r1_validate_recovery_identity(id),"Current verified frozen")
writeBin(json_bytes,json_path)
unlink(file.path(root,"R/synthetic.R"))
expect_error(suppressWarnings(s07r1_verify()),"SHA256 mismatch")
writeLines("x <- 2",file.path(root,"R/synthetic.R"))
expect_error(suppressWarnings(s07r1_verify()),"SHA256 mismatch")
writeLines("x <- 1",file.path(root,"R/synthetic.R"))
current$study <- "stale"
expect_error(s07r1_verify(),"source or ancestry changed")
current$study <- "synthetic"
unlink(json_path)
expect_error(s07r1_verify(),"not completely frozen")
cat("Nine isolated R freeze/cache guard cases passed.\n")
''')
        result = subprocess.run([str(RSCRIPT), str(check), str(self.root)],
                                text=True, capture_output=True, check=False)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("Nine isolated R", result.stdout)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path,
                        default=Path(__file__).with_name("manifest-tests.json"))
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    paths = [SOURCE / name for name in ("scripts/manifest.py", "scripts/freeze.R", "R/guards.R")]
    report = dict(status="passed" if result.wasSuccessful() else "failed",
                  tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  skipped=len(result.skipped), isolated_R_guard_cases=9,
                  reserved_panels_generated=0, reserved_draws_generated=0,
                  source_sha256={str(path.relative_to(SOURCE)): hashlib.sha256(path.read_bytes()).hexdigest()
                                 for path in paths},
                  scope="Copied production sealing code on synthetic trees. R ancestry is stubbed only in isolated precondition tests; no original or reserved inputs are read.")
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
