# Engineering-only sealing. This script has no generation calls.
args <- commandArgs(TRUE)
if (length(args) != 2L) stop("Usage: freeze.R ENGINEERING_GRID TEST_EVIDENCE_DIR")
script <- sub("^--file=", "", commandArgs(FALSE)[grepl("^--file=", commandArgs(FALSE))][1])
root <- normalizePath(file.path(dirname(script), ".."))
source(file.path(root, "R/load.R"))
s07r1_load(root)
locks <- file.path(root, c("implementation-freeze.rds", "implementation-freeze.json"))
if (any(file.exists(locks))) {
  stop("Existing or partial freeze refused; amendments require a new freeze ID.")
}
grid <- normalizePath(args[1], mustWork = TRUE)
evidence <- normalizePath(args[2], mustWork = TRUE)
identity <- s07r1_source_identity()
read_json <- function(path) jsonlite::read_json(path, simplifyVector = FALSE)
json_equal <- function(x, y) {
  identical(jsonlite::toJSON(x, auto_unbox = TRUE, digits = NA, null = "null", na = "null"),
            jsonlite::toJSON(y, auto_unbox = TRUE, digits = NA, null = "null", na = "null"))
}
scalar_equal <- function(value, target) {
  is.numeric(value) && length(value) == 1L && is.finite(value) && value == target
}
zero_fields <- function(value, fields) {
  all(vapply(fields, function(name) scalar_equal(value[[name]], 0), logical(1)))
}
require_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}
require_true(identical(readRDS(file.path(grid, "execution-identity.rds")), identity),
             "Engineering execution identity differs from current recovery sources.")
require_true(identical(readRDS(file.path(grid, "seed-plan.rds")), s07i_engineering_jobs()),
             "Engineering job grid is not the exact 12 frozen fixtures.")

tests <- read_json(file.path(evidence, "implementation-tests.json"))
require_true(identical(tests$status, "passed") &&
  zero_fields(tests, c("failed", "error", "warning", "skipped")) &&
  is.numeric(tests$assertions) && length(tests$assertions) == 1L &&
  is.finite(tests$assertions) && tests$assertions > 0 &&
  zero_fields(tests, c("reserved_panels_generated", "reserved_draws_generated")) &&
  json_equal(tests$source_identity, identity), "Implementation test evidence is incomplete or stale.")
python <- read_json(file.path(evidence, "independent-audit-tests.json"))
require_true(identical(python$status, "passed") &&
  zero_fields(python, c("failures", "errors", "skipped")) &&
  is.numeric(python$tests) && length(python$tests) == 1L &&
  is.finite(python$tests) && python$tests > 0 &&
  json_equal(python$source_identity, identity), "Independent audit test evidence is incomplete or stale.")

complete <- read_json(file.path(grid, "execution-complete.json"))
require_true(isTRUE(complete$engineering) && scalar_equal(complete$panels, 12) &&
  scalar_equal(complete$draws, 1564) &&
  zero_fields(complete, c("reserved_measurement_panels_generated",
                         "reserved_bootstrap_weight_vectors_generated")),
  "Engineering grid is incomplete or contains reserved generation.")
audit_script <- file.path(root, "audit/final-audit.py")
status <- system2("python3", c(shQuote(audit_script), shQuote(grid), "--engineering"),
                  stdout = TRUE, stderr = TRUE)
writeLines(status, file.path(grid, "freeze-independent-audit.log"))
require_true(is.null(attr(status, "status")), paste(status, collapse = "\n"))
audit <- read_json(file.path(grid, "final-audit.json"))
require_true(identical(audit$status, "passed") && isTRUE(audit$engineering) &&
  scalar_equal(audit$panels, 12) && scalar_equal(audit$planned_draws, 1564) &&
  scalar_equal(audit$population_roles, 16524) &&
  zero_fields(audit, c("reserved_panels_generated", "reserved_draws_generated")),
  "Inherited final independent audit did not pass the complete engineering grid.")
recovery_audit <- read_json(file.path(grid, "recovery-audit.json"))
require_true(identical(recovery_audit$status, "passed") &&
  scalar_equal(recovery_audit$panels, 12) &&
  is.numeric(recovery_audit$provenance_checks) &&
  length(recovery_audit$provenance_checks) == 1L &&
  is.finite(recovery_audit$provenance_checks) && recovery_audit$provenance_checks > 0 &&
  identical(recovery_audit$recovery_provenance$status, "passed") &&
  isTRUE(recovery_audit$recovery_provenance$engineering),
  "Recovery provenance audit did not pass the complete engineering grid.")
figures <- sprintf("figure-%02d.png", seq_len(4L))
review <- read_json(file.path(evidence, "figure-review.json"))
require_true(isTRUE(review$reviewed) &&
  identical(unname(unlist(review$files)), figures) &&
  identical(unname(unlist(review$sha256)),
            s07r1_file_sha256(file.path(grid, "analysis", figures))),
  "The four engineering figures require a matching visual review.")

retain <- function(from, name) {
  to <- file.path(root, "evidence", name)
  dir.create(dirname(to), recursive = TRUE, showWarnings = FALSE)
  if (!file.exists(from)) stop("Missing freeze evidence: ", from)
  if (file.exists(to)) {
    if (!identical(s07r1_file_sha256(from), s07r1_file_sha256(to))) {
      stop("Conflicting retained evidence: ", name)
    }
  } else if (!file.copy(from, to)) stop("Failed to retain freeze evidence: ", name)
}
for (name in c("implementation-tests.json", "independent-audit-tests.json", "figure-review.json")) {
  retain(file.path(evidence, name), name)
}
for (name in c("execution-identity.rds", "execution-complete.json", "final-audit.json",
               "recovery-audit.json", "content-manifest.csv", "job-manifest.csv")) {
  retain(file.path(grid, name), paste0("engineering-", name))
}
for (name in c("mechanical-validation.csv", "control-validation.csv", "public-audit.csv",
               "control-audit.csv", "stage-accounting.csv", "control-stage-accounting.csv")) {
  retain(file.path(grid, "tables", name), paste0("engineering-", name))
}
require_true(identical(identity, s07r1_source_identity()),
             "Source identity changed during sealing.")
inventory <- s07r1_manifest("inventory")
files <- names(inventory)
lock <- list(freeze_id = "S07-R1", frozen_at_utc = study05_utc(),
  source_identity = identity, design = identity$design, runtime = identity$runtime,
  original_identity = identity$original_identity,
  input_catalog_sha256 = identity$input_catalog_sha256,
  contract_sha256 = identity$contract_sha256,
  files = files, md5 = unname(study05_md5(file.path(root, files))),
  sha256_files = inventory, ready_for_recovery = TRUE,
  reserved_measurement_panels_generated = 0L,
  reserved_bootstrap_weight_vectors_generated = 0L,
  validation = list(implementation_tests = tests$assertions,
    independent_audit_tests = python$tests, engineering_audit = audit,
    recovery_audit = recovery_audit, figures_reviewed = 4L),
  contract = paste("S07-D1 unchanged. Uniform stable linear and normal controls.",
    "Verified full-estimator payloads retained; exact missing jobs require reserved execution.",
    "Engineering fixtures only at freeze. No new statistical calibration claim."))
jsonlite::write_json(lock, locks[2], pretty = TRUE, auto_unbox = TRUE,
                     digits = NA, na = "null", null = "null")
lock$json_sha256 <- s07r1_file_sha256(locks[2])
study05_atomic_rds(lock, locks[1])
verified <- s07r1_verify()
cat("S07-R1 frozen with zero reserved measurements or weight vectors generated.\n")
cat("Freeze SHA256: ", verified$freeze_sha256, "\n", sep = "")
