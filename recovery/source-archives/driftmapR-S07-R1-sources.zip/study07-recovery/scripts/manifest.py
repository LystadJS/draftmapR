#!/usr/bin/env python3
"""Read-only SHA256 inventory and exact-tree verification for S07-R1."""
import hashlib
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
LOCKS = {"implementation-freeze.json", "implementation-freeze.rds"}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inventory(root, sources=False):
    root = Path(root)
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError("Symlinks are forbidden in the recovery source tree")
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in LOCKS or (sources and relative.startswith("evidence/")):
            continue
        result[relative] = {"sha256": sha256(path), "bytes": path.stat().st_size}
    return result


def verify(root):
    root = Path(root)
    lock = json.loads((root / "implementation-freeze.json").read_text())
    if lock.get("freeze_id") != "S07-R1" or lock.get("ready_for_recovery") is not True:
        raise AssertionError("Invalid S07-R1 freeze")
    actual = inventory(root)
    if actual != lock["sha256_files"]:
        raise AssertionError("Frozen exact file grid or SHA256 mismatch")
    return {"status": "passed", "freeze_id": "S07-R1", "files": len(actual),
            "freeze_sha256": sha256(root / "implementation-freeze.json")}


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit("Usage: manifest.py inventory|sources|verify ROOT; sha256 FILE...")
    operation = sys.argv[1]
    if operation == "sha256":
        print(json.dumps([sha256(path) for path in sys.argv[2:]]))
    elif len(sys.argv) != 3:
        raise SystemExit("One root directory is required")
    elif operation in ("inventory", "sources"):
        print(json.dumps(inventory(sys.argv[2], sources=operation == "sources")))
    elif operation == "verify":
        print(json.dumps(verify(sys.argv[2])))
    else:
        raise SystemExit("Unknown manifest operation")
