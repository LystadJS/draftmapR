args <- commandArgs(TRUE)
if (length(args) < 3L || length(args) > 4L || !args[1] %in% c('engineering', 'reserved'))
  stop('Usage: run.R engineering|reserved ORIGINAL_OUTPUT RECOVERY_OUTPUT [WORKERS]')
script <- sub('^--file=', '', commandArgs(FALSE)[grepl('^--file=', commandArgs(FALSE))][1])
p <- normalizePath(file.path(dirname(script), '..'))
source(file.path(p, 'R/load.R')); s07r1_load(p)
s07r1_run(args[2], args[3], if (length(args) == 4L) as.integer(args[4]) else 4L,
          engineering = args[1] == 'engineering')
