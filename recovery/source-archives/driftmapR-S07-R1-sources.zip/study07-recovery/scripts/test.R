args <- commandArgs(TRUE)
if (length(args) != 1L) stop('Usage: test.R TEST_EVIDENCE_DIR')
script <- sub('^--file=', '', commandArgs(FALSE)[grepl('^--file=', commandArgs(FALSE))][1])
p <- normalizePath(file.path(dirname(script), '..'))
source(file.path(p, 'R/load.R')); s07r1_load(p)
out <- normalizePath(args[1], mustWork = FALSE)
dir.create(out, recursive = TRUE, showWarnings = FALSE)
identity <- s07r1_source_identity()
# Source the files in this order because integration tests use runner fixtures.
reporter <- testthat::ListReporter$new()
testthat::with_reporter(reporter, {
  for (name in c('test-controls.R', 'test-runner.R', 'test-integration.R')) {
    reporter$start_file(name)
    sys.source(file.path(p, 'tests', name), envir = .GlobalEnv)
    reporter$end_file()
  }
})
results <- as.data.frame(reporter$get_results())
write.csv(results[setdiff(names(results), 'result')], file.path(out, 'implementation-test-blocks.csv'),
          row.names = FALSE)
totals <- list(failed = sum(results$failed), error = sum(results$error),
  warning = sum(results$warning), skipped = sum(results$skipped), assertions = sum(results$passed))
record <- c(list(status = if (sum(unlist(totals[c('failed','error','warning','skipped')])) == 0) 'passed' else 'failed'),
  totals, list(blocks = nrow(results), source_identity = identity,
  reserved_panels_generated = 0L, reserved_draws_generated = 0L))
s07i_json(record, file.path(out, 'implementation-tests.json'))
if (record$status != 'passed') stop('R engineering assertions failed; see retained test evidence.')
py <- system2('python3', c(shQuote(file.path(p, 'audit/test_recovery_audit.py')),
  '--report', shQuote(file.path(out, 'independent-audit-tests.json'))), stdout = TRUE, stderr = TRUE,
  env = c('PYTHONDONTWRITEBYTECODE=1', paste0('PYTHONPATH=', shQuote(paste(
    file.path(s07r1_paths()$execution, 'scripts'), file.path(p, 'audit'), sep = ':')))))
writeLines(py, file.path(out, 'independent-audit-tests.log'))
if (!is.null(attr(py, 'status'))) stop('Python engineering audit tests failed.')
audit <- jsonlite::read_json(file.path(out, 'independent-audit-tests.json'), simplifyVector = FALSE)
audit$source_identity <- identity
s07i_json(audit, file.path(out, 'independent-audit-tests.json'))
if (!identical(identity, s07r1_source_identity())) stop('Sources changed during tests.')
cat('Passed', totals$assertions, 'R assertions in', nrow(results), 'blocks and', audit$tests, 'Python tests.\n')
