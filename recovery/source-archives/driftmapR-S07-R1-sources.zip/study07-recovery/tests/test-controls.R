# May run via testthat after the recovery loader, or directly with Rscript.
if (!exists('s07r1_mean_path', mode = 'function')) {
  source('study07-execution/R/load.R')
  s07i_load('study07-execution')
  s07r1_original_mean_path <- s07i_mean_path
  s07r1_original_mean_regions <- s07i_mean_regions
  s07r1_original_validate_control <- s07i_validate_control
  source('study07-recovery/R/controls.R')
}

s07r1_test_basis <- function(w) {
  k <- seq_along(w) - 1L
  u <- cos(k + .3) + k / 17
  v <- sin(k * 1.7 + .2) + k * k / 113
  u <- u - sum(w * u) / sum(w)
  v <- v - sum(w * v) / sum(w)
  u <- u / sqrt(sum(w * u^2))
  v <- v - u * sum(w * u * v)
  cbind(u, v / sqrt(sum(w * v^2)))
}
s07r1_test_input <- function(normal = FALSE, B = 21L) {
  job <- s07i_fixture(if (normal) 101L else 8L, B)$job
  n <- job$m
  w <- rep(1L, n); w[1:3] <- c(0L, 2L, 1L)
  weights <- t(vapply(seq_len(B), function(b) w[((seq_len(n) + b - 2L) %% n) + 1L], integer(n)))
  list(job = job, values = s07r1_test_basis(rep(1L, n)), weights = weights,
       truth = c(.2, -.1), construction = if (normal) 'normal_mean' else 'population_linear',
       entity = if (normal) 'mean' else 'E015')
}
s07r1_test_path <- function(f, hooks = list()) s07r1_mean_path(f$values, f$truth,
  f$weights, f$job, f$construction, f$entity, hooks)
s07r1_test_factor_failure <- function(expr) {
  env <- environment(s07r1_mean_path)
  original <- get('s07r1_weighted_qr', env)
  on.exit(assign('s07r1_weighted_qr', original, env))
  assign('s07r1_weighted_qr', function(...) stop('forced deterministic factor failure'), env)
  eval.parent(substitute(expr))
}

testthat::test_that('945 deterministic weighted QR and expanded SVD factors agree', {
  weight_cases <- list(rep(1L, 12L), c(0L,3L,1L,0L,2L,1L,1L,1L,1L,1L,1L,0L),
    c(0L,1L,0L,0L,7L,0L,0L,1L,0L,2L,1L,0L))
  count <- 0L; worst <- 0
  for (w in weight_cases) {
    basis <- s07r1_test_basis(w)
    for (ratio in c(1.001e-8, 1.015e-8, 2e-8, 5.531e-8, 1e-6, .1, 1))
      for (angle in c(0, .17, pi/4, 1.33, 2.67))
        for (scale in c(1e-7, 1, 1e7)) {
          rotation <- matrix(c(cos(angle), sin(angle), -sin(angle), cos(angle)), 2L)
          x <- sweep(basis, 2L, c(1, sqrt(ratio)), '*') %*% rotation * scale
          S <- s07_linear_covariance(x, w)$jackknife
          stopifnot(study03_covariance_status(S)$valid)
          for (d in list(drop(c(.25,.125*sqrt(ratio)) %*% rotation)*scale, c(.1,-.07)*scale, c(0,0))) {
            a <- s07r1_weighted_qr(x, w, d, S)
            b <- s07r1_expanded_svd(x, w, d, S)
            error <- abs(a-b)/max(abs(a),abs(b),1e-300)
            worst <- max(worst,error); count <- count + 1L
            testthat::expect_lt(error, 1e-9)
          }
        }
  }
  testthat::expect_identical(count, 945L)
  testthat::expect_lt(worst, 1e-10)
})

testthat::test_that('all covariance payloads means and gate decisions remain identical', {
  f <- s07r1_test_input()
  old <- s07r1_original_mean_path(f$values, f$truth, f$weights, f$job, f$construction, f$entity)
  new <- s07r1_test_path(f)
  fields <- setdiff(names(old$parents), c('pivot', 'pivot_raw', 'pivot_ok', 'message', 'warnings'))
  testthat::expect_identical(new$parents[fields], old$parents[fields])
  testthat::expect_identical(new$covariances, old$covariances)
  testthat::expect_identical(new$observed, old$observed)
  testthat::expect_identical(new$truth, old$truth)
  testthat::expect_identical(new$values, old$values)
  testthat::expect_identical(s07r1_validate_control(new, f$job, f$weights)$status, 'passed')
})

testthat::test_that('gate threshold, input rejection, and zero pivots are unchanged', {
  x <- s07r1_test_basis(rep(1L,12L)); w <- rep(1L,12L)
  for (ratio in c(0, .99e-8, 1e-8)) {
    S <- diag(c(1,ratio))
    testthat::expect_false(study03_covariance_status(S)$valid)
    testthat::expect_error(s07r1_weighted_qr(x,w,c(0,0),S),'unchanged covariance gate')
  }
  S <- s07_linear_covariance(x,w)$jackknife
  testthat::expect_identical(s07r1_weighted_qr(x,w,c(0,0),S),0)
  testthat::expect_error(s07r1_weighted_qr(x,replace(w,1,-1),c(1,0),S),'Invalid')
  testthat::expect_error(s07r1_weighted_qr(x,replace(w,1,.5),c(1,0),S),'Invalid')
  w[1] <- 0; x[1,1] <- NA_real_
  testthat::expect_error(s07r1_weighted_qr(x,w,c(1,0),S),'Invalid')
})

testthat::test_that('pivot hooks run once and failed pivots retain every slot', {
  f <- s07r1_test_input(); seen <- integer()
  path <- s07r1_test_path(f,list(pivot=function(ctx,p){seen <<- c(seen,ctx$parent_id);Inf}))
  testthat::expect_identical(seen,seq_len(f$job$B_planned))
  testthat::expect_false(any(path$parents$pivot_ok))
  testthat::expect_true(all(path$parents$pivot_attempted[-1]))
  testthat::expect_true(all(is.infinite(path$parents$pivot_raw[-1])))
  testthat::expect_identical(s07r1_validate_control(path,f$job,f$weights,allow_hooks=TRUE)$status,'passed')
  testthat::expect_false(any(s07r1_mean_regions(path,f$job)$delivered))
})

testthat::test_that('covariance failure hooks preserve gates and changed finite hooks fail explicitly', {
  f <- s07r1_test_input()
  singular <- s07r1_test_path(f,list(covariance=function(ctx,S)matrix(0,2,2)))
  testthat::expect_false(any(singular$parents$covariance_ok))
  testthat::expect_false(any(singular$parents$pivot_attempted))
  testthat::expect_error(s07r1_test_path(f,list(covariance=function(ctx,S)2*S)),
    'covariance-changing hooks are unsupported')
  testthat::expect_error(s07r1_test_path(f,list(covariance=function(ctx,S)if(ctx$parent_id==0L)2*S else S)),
    'covariance-changing hooks are unsupported')
})

testthat::test_that('factor failures are explicit and never fall back to covariance pivots', {
  f <- s07r1_test_input()
  path <- s07r1_test_factor_failure(s07r1_test_path(f))
  testthat::expect_true(all(path$parents$pivot_attempted[-1]))
  testthat::expect_false(any(path$parents$pivot_ok))
  testthat::expect_true(all(grepl('forced deterministic factor failure',path$parents$message[-1])))
  good <- s07r1_test_path(f)
  regions <- s07r1_test_factor_failure(s07r1_mean_regions(good,f$job))
  testthat::expect_false(any(regions$available))
  testthat::expect_false(any(regions$delivered))
  testthat::expect_true(all(regions$reason == 's07r1_control_factor_failed'))
})

testthat::test_that('regions use observed factors without changing cutoffs areas or delivery gates', {
  for (normal in c(FALSE,TRUE)) {
    f <- s07r1_test_input(normal)
    path <- s07r1_test_path(f)
    original <- s07r1_original_mean_regions(path,f$job,normal)
    actual <- s07r1_mean_regions(path,f$job,normal)
    for (n in c('available','delivered','cutoff','cutoff_raw','area','area_raw'))
      testthat::expect_identical(actual[[n]],original[[n]])
    S <- path$covariances[[1L]]; w <- rep(1L,f$job$m)
    truth <- s07r1_expanded_svd(path$values,w,path$truth-path$observed,S)
    null <- s07r1_expanded_svd(path$values,w,-path$observed,S)
    testthat::expect_equal(actual$truth_statistic[actual$available],rep(truth,sum(actual$available)),tolerance=1e-9)
    testthat::expect_equal(actual$null_statistic[actual$available],rep(null,sum(actual$available)),tolerance=1e-9)
    testthat::expect_identical(actual$covered[actual$delivered],truth<=actual$cutoff[actual$delivered]*(1+1e-12))
    testthat::expect_identical(actual$rejects_zero[actual$delivered],null>actual$cutoff[actual$delivered]*(1+1e-12))
  }
})

testthat::test_that('unavailable influences preserve required but unattempted accounting', {
  f <- s07r1_test_input(); f$values[,] <- NA_real_
  path <- s07r1_test_path(f)
  testthat::expect_false(any(path$parents$covariance_attempted))
  testthat::expect_false(any(path$parents$pivot_attempted))
  testthat::expect_identical(s07r1_validate_control(path,f$job,f$weights)$status,'passed')
})

testthat::test_that('validator catches deliberate scalar corruption at the frozen tolerance', {
  f <- s07r1_test_input(); path <- s07r1_test_path(f)
  path$parents$pivot[2] <- path$parents$pivot[2] + 1e-5
  testthat::expect_error(s07r1_validate_control(path,f$job,f$weights),'Control scalar pivot')
})
