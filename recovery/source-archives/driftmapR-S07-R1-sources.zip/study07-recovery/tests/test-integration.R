testthat::test_that('reserved API is blocked before the recovery freeze', {
  if (!file.exists(file.path(s07r1_paths()$recovery, 'implementation-freeze.rds')))
    testthat::expect_error(s07r1_identity(FALSE), 'not completely frozen')
  s07r1_context(clear = TRUE)
  testthat::expect_error(s07r1_validate_recovery_identity(list(freeze_id = 'S07-R1')),
                         'verified frozen')
  job <- s07i_jobs()[[418L]]
  testthat::expect_identical(s07i_key(job), 's07_sparse_m12-0018')
  # Validation fails before any source reads or generation.
  testthat::expect_error(s07r1_work(job, source_out = 'absent-source', new_out = 'absent-output',
    original_identity = s07i_verify_implementation(), recovery_identity = list(freeze_id = 'S07-R1')),
    'verified frozen')
})

testthat::test_that('serial and parallel migration agree with unchanged RNG and source bytes', {
  source_out <- file.path(s07r1_paths()$recovery, '../study07-engineering/S07-I1-final')
  original <- readRDS(file.path(source_out, 'execution-identity.rds'))
  jobs <- s07i_engineering_jobs()[10:11]
  identity <- list(study = 'S07-R1 serial parallel engineering comparison')
  serial <- tempfile('s07r1-serial-'); parallel <- tempfile('s07r1-parallel-')
  on.exit(unlink(c(serial, parallel), recursive = TRUE), add = TRUE)
  source_files <- vapply(jobs, function(j) file.path(source_out, 'checkpoints',
                         paste0(s07i_key(j), '.rds')), character(1))
  source_hash <- study05_md5(source_files)
  set.seed(812L); seed <- .Random.seed
  work <- function(j, out) s07r1_work(j, source_out = source_out, new_out = out,
                           original_identity = original, recovery_identity = identity)
  a <- study05_execute_jobs(jobs, function(j) work(j, serial), 1L)
  b <- study05_execute_jobs(jobs, function(j) work(j, parallel), 2L)
  testthat::expect_identical(.Random.seed, seed)
  testthat::expect_identical(study05_md5(source_files), source_hash)
  for (i in seq_along(jobs)) {
    x <- s07r1_checkpoint_read(a[[i]], identity, jobs[[i]])
    y <- s07r1_checkpoint_read(b[[i]], identity, jobs[[i]])
    testthat::expect_identical(x, y)
    testthat::expect_true(all(x$control_stage$required ==
      x$control_stage$attempted + x$control_stage$unattempted_required))
    testthat::expect_true(all(x$control_stage$attempted ==
      x$control_stage$successful + x$control_stage$failed_after_attempt))
  }
})

testthat::test_that('corrupt recovered checkpoints are retained and cannot count as delivery', {
  z <- s07r1_test_source(3L)
  out <- tempfile('s07r1-corrupt-recovered-')
  on.exit(unlink(c(z$source_out, out), recursive = TRUE), add = TRUE)
  path <- s07r1_work(z$job, z$case, z$source_out, out, z$identity, z$recovery_identity)
  writeBin(as.raw(c(9, 8, 7)), path)
  damaged <- study05_md5(path)
  testthat::expect_error(s07r1_work(z$job, z$case, z$source_out, out,
                           z$identity, z$recovery_identity), 'checksum mismatch')
  testthat::expect_identical(study05_md5(path), damaged)
  testthat::expect_error(s07r1_status(out, list(z$job), z$recovery_identity, TRUE), 'Unresolved')
  status <- s07r1_status(out, list(z$job), z$recovery_identity)
  testthat::expect_identical(status$status, 'infrastructure_unresolved')
  testthat::expect_false(file.exists(file.path(out, 'execution-complete.json')))
})
