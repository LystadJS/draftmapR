# Engineering fixtures only. The original reserved output is never opened here.
s07r1_test_source <- function(B = 3L) {
  f <- s07i_fixture(101L, B)
  source_out <- tempfile('s07r1-test-source-')
  dir.create(source_out)
  identity <- list(study = 'S07-R1 source engineering fixture', job = f$job)
  plan <- s07i_draws(f$job, f$case)
  generated <- s07i_generate(f$job, f$case)
  normal <- s07i_normal(f$job, f$case, generated, plan)
  result <- list(job = f$job, case = f$case, plan = plan, generated = generated,
    normal = normal,
    control_validation = s07i_validate_control(normal$path, f$job, plan$weights),
    control_stage = s07i_control_accounting(normal$parents),
    control_audit = s07i_mean_physical_audit(normal$path, f$job, plan$weights))
  result$science_md5 <- s07i_science_hash(result)
  saveRDS(identity, file.path(source_out, 'execution-identity.rds'), version = 2L)
  saveRDS(list(f$job), file.path(source_out, 'seed-plan.rds'), version = 2L)
  checkpoint <- file.path(source_out, 'checkpoints', paste0(s07i_key(f$job), '.rds'))
  draw_path <- file.path(source_out, 'draw-plans', paste0(s07i_key(f$job), '.rds'))
  study05_checkpoint_save(result, checkpoint, identity)
  study05_checkpoint_save(plan, draw_path, identity)
  list(job = f$job, case = f$case, source_out = source_out, identity = identity,
       result = result, checkpoint = checkpoint, draw_path = draw_path,
       recovery_identity = list(study = 'S07-R1 engineering fixture', job = f$job))
}

s07r1_test_inventory <- function(path) {
  files <- sort(list.files(path, recursive = TRUE, all.files = TRUE, no.. = TRUE))
  stats::setNames(study05_md5(file.path(path, files)), files)
}

testthat::test_that('strict checkpoint reads preserve damaged inputs and reject mismatches', {
  z <- s07r1_test_source()
  on.exit(unlink(z$source_out, recursive = TRUE), add = TRUE)
  before <- s07r1_test_inventory(z$source_out)
  testthat::expect_identical(s07r1_checkpoint_read(z$checkpoint, z$identity, z$job), z$result)
  testthat::expect_error(s07r1_checkpoint_read(z$checkpoint, list(changed = TRUE), z$job),
                         'identity or job')
  changed_job <- z$job
  changed_job$data_stream[2L] <- changed_job$data_stream[2L] + 1L
  testthat::expect_error(s07r1_checkpoint_read(z$checkpoint, z$identity, changed_job),
                         'identity or job')
  testthat::expect_identical(s07r1_test_inventory(z$source_out), before)
  missing <- file.path(z$source_out, 'absent.rds')
  testthat::expect_null(s07r1_checkpoint_read(missing, z$identity, z$job, TRUE))
  testthat::expect_error(s07r1_checkpoint_read(missing, z$identity, z$job), 'Missing or partial')
  writeBin(as.raw(c(1, 2, 3)), z$checkpoint)
  damaged <- s07r1_test_inventory(z$source_out)
  testthat::expect_error(s07r1_checkpoint_read(z$checkpoint, z$identity, z$job, TRUE),
                         'checksum mismatch')
  testthat::expect_identical(s07r1_test_inventory(z$source_out), damaged)
  unlink(paste0(z$checkpoint, '.manifest.rds'))
  partial <- s07r1_test_inventory(z$source_out)
  testthat::expect_error(s07r1_checkpoint_read(z$checkpoint, z$identity, z$job, TRUE),
                         'Missing or partial')
  testthat::expect_identical(s07r1_test_inventory(z$source_out), partial)
})

testthat::test_that('migration preserves payloads, recomputes controls, and resumes identically', {
  z <- s07r1_test_source(21L)
  out <- tempfile('s07r1-test-output-')
  on.exit(unlink(c(z$source_out, out), recursive = TRUE), add = TRUE)
  before_files <- s07r1_test_inventory(z$source_out)
  catalog <- s07r1_preflight(z$source_out, list(z$job), z$identity)
  testthat::expect_identical(catalog$mode, 'migrate_verified')
  path <- s07r1_work(z$job, z$case, z$source_out, out, z$identity, z$recovery_identity)
  result <- s07r1_checkpoint_read(path, z$recovery_identity, z$job)
  testthat::expect_identical(s07r1_preserved_payload(result), s07r1_preserved_payload(z$result))
  testthat::expect_identical(result$recovery$mode, 'migrate_verified')
  testthat::expect_true(result$recovery$controls_recomputed)
  testthat::expect_identical(result$recovery$preserved_payload_before_sha256,
                             result$recovery$preserved_payload_after_sha256)
  testthat::expect_identical(result$recovery$source_checkpoint_md5,
                             study05_md5(z$checkpoint))
  first_bytes <- s07r1_test_inventory(out)
  testthat::expect_identical(s07r1_work(z$job, z$case, z$source_out, out,
                            z$identity, z$recovery_identity), path)
  testthat::expect_identical(s07r1_test_inventory(out), first_bytes)
  testthat::expect_identical(s07r1_test_inventory(z$source_out), before_files)
  testthat::expect_error(s07r1_work(z$job, z$case, z$source_out, z$source_out,
                            z$identity, z$recovery_identity), 'must be separate')
  nested <- file.path(z$source_out, 'never-created', 'nested')
  testthat::expect_error(s07r1_work(z$job, z$case, z$source_out, nested,
                            z$identity, z$recovery_identity), 'must be separate')
  testthat::expect_false(dir.exists(file.path(z$source_out, 'never-created')))
  aliased <- file.path(z$source_out, 'never-created', '..', 'also-never-created')
  testthat::expect_error(s07r1_work(z$job, z$case, z$source_out, aliased,
                            z$identity, z$recovery_identity), 'must be separate')
  testthat::expect_identical(s07r1_test_inventory(z$source_out), before_files)
})

testthat::test_that('unexpected absence and broken plans are infrastructure failures, never redraws', {
  z <- s07r1_test_source()
  out <- tempfile('s07r1-test-failure-')
  on.exit(unlink(c(z$source_out, out), recursive = TRUE), add = TRUE)
  unlink(c(z$checkpoint, paste0(z$checkpoint, '.manifest.rds')))
  source_files <- s07r1_test_inventory(z$source_out)
  testthat::expect_error(s07r1_preflight(z$source_out, list(z$job), z$identity),
                         'Unexpected missing original')
  testthat::expect_error(s07r1_work(z$job, z$case, z$source_out, out,
                         z$identity, z$recovery_identity), 'Unexpected missing original')
  testthat::expect_identical(s07r1_test_inventory(z$source_out), source_files)
  incidents <- list.files(out, recursive = TRUE, pattern = '\\.incident\\.rds$')
  testthat::expect_length(incidents, 1L)
  incident <- readRDS(file.path(out, incidents))
  testthat::expect_match(incident$classification, 'never statistical non-delivery')
  testthat::expect_length(list.files(file.path(out, 'checkpoints'),
                                   pattern = '\\.rds$', recursive = FALSE), 0L)
  plan <- z$result$plan
  plan$weights[1L, 1L] <- plan$weights[1L, 1L] + 1L
  testthat::expect_error(s07r1_validate_plan(plan, z$job), 'redraw forbidden')
  plan <- z$result$plan
  plan$streams_md5 <- 'changed'
  testthat::expect_error(s07r1_validate_plan(plan, z$job), 'redraw forbidden')
})

testthat::test_that('explicit engineering missing fixture is reconstructed from unchanged streams', {
  z <- s07r1_test_source(21L)
  out <- tempfile('s07r1-test-refit-')
  on.exit(unlink(c(z$source_out, out), recursive = TRUE), add = TRUE)
  unlink(c(z$checkpoint, paste0(z$checkpoint, '.manifest.rds')))
  source_files <- s07r1_test_inventory(z$source_out)
  catalog <- s07r1_preflight(z$source_out, list(z$job), z$identity,
                              engineering_refit_keys = s07i_key(z$job))
  testthat::expect_identical(catalog$mode, 'refit_missing')
  set.seed(958L)
  seed <- .Random.seed
  path <- s07r1_work(z$job, z$case, z$source_out, out, z$identity,
                     z$recovery_identity, engineering_refit = TRUE)
  testthat::expect_identical(.Random.seed, seed)
  result <- s07r1_checkpoint_read(path, z$recovery_identity, z$job)
  testthat::expect_identical(result$generated, z$result$generated)
  testthat::expect_identical(result$plan, z$result$plan)
  testthat::expect_identical(result$normal, z$result$normal)
  testthat::expect_identical(result$recovery$mode, 'refit_missing')
  testthat::expect_identical(result$recovery$source_checkpoint_md5, '')
  testthat::expect_identical(result$recovery$source_checkpoint, '')
  testthat::expect_identical(s07r1_test_inventory(z$source_out), source_files)
})

testthat::test_that('reserved missing-key allowance is exactly the five frozen sparse exceptions', {
  jobs <- s07i_jobs()
  permitted <- vapply(jobs, s07r1_missing_allowed, logical(1))
  testthat::expect_setequal(vapply(jobs[permitted], s07i_key, character(1)),
                             s07r1_missing_keys())
  testthat::expect_equal(sum(permitted), 5L)
  fixture <- s07i_fixture(8L, 21L)$job
  testthat::expect_false(s07r1_missing_allowed(fixture))
  testthat::expect_true(s07r1_missing_allowed(fixture, TRUE))
  fixture$dataset_id <- 998L
  testthat::expect_error(s07r1_missing_allowed(fixture, TRUE), 'exact seed781/dataset999')
})

testthat::test_that('missing sparse full engineering fixture refits exactly with preserved plan and reference', {
  grid <- Sys.getenv('S07R1_TEST_GRID', unset = '')
  if (!nzchar(grid)) grid <- file.path(s07i_paths()$execution, '..',
                                      'study07-engineering', 'S07-I1-final')
  grid <- normalizePath(grid, mustWork = TRUE)
  fixture <- s07i_fixture(8L, 21L)
  original_identity <- readRDS(file.path(grid, 'execution-identity.rds'))
  key <- s07i_key(fixture$job)
  old <- s07r1_checkpoint_read(file.path(grid, 'checkpoints', paste0(key, '.rds')),
                               original_identity, fixture$job)
  source_out <- tempfile('s07r1-missing-full-source-')
  out <- tempfile('s07r1-missing-full-output-')
  on.exit(unlink(c(source_out, out), recursive = TRUE), add = TRUE)
  # Copy only the immutable plan/reference pairs; checkpoint absence is deliberate
  # in this isolated fixture tree. No file in the archived grid is changed.
  relative <- c(file.path('draw-plans', paste0(key, '.rds')),
                file.path('population', paste0(fixture$case$case_id, '.rds')))
  relative <- c(relative, paste0(relative, '.manifest.rds'))
  for (name in relative) {
    destination <- file.path(source_out, name)
    dir.create(dirname(destination), recursive = TRUE, showWarnings = FALSE)
    stopifnot(file.copy(file.path(grid, name), destination, overwrite = FALSE))
  }
  source_files <- s07r1_test_inventory(source_out)
  recovery_identity <- list(study = 'S07-R1 sparse missing engineering fixture',
                            original_identity = original_identity)
  path <- s07r1_work(fixture$job, fixture$case, source_out, out,
                     original_identity, recovery_identity, engineering_refit = TRUE)
  result <- s07r1_checkpoint_read(path, recovery_identity, fixture$job)
  testthat::expect_identical(result$generated, old$generated)
  testthat::expect_identical(result$plan, old$plan)
  testthat::expect_identical(result$reference, old$reference)
  testthat::expect_identical(s07i_science_hash(result$full), s07i_science_hash(old$full))
  testthat::expect_identical(result$stage, old$stage)
  testthat::expect_true(all(result$mechanical_validation$status == 'passed'))
  testthat::expect_true(all(result$control_validation$status == 'passed'))
  testthat::expect_true(result$recovery$full_estimator_recomputed)
  testthat::expect_false(result$recovery$full_estimator_reused)
  testthat::expect_identical(result$recovery$mode, 'refit_missing')
  testthat::expect_identical(s07r1_test_inventory(source_out), source_files)
})

testthat::test_that('recovery resume refuses altered preserved payload despite a valid outer manifest', {
  z <- s07r1_test_source()
  out <- tempfile('s07r1-test-tampered-output-')
  on.exit(unlink(c(z$source_out, out), recursive = TRUE), add = TRUE)
  source_files <- s07r1_test_inventory(z$source_out)
  path <- s07r1_work(z$job, z$case, z$source_out, out, z$identity, z$recovery_identity)
  changed <- s07r1_checkpoint_read(path, z$recovery_identity, z$job)
  changed$generated$Y[1L, 1L] <- changed$generated$Y[1L, 1L] + 1
  unlink(c(path, paste0(path, '.manifest.rds')))
  study05_checkpoint_save(changed, path, z$recovery_identity)
  tampered_md5 <- study05_md5(path)
  testthat::expect_error(s07r1_work(z$job, z$case, z$source_out, out,
                          z$identity, z$recovery_identity), 'provenance or validation mismatch')
  testthat::expect_identical(study05_md5(path), tampered_md5)
  testthat::expect_identical(s07r1_test_inventory(z$source_out), source_files)
})
