# Study 07: full-estimator linearization and studentization diagnostics

Design S07-D1.  Status: bounded method-development specification.  No reserved
measurement panels or bootstrap weight vectors have been generated.  The plan,
seed allocator, and reference mathematical identities are implemented and tested;
the integrated generator, estimator adapter, analyses, and execution runner are
not yet implemented or frozen.  A design freeze is not an implementation freeze.

## Purpose and limits

Study 06 did not support T1 as a calibrated restriction.  Its clean strong-gap
primary coverage was 147/160 and 146/160; weak-gap accepted coverage was poor,
with severe withholding.  Study 04's two selected secondary null deficits did
not replicate under that study's frozen tests.  These different finite samples
must not be pooled or presented as a constant, established coverage deficit.

The retrospective covariance-key audit found no affected historical products
in Study 05.  All 19,680 joins and four covariance products were unchanged;
Studies 01–04 use joins without this formatting defect.  Thus a reporting
correction does not remove the statistical questions raised by Study 06.

This study separates four mechanisms: estimation of covariance; nonlinear
remainder and centering of the full estimator; finite bootstrap-quantile
variation; and selection induced by T1.  It does not propose a calibrated
replacement, optimize a screen, or change an existing package API.

Study 02 already studied population tangents and B=199/399 for non-studentized
regions.  Study 04 used opposite-half empirical covariance and frame controls.
S07 specifically adds occurrence-studentized tangent controls, model-based
fourth-moment covariance, a wider B=199/799 studentized comparison, and the
nonlinear remainder within T1 strata.  It must not claim that tangents or
unit-count diagnostics are new contributions.

## Seed reservation and separation

Use R's L'Ecuyer-CMRG / Inversion / Rejection RNG combination.  The data master
seed is 261031.  Allocate successive complete `nextRNGStream` states in case-major,
dataset-major order: the 480 full panels first, then 2,000 normal-control panels
at each of m=40,160,640.  Full case indices are 1–9; normal-control indices are
101–103.  Each bootstrap seed is 7400000 + 10000*case_index + dataset_id.
Both budgets and every estimator/control within a full panel reuse its one
prescribed draw sequence.  Engineering uses seed 781 and dataset ID 999.

The metadata allocator preserves the caller's RNG kind and complete state.
It generates no measurements or resampling weights.  The saved 6,480 complete
starting states and scalar bootstrap seeds are unique within S07 and differ
from those in all six recovered prior plans (6,440 planned panels).  This is a
check of starting-state/scalar identity, not a proof that complete RNG
trajectories cannot overlap.  Keep the exact RDS, readable CSV, and seed audit;
do not regenerate or substitute seeds in the execution implementation.

## Fixed full-estimator design

The table is authoritative together with design/case-plan.csv.  All cells use
18 fixed entities, two periods, the original 11 declared anchors, three targets
(E015 primary, E003/E006 secondary), and the S05/S06 data-generating laws.  Gaussian
noise SD is .25, temporal noise correlation .6, and contamination direction and
entity IDs remain unchanged.  Movement amplitude is the inherited .2 scale.
The m=640 cell extends only the number of iid columns in the same Gaussian law.

| Cell | g | a | m | M | Purpose |
| --- | --- | --- | --- | --- | --- |
| s07_null_g1_m40 | 1 | 0 | 40 | 80 | Regular null |
| s07_null_g1_m160 | 1 | 0 | 160 | 80 | Regular null |
| s07_null_g1_m640 | 1 | 0 | 640 | 40 | Unit-count diagnostic |
| s07_anchor_g0p1_a0p25_m40 | .1 | .25 | 40 | 60 | T1 selection |
| s07_anchor_g0p01_a0p25_m40 | .01 | .25 | 40 | 60 | T1 selection |
| s07_movement_g1_m160 | 1 | 0 | 160 | 40 | Movement |
| s07_movement_g0p01_m160 | .01 | 0 | 160 | 40 | Weak-gap movement |
| s07_sparse_m12 | inherited rare-axis law | 0 | 12 | 40 | Non-delivery sentinel |
| s07_ar1_g1_m160 | 1 | 0 | 160 | 40 | rho_unit=.5, outside iid contract |

There are 480 independent full-estimator panels.  B=199 is the primary budget
for every panel.  In the first two cells, dataset IDs 1–20 additionally receive
600 draws, giving B=799.  This subset is fixed by IDs before generation and
cannot depend on observed fit success, T1, coverage, or cutoff stability.  Generate
one ordered 799-vector plan for those panels; its first 199 are the primary
plan.  Other panels have exactly 199 draws.  No new data panel is created for a
budget comparison, and the two budget views are paired within panel.

Compute all five inherited methods in both frames: bootstrap Wald, empirical
Mahalanobis, Euclidean ball, jackknife Wald, and jackknife studentized.  The
primary endpoint remains E015/core/jackknife_studentized/theta_D.  The population
frame is a separate diagnostic.  Its successful output cannot rescue a core
failure.  Clean-anchor point fitting is retained as a separate diagnostic;
there is no clean-anchor uncertainty region.

The full estimator, occurrence jackknife, evaluation chart, tolerances, and
failure precedence remain the S06 definitions.  At B=199/799 the valid-pivot
fraction requires at least 190/760 valid planned pivots, respectively, as well
as at least 20 valid pivots.  Quantiles are type 7.  Every bootstrap and required
deletion refits the same fitting stages.  One failed required deletion invalidates
its parent covariance; later required available-parent deletions still run.

New isolated S07 orchestration is required for m=640 and B=799.  Existing S05/S06
validators reject foreign cases by design.  Never weaken those guards, monkeypatch
their settings, or overwrite their frozen sources to execute S07.  New adapters
must prove equivalence on shared cases and explicitly validate the extended
column and draw counts before an S07 implementation freeze.

## Targets, frames, and population linearization

Write X_tj for the centered entity vector for paired measurement unit j, and
K_t=E(X_tj X_tj').  The observed normalized Gram is Khat_t=sum_j X_tj X_tj'/m.
T(K_1,K_2) is the complete two-dimensional displacement functional: both leading
two-dimensional embeddings, registration of the first map to its fixed population
reference A, and temporal alignment using declared anchors.  Its value is theta_D.
Population linearization uses that fixed canonical chart.  The observed core
point must be registered to the same chart before comparison; its data-dependent
reference remains fixed as specified during its own bootstrap/deletions.

The derivative includes embedding, anchor centering, rotation/reflection and
translation, and both periods.  It is not a derivative of only the eigenscores,
and it must not divide covariance by the number of bootstrap draws.  At nonzero
movement or contamination, it differentiates at the actual paired population
Grams and actual theta_D.  Latent-stable labels cannot replace those targets.

Use the deterministic orthonormal Helmert matrix Q with 18 rows and 17 columns.
In each period form an orthonormal symmetric 17-by-17 basis: diagonal E_aa and
off-diagonal (E_ab+E_ba)/sqrt(2), ordered lexicographically by a then b>=a.  There
are 153 basis matrices per period and 306 derivative directions overall.  The
Gram perturbation for basis element E is Q E Q'.

For each target, compute central finite-difference Jacobians at steps
h=L*2^(-12), L*2^(-14), and L*2^(-16), where
L=max(1,sqrt(||K_1||_F^2+||K_2||_F^2)).  All six evaluations for every direction
are required even after another direction fails.  Steps and orientation handling
cannot adapt to results.  Each perturbed functional registers to the same A;
arbitrary raw eigenvector signs or rotations cannot enter the derivative.

For a target's Jacobian to be available: all required fits are finite; each
population boundary eigengap and declared-anchor registration satisfies the
inherited numerical identification rules; and
||J_fine-J_mid||_F/max(1,||J_fine||_F)<=1e-3.  Also require the fine-versus-mid
difference to be no more than .25 times the mid-versus-coarse difference unless
the latter is already <=1e-10*max(1,||J_fine||_F).  Retain all three matrices and
both discrepancies.  A failed convergence check yields an unavailable oracle
diagnostic, never a new step search or a failed full estimator.  No analytic
derivative may silently replace a failed finite-difference reference.

Define h_j as the 306-vector of Frobenius inner products of the paired centered
quadratic deviations with this basis.  For each target,

    psi_j = J_fine h_j
    delta_linear = theta_D + mean_j psi_j
    remainder = delta_full - delta_linear.

J is fixed by the population case, not refitted from each panel.  Bootstrap
linear draws use the same weights as the full estimator and keep J fixed.  Their
occurrence-jackknife covariance has the exact form

    S_linear(w) = sum_j w_j (psi_j-mean_w)(psi_j-mean_w)' / [m(m-1)].

The exact conditional multinomial covariance of the linear mean is the same
centered sum divided by m^2.  These two quantities differ by (m-1)/m and must not
be confused.  The linear studentized pivot uses its own S_linear(w), centered
at the observed linear mean, and the same planned-fraction, SPD, and quantile
rules as the full candidate.  It is an oracle diagnostic, not an available
confidence procedure.  It cannot pass T1 separately or replace a missing full
region.  It has its own planned/available/failed/blocked rows, including panels
where the full estimator is unavailable.

## Gaussian fourth-moment benchmark

For Gaussian cells the full paired unit vector is centered jointly Gaussian.
Let Gamma_ts=Cov(Q'X_tj,Q'X_sj), calculated directly from the frozen latent
loadings and paired noise law, including temporal cross-covariance.  For basis
matrices E_a,E_b,

    V[(t,a),(s,b)] = 2 tr(E_a Gamma_ts E_b Gamma_st)
    Omega = J_fine V J_fine'.

This is obtained by subtracting the mean product from the Gaussian fourth-moment
pairing identity.  It retains cross-period terms.  The population linear mean
covariance is Omega/m for iid units.  These identities follow the Gaussian
pairing rule in [Vignat, Theorem 1 and its fourth-moment example](https://arxiv.org/pdf/1107.2309).

Omega is a deterministic oracle reference conditional on the declared derivative
approximation, not covariance estimated from other Monte Carlo panels.  Save
Gamma, V, J, and Omega, including all numerical validity flags.  Report it only
when the relevant matrices and identification checks are available; no ridge
or silent eigenvalue replacement.  Compare its covariance and chi-square(2)
ellipses with full and linear points on paired panels.  Such ellipses are
asymptotic diagnostic benchmarks, not exact confidence sets for nonlinear
full estimates or non-Gaussian quadratic influences.

For AR(1) Gaussian units use the analytically prescribed multiplier
1+2*sum_{h=1}^{m-1}(1-h/m)*rho_unit^(2h) for the covariance of the linear mean.
Report both iid Omega/m and the dependence-aware analytic reference.  Neither
modifies resampling, m, studentization, eligibility, or the full candidate.
The AR(1) cell remains outside the iid contract regardless of T1.

The sparse non-Gaussian cell retains full computation and all failure accounting.
Its population influence may be reported if its derivative exists, but the
Gaussian fourth-moment covariance is structurally not applicable there.  Save
`not_applicable_non_gaussian` separately from a failed numeric computation.
No unimplemented rare-axis fourth-moment extension is claimed.

## Separate normal-mean control

Reserve 2,000 independent bivariate-normal mean panels at each m=40,160,640:
6,000 panels total, independent of all embedding panels.  Within each panel,
Y_j are iid N_2(0,[[1,.3],[.3,2]]); B=199 paired-unit bootstrap plans are fixed
in advance.  These control panels use no embeddings, anchors, or T1, and cannot
be pooled with embedding panels or given replicated entity/frame labels.

Compute three regions using the sample mean and S_J=sample covariance/m:
Hotelling, chi-square Wald, and occurrence-studentized bootstrap.  With p=2 the
Hotelling cutoff is p(m-1)/(m-p)*F_quantile(.95,p,m-p), equivalently
(m-1)*expm1(-2*log(.05)/(m-2)).  The normal model justifies the F reference;
the chi-square alternative is an approximation, as distinguished in the
[ICSNP authors' HotellingsT2 documentation](https://cran.r-project.org/web/packages/ICSNP/ICSNP.pdf).
ICSNP is a source reference, not a new runtime dependency.

The exact model supplies a computational/statistical benchmark.  Any numerical
SPD failure or non-delivery is retained rather than silently excluded from a
claim of exact 95% delivered coverage.  The bootstrap construction has its own
finite-unit and finite-B approximation error even in this control.  No favorable
control result certifies the embedding estimator.  Verify occurrence formulas
against physical expanded deletions in engineering fixtures and the first two
normal panels of each m, all 199 full draws.

## Analyses and denominators

Publish all planned cells, three embedding targets, five inherited methods,
both frames, and all fixed diagnostic constructions.  E015/core/studentized
comes first.  Reuse the unchanged six assumption declarations and T1 values
from observed core geometry once per panel, for every budget/frame/target view.
The known AR(1) violation is outside-contract; m=12 fails the unit screen.
All main candidates are computed for rejected and unknown panels too.

Keep original and combined-policy summaries.  For M planned, D delivered,
C covered and Z excluding zero, report D/M, C/D, C/M, Z/D and Z/M, with exact
counts, pointwise Wilson intervals and outer-panel MCSEs.  Zero denominators are
NA.  Known computational failure, unknown candidate availability, evaluation-only
block, policy withholding, and structurally inapplicable diagnostics are distinct.
Do not impute a failed fit's displacement or error by zero.

The B extension has a dedicated scope `prespecified_budget_subset` with M=20 in
each of two cells, comparing its 199/799 prefixes on exactly those same panels.
It is separate from each full M=80 primary summary.  Report all delivery
discordances, both directions of coverage discordance, paired differences and
MCSEs, and common-delivery log area and cutoff ratios.  B-independent methods
still retain explicit budget-view identity.  No choosing the better B per panel.

For full and linear observed vectors, and their paired remainder, report bias,
component/Euclidean RMSE, covariance, and cross-covariance.  On exactly the same
finite joint cohort independently verify

    Cov(full error) = Cov(linear error) + Cov(remainder)
                     + Cov(linear error,remainder)
                     + Cov(remainder,linear error).

Report the cross terms and joint n.  Never add covariance matrices estimated on
different availability or policy cohorts.  Repeat for all, eligible-pass,
eligible-fail, eligible-unknown, outside-contract, and assumptions-unknown
cohorts.  Selection changes centering and covariance; conditional associations
cannot be labeled causal mechanisms or used to fit a bias correction.

Compare each available fitted covariance with empirical error covariance on
its own matched cohort and with available Omega/m; show finite counts, trace
and generalized ratios, spectra, orientation when identified, and variability.
All ratios including trace require an SPD empirical denominator with eigenratio
>1e-8.  Outer delete-one MCSE requires n>=20 and every required diagnostic
deletion successful; otherwise preserve the ratio where defined and set MCSE
to NA, retaining failed and unattempted rows.  A derivative-level failure shared
across a case is not an independent failure in every target/view.

Retain original sparse bins 0,1,2,3,4+, every observed failure, and planned versus
full-fit versus valid-pivot selection in distinct units, maximum multiplicity,
rare multiplicity and finite bootstrap displacement from the observed point.
Errors for undefined fits remain NA.  Within-panel contrasts are summarized
across independent outer panels; draws and deletions are not independent MC
replications.  Retain uncapped finite and infinite tails in area, cutoffs and
remainder norms with their availability status.

The normal controls have their own three-method table and denominator 2,000 per
m.  They do not receive a T1 pass label.  At nominal .95, MCSE is approximately
.0049 there, .0244 for M=80, .0281 for M=60, .0345 for M=40, and .0487 for M=20
before additional delivery selection.  This is mechanism development, not a
precise release-certification study or a simultaneous testing family.

## Budget and independent implementation gates

Full pipeline: 480 panels; 95,520 primary draws plus 24,000 extension draws;
119,520 unique draw plans; 66,080 observed occurrence slots; 15,549,920 inner
occurrence slots per frame; 31,232,000 two-frame original-unit deletion-slot rows,
including zero multiplicities and blocked work.  There are 15,600 unique
target/frame/method/budget region rows.  Repeated policy views are additional
reports of those same fits.  Linear controls reuse these exact draw plans.

Normal controls: 6,000 panels; 1,194,000 draw plans; 334,320,000 represented
resampling occurrences; 18,000 region rows.  Use the tested closed occurrence
formula; do not perform hundreds of millions of separate deletion refits.
Persist unit values, exact seeds, draw-count/weight hashes, stage ledgers, and
physical-audit subsets so every prescribed count is recoverable.

There are at most 9*306*2*3=16,524 population perturbed-functional evaluations,
plus nine base evaluations, before target extraction.  Case-identical population
objects may be cached only with a verified identical population-input hash and
explicit shared-evaluation mapping; report both planned roles and actual unique
computations.  If the sparse derivative is not attempted because its population
identification fails, retain every blocked role.  The normal controls require
no population embedding evaluations.

Before execution implement and freeze: source/runtime identity guards; new case
and B adapters; full-versus-linear and fourth-moment modules; normal controls;
complete collectors and analyses; immutable checkpoints; independent audit;
and figures.  Engineering seed is 781/dataset 999, outside all reserved rows.
Use deterministic fixtures, finite-difference checks at regular/movement/weak-gap
population configurations, physical deletion agreement, exact covariance
identities, forced failures, incomplete derivatives, duplicate IDs, mixed
80/160 dataset-ID widths, corrupted checkpoints, and serial/parallel RNG tests.
No reserved data may be used to make these tests pass.

For every full cell, dataset 1 receives public PCA/classical-MDS full-fit audits
for all planned draws (including 799 where prescribed), plus physical occurrence
deletions for observed and bootstrap parents 1 and 2 in both frames.  Remaining
full deletions retain mechanical and scalar-ledger checks.  Tolerances remain
1e-9 for finite physical vector/covariance comparisons.  A blocked comparison
is never a passing numerical agreement.  Derivative/moment convergence failures
are diagnostic non-delivery unless an independent identity establishes an
implementation error; neither permits outcome-dependent parameter repair.

Every stage verifies required=attempted+unattempted-required and
attempted=successful+failed-after-attempt, separately for unique computations,
represented occurrences, and shared case diagnostics.  Keep zero-multiplicity
slots.  Missing or corrupted jobs are infrastructure incompleteness, not
statistical non-delivery.  Resume only exact original jobs, seeds, and inputs;
no successful-fit redraw.  Summaries cannot be called complete until the entire
plan and independent final audit pass.  Post-freeze engineering repairs need a
separate amendment with original evidence preserved.

## Outputs, decisions, and stopping rule

Deliver full tables, machine-readable stage/non-delivery and derivative ledgers,
all population reference matrices, seed/checkpoint catalogs, audit evidence,
and four figures: full/linear/analytic covariance and remainder; original/T1
coverage-delivery-yield with accepted/rejected centering; paired B and normal
controls; movement, dependence and sparse selection.  Exact scalar values and
cohort sizes accompany every figure; no clipping or hidden unavailable cells.

At completion classify the evidence as covariance-scale/shape, nonlinear
remainder/centering, finite-B, selection, unresolved, or a combination, using
the prespecified contrasts.  Do not rank-select a winning screen or deployable
method.  No quantitative adaptation threshold is established by this protocol.
Any proposed correction must have its own specification and later independent
validation; S07 may inform development but cannot validate that same revision.

This is the last planned mechanism study before a scope decision for v0.1:
either justify one concrete inferential-method proposal for later independent
validation, or ship the descriptive/core package with uncertainty clearly
experimental and calibrated-coverage claims deferred.  Do not automatically
schedule another calibration because some small cell remains below .95.
Cluster correspondence already exists; bootstrap cluster stability remains a
separate development task, not a capability established by these regions.
