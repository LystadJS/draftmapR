# S07-D1 metadata only: no measurement or resampling generator is implemented.
s07_settings <- function() list(design='S07-D1',data_seed=261031L,
  bootstrap_seed_base=7400000L,fixture_seed=781L,fixture_dataset=999L,
  targets=c('E015','E003','E006'),B=199L,B_extension=799L,
  extension_panels=20L,normal_M=2000L,normal_m=c(40L,160L,640L))
s07_cases <- function() {
  data.frame(case_index=1:9,case_id=c('s07_null_g1_m40','s07_null_g1_m160',
    's07_null_g1_m640','s07_anchor_g0p1_a0p25_m40','s07_anchor_g0p01_a0p25_m40',
    's07_movement_g1_m160','s07_movement_g0p01_m160','s07_sparse_m12','s07_ar1_g1_m160'),
    scenario=c(rep('gapped_gaussian',7),'rare_axis','gapped_gaussian'),
    g=c(1,1,1,.1,.01,1,.01,NA,1),a=c(0,0,0,.25,.25,0,0,0,0),
    m=c(40L,160L,640L,40L,40L,160L,160L,12L,160L),
    M=c(80L,80L,40L,60L,60L,40L,40L,40L,40L),B=199L,
    focal_motion=c(FALSE,FALSE,FALSE,FALSE,FALSE,TRUE,TRUE,TRUE,FALSE),
    rho_unit=c(rep(0,8),.5),
    role=c('regular_null','regular_null','unit_count_diagnostic','selection_stress',
      'selection_stress','movement_control','movement_control','sparse_control','dependence_control'),
    extension_n=c(20L,20L,rep(0L,7)),stringsAsFactors=FALSE)
}
s07_preserve_rng <- function(code) {
  kind<-RNGkind();had<-exists('.Random.seed',.GlobalEnv,inherits=FALSE)
  if(had)seed<-get('.Random.seed',.GlobalEnv)
  on.exit({do.call(RNGkind,as.list(kind));if(had)assign('.Random.seed',seed,.GlobalEnv)
    else if(exists('.Random.seed',.GlobalEnv,inherits=FALSE))rm('.Random.seed',envir=.GlobalEnv)},add=TRUE)
  force(code)
}
s07_jobs <- function() s07_preserve_rng({
  s<-s07_settings();cp<-s07_cases();RNGkind("L'Ecuyer-CMRG",'Inversion','Rejection');set.seed(s$data_seed)
  stream<-.Random.seed;ans<-list()
  add<-function(case_id,k,i,m,B,pipeline,extend=FALSE) {
    ans[[length(ans)+1L]]<<-list(case_id=case_id,case_index=k,dataset_id=i,m=m,
      B_planned=as.integer(B),B_primary=199L,extension=extend,pipeline=pipeline,
      data_stream=stream,bootstrap_seed=as.integer(s$bootstrap_seed_base+10000L*k+i),
      stage='reserved_method_development')
    stream<<-parallel::nextRNGStream(stream)
  }
  for(k in seq_len(nrow(cp)))for(i in seq_len(cp$M[k]))
    add(cp$case_id[k],k,i,cp$m[k],if(i<=cp$extension_n[k])s$B_extension else s$B,
      'full_estimator',i<=cp$extension_n[k])
  for(k in seq_along(s$normal_m))for(i in seq_len(s$normal_M))
    add(paste0('s07_normal_mean_m',s$normal_m[k]),100L+k,i,s$normal_m[k],s$B,'normal_mean_control')
  ans
})
s07_validate_jobs <- function(jobs) {
  expected<-s07_jobs()
  if(!identical(jobs,expected))stop('Jobs differ from the complete frozen case-major plan.')
  keys<-vapply(jobs,function(j)paste(j$case_id,as.character(j$dataset_id),sep='|'),character(1))
  states<-vapply(jobs,function(j)paste(j$data_stream,collapse=';'),character(1))
  seeds<-vapply(jobs,`[[`,integer(1),'bootstrap_seed')
  if(anyDuplicated(keys)||anyDuplicated(states)||anyDuplicated(seeds))stop('Duplicate identity or seed.')
  invisible(TRUE)
}
s07_budget <- function(jobs=s07_jobs()) {
  full<-Filter(function(j)j$pipeline=='full_estimator',jobs)
  normal<-Filter(function(j)j$pipeline=='normal_mean_control',jobs)
  sm<-function(jobs,f)sum(vapply(jobs,f,numeric(1)))
  list(full_panels=length(full),normal_control_panels=length(normal),
    full_primary_draws=length(full)*199L,full_unique_draws=sm(full,function(j)as.double(j$B_planned)),
    full_extension_draws=sm(full,function(j)as.double(j$B_planned-199L)),
    full_observed_occurrences=sm(full,function(j)as.double(j$m)),
    full_inner_occurrences=sm(full,function(j)as.double(j$m)*j$B_planned),
    full_two_frame_original_unit_deletion_slots=sm(full,function(j)2*as.double(j$m)*(j$B_planned+1)),
    full_unique_budget_region_rows=length(full)*3L*2L*5L+sum(vapply(full,`[[`,logical(1),'extension'))*3L*2L*5L,
    normal_control_draws=sm(normal,function(j)as.double(j$B_planned)),
    normal_control_draw_occurrences=sm(normal,function(j)as.double(j$m)*j$B_planned),
    normal_control_region_rows=length(normal)*3L)
}
