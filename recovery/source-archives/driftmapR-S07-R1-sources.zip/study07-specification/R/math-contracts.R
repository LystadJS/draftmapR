# Tested reference identities for the proposed diagnostics, not a study runner.
s07_linear_covariance <- function(psi,w=rep(1,nrow(psi))) {
  if(!is.matrix(psi)||ncol(psi)!=2L||any(!is.finite(psi))||length(w)!=nrow(psi)||
     any(!is.finite(w))||any(w<0|w!=floor(w))||sum(w)<3)stop('Invalid finite occurrence input.')
  m<-sum(w);center<-colSums(psi*w)/m;z<-sweep(psi,2L,center,'-')
  list(mean=center,jackknife=crossprod(z,z*w)/(m*(m-1)),
    conditional_bootstrap=crossprod(z,z*w)/m^2,m=m)
}
s07_hotelling_cutoff <- function(m,p=2L,level=.95) {
  if(length(m)!=1L||!is.finite(m)||m<=p||m!=floor(m)||p<1L||level<=0||level>=1)stop('Invalid Hotelling parameters.')
  p*(m-1)/(m-p)*stats::qf(level,p,m-p)
}
s07_centered_basis <- function(n=18L) {
  # Helmert columns provide deterministic orthonormal contrasts with no RNG.
  q<-stats::contr.helmert(n);q<-sweep(q,2L,sqrt(colSums(q^2)),'/')
  r<-n-1L;basis<-list();indices<-list()
  for(a in seq_len(r))for(b in a:r) {
    e<-matrix(0,r,r);e[a,b]<-e[b,a]<-if(a==b)1 else 1/sqrt(2)
    basis[[length(basis)+1L]]<-e;indices[[length(indices)+1L]]<-c(a,b)
  }
  list(Q=q,basis=basis,indices=do.call(rbind,indices))
}
s07_gaussian_gram_covariance <- function(gamma,basis) {
  # gamma[[t]][[s]] is Cov(Q'X_t, Q'X_s); paired periods are never separated.
  if(length(gamma)!=2L||any(lengths(gamma)!=2L)||!length(basis))stop('Invalid paired covariance blocks.')
  r<-nrow(basis[[1L]]);d<-length(basis)
  if(any(vapply(unlist(gamma,recursive=FALSE),function(x)!is.matrix(x)||!identical(dim(x),c(r,r))||any(!is.finite(x)),logical(1))))stop('Invalid covariance dimensions.')
  if(max(abs(gamma[[1]][[2]]-t(gamma[[2]][[1]])))>1e-12)stop('Cross-period covariance transpose mismatch.')
  V<-matrix(NA_real_,2L*d,2L*d)
  for(t in 1:2)for(s in 1:2)for(a in seq_len(d))for(b in seq_len(d))
    V[(t-1L)*d+a,(s-1L)*d+b]<-2*sum(diag(basis[[a]]%*%gamma[[t]][[s]]%*%basis[[b]]%*%gamma[[s]][[t]]))
  V
}
