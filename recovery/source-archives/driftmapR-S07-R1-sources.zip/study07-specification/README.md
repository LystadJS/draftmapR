# driftmapR Study 07 specification

S07-D1 is a frozen **design**, not a frozen execution implementation.  Read
PROTOCOL.md for the estimands, controls, budgets, failure accounting, and stopping
rule.  No reserved measurements or resampling weights have been generated.

Implemented here: a deterministic case/job/seed plan, RNG-preserving allocation,
budget and collision audits, reference occurrence-covariance and Gaussian-moment
identities, and design tests.  No integrated Study07 runner is provided yet.

The vendor directories preserve the exact S06-D1, S06-I1 and S06-R1 source
snapshots.  Their older status text is historical; none is rewritten to imply
that its implementation runs S07.  The reporting-key correction lives in the
separate S06-R1 snapshot and must be used for future reporting joins.

Verify the new design without executing a study:

```sh
python3 study07-specification/scripts/freeze.py verify
```

The original build-plan and test scripts are retained as evidence.  To reproduce
their results, use an isolated copy: the builder refuses a nonempty design
directory, and tests write evidence.  Do not rerun them inside a frozen source
directory.  They require the preserved R 4.5.3 runtime and jsonlite for JSON
records; they add no package runtime dependency to driftmapR.

Next: implement, validate and freeze S07-I1 against S07-D1, using engineering
fixtures only.  Then execute the untouched plan in a subsequent work session.
