# Pre-freeze engineering history

All work here precedes the S07-D1 freeze.  No reserved measurement panel,
resampling weight, fitted estimate, or coverage outcome was generated.

The first metadata-build attempt failed because historical S02/S03 job
constructors read `.Random.seed` lexically after `set.seed()` wrote it to the
global environment.  Their isolated loader initially had `baseenv()` as its
parent.  The new S07 loader now uses `.GlobalEnv` as parent within the existing
RNG-preserving wrapper.  No historical source was edited.  The failure preceded
writing the design directory.  An immediately attempted design test failed
because the missing seed-plan file had not been created.  Both failed logs are
preserved, as are the successful final build and test logs.

Final checks: 36 R design/identity assertions; 25,943 independent Python
identity/budget/corruption assertions; five isolated freeze-verifier assertions.
R verifies exact complete saved starting states, historical seed non-reuse and
caller-state preservation; Python separately verifies ordered jobs, scalar
seeds, state uniqueness/shape, and integer budgets.  These are design tests,
not execution or calibration tests.  Engineering normal values used seed 781.

The historical covariance audit is separate: 773 R and 439,563 independent
Python assertions, with no new fits or draws.  Study05's four reporting products
are bit-identical under the old and normalized join keys.

The preserved source ancestry is S06-D1, S06-I1 and S06-R1.  Their published
freeze-record SHA-256 identities are respectively:

- S06-D1 `freeze.json`: `7d2eae0aace752fb46698adb1f3388f185176106dcfc0eae65f2f9f2a15ed777`
- S06-I1 `implementation-freeze.rds`: `38f187ce3056bf26281ec12a9b372d746cf21120388b924cab4753059f24b269`
- S06-R1 `recovery-freeze.json`: `4931b45f6e00f6df4dd02137b9166cdfdc5348adfa7c156d6ddb97f2762edde6`

The human-readable S06-I1 `implementation-freeze.json` is a distinct file with
SHA-256 `2059160ab65ba3f72ff9f2c040f24cb33839bcbaf1ee074bdc2df4e2f04916d2`.

R 4.5.3 was restored from the previously saved runtime archive with SHA-256
`a61e14e5815a70cd8d70e1600e2583c10d52c0af59475773934a9843dd7caf2d`.
Archive verification and the full historical key-audit evidence are delivered
separately.  A later S07 implementation freeze must verify its own source and
runtime and all execution modules; this design freeze cannot substitute for it.
