#!/usr/bin/env python3
"""Independent integer/identity audit. Does not simulate or call R."""
import copy
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read_csv(name):
    with (ROOT/'design'/name).open(newline='') as f:
        return list(csv.DictReader(f))

def validate(rows, cases, budget):
    expected_cases = [
        ('s07_null_g1_m40',40,80,20), ('s07_null_g1_m160',160,80,20),
        ('s07_null_g1_m640',640,40,0), ('s07_anchor_g0p1_a0p25_m40',40,60,0),
        ('s07_anchor_g0p01_a0p25_m40',40,60,0), ('s07_movement_g1_m160',160,40,0),
        ('s07_movement_g0p01_m160',160,40,0), ('s07_sparse_m12',12,40,0),
        ('s07_ar1_g1_m160',160,40,0)]
    n=0
    def ck(ok, label):
        nonlocal n
        n+=1
        if not ok: raise ValueError(label)
    ck([(c['case_id'],int(c['m']),int(c['M']),int(c['extension_n'])) for c in cases]==expected_cases,
       'Case table matches independently transcribed protocol grid')
    expected=[]
    for k,(name,m,M,ext) in enumerate(expected_cases,1):
        for i in range(1,M+1): expected.append((name,k,i,m,799 if i<=ext else 199,i<=ext,'full_estimator'))
    for k,m in enumerate((40,160,640),101):
        for i in range(1,2001): expected.append((f's07_normal_mean_m{m}',k,i,m,199,False,'normal_mean_control'))
    ck(len(rows)==len(expected)==6480,'Exact number of planned jobs')
    for row,expected_row in zip(rows,expected):
        actual=(row['case_id'],int(row['case_index']),int(row['dataset_id']),int(row['m']),
                int(row['B_planned']),row['extension']=='TRUE',row['pipeline'])
        ck(actual==expected_row,'Exact ordered job identity and budget')
        ck(int(row['bootstrap_seed'])==7400000+10000*actual[1]+actual[2], 'Exact scalar seed')
        ck(row['B_primary']=='199' and row['stage']=='reserved_method_development','Primary budget and reservation status')
        state=[int(x) for x in row['data_stream'].split(';')]
        ck(len(state)==7 and state[0]==10407 and all(-2**31<=x<2**31 for x in state), 'Complete signed L Ecuyer state shape')
    for field in ('bootstrap_seed','data_stream'):
        ck(len({r[field] for r in rows})==6480,f'No duplicate {field}')
    f=rows[:480];normal=rows[480:]
    calc=dict(full_panels=len(f),normal_control_panels=len(normal),full_primary_draws=len(f)*199,
        full_unique_draws=sum(int(r['B_planned']) for r in f),
        full_extension_draws=sum(int(r['B_planned'])-199 for r in f),
        full_observed_occurrences=sum(int(r['m']) for r in f),
        full_inner_occurrences=sum(int(r['m'])*int(r['B_planned']) for r in f),
        full_two_frame_original_unit_deletion_slots=sum(2*int(r['m'])*(int(r['B_planned'])+1) for r in f),
        full_unique_budget_region_rows=(len(f)+sum(r['extension']=='TRUE' for r in f))*3*2*5,
        normal_control_draws=sum(int(r['B_planned']) for r in normal),
        normal_control_draw_occurrences=sum(int(r['m'])*int(r['B_planned']) for r in normal),
        normal_control_region_rows=len(normal)*3)
    ck(set(calc)==set(budget),'Complete budget fields')
    for key,value in calc.items(): ck(value==budget[key],f'Independent budget {key}')
    return n

def main():
    if (ROOT/'FREEZE.json').exists(): raise RuntimeError('Frozen evidence is immutable.')
    rows=read_csv('seed-plan.csv');cases=read_csv('case-plan.csv')
    budget=json.loads((ROOT/'design/budgets.json').read_text())
    n=validate(rows,cases,budget)
    rejected=[]
    for label in ('missing job','duplicate job','changed seed','changed B','swapped job order','duplicate state'):
        bad=copy.deepcopy(rows)
        if label=='missing job': bad.pop()
        if label=='duplicate job': bad[1]=bad[0]
        if label=='changed seed': bad[0]['bootstrap_seed']='1'
        if label=='changed B': bad[0]['B_planned']='199'
        if label=='swapped job order': bad[0],bad[1]=bad[1],bad[0]
        if label=='duplicate state': bad[1]['data_stream']=bad[0]['data_stream']
        try: validate(bad,cases,budget)
        except ValueError: rejected.append(label)
        else: raise AssertionError(f'Undetected corruption: {label}')
    result=dict(status='passed',assertions=n+len(rejected),injected_errors_rejected=rejected,
        scope='Independent CSV job identities, scalar seeds, state uniqueness/shape, and integer budgets; R separately verifies exact saved RNG states and historical non-reuse.',
        reserved_measurement_panels_generated=0,reserved_bootstrap_weight_vectors_generated=0)
    (ROOT/'evidence/independent-design-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
