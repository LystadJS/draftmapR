#!/usr/bin/env Rscript
root<-normalizePath('study07-specification',mustWork=TRUE)
if(file.exists(file.path(root,'FREEZE.json')))stop('Frozen design is immutable.')
out<-file.path(root,'design')
if(dir.exists(out)&&length(list.files(out,all.files=TRUE,no..=TRUE)))stop('Refusing to overwrite a plan.')
source(file.path(root,'R/design.R'))
had<-exists('.Random.seed',.GlobalEnv,inherits=FALSE);old<-if(had)get('.Random.seed',.GlobalEnv)else NULL;kind<-RNGkind()
jobs<-s07_jobs();s07_validate_jobs(jobs)
prior<-s07_preserve_rng({
  # Historical metadata constructors use the global RNG state after set.seed().
  # The surrounding s07_preserve_rng() restores that state after allocation.
  e<-new.env(parent=.GlobalEnv);base<-file.path(root,'vendor/study06-specification/vendor/driftmapR/data-raw')
  for(s in 1:4)sys.source(file.path(base,sprintf('calibration-%02d/model.R',s)),e)
  RNGkind("L'Ecuyer-CMRG",'Inversion','Rejection');set.seed(260915L);stream<-.Random.seed;one<-list()
  for(s in seq_len(nrow(e$calibration_scenarios())))for(i in 1:80){
    one[[length(one)+1L]]<-list(data_stream=stream,bootstrap_seed=as.integer(1400000L+s*1000L+i))
    stream<-parallel::nextRNGStream(stream)
  }
  list(study01=one,study02=e$study02_jobs(),study03=e$study03_jobs(),study04=e$study04_jobs(),
    study05=readRDS(file.path(base,'calibration-05/design/seed-plan.rds')),
    study06=readRDS(file.path(root,'vendor/study06-specification/design/seed-plan.rds')))
})
stopifnot(identical(as.integer(lengths(prior)),c(480L,960L,800L,1120L,1640L,1440L)))
states<-function(j)vapply(j,function(x)paste(x$data_stream,collapse=';'),character(1))
seeds<-function(j)vapply(j,function(x)as.integer(x$bootstrap_seed),integer(1))
past<-unlist(prior,recursive=FALSE)
stopifnot(!any(states(jobs)%in%states(past)),!any(seeds(jobs)%in%seeds(past)),
  !any(seeds(jobs)%in%c(777L,778L,779L,780L,781L)))
stopifnot(identical(kind,RNGkind()),identical(had,exists('.Random.seed',.GlobalEnv,inherits=FALSE)),
  !had||identical(old,get('.Random.seed',.GlobalEnv)))
dir.create(out,showWarnings=FALSE)
utils::write.csv(s07_cases(),file.path(out,'case-plan.csv'),row.names=FALSE,na='')
saveRDS(jobs,file.path(out,'seed-plan.rds'),compress='gzip')
flat<-do.call(rbind,lapply(jobs,function(j){j$data_stream<-paste(j$data_stream,collapse=';');as.data.frame(j,stringsAsFactors=FALSE)}))
utils::write.csv(flat,file.path(out,'seed-plan.csv'),row.names=FALSE)
jsonlite::write_json(s07_budget(jobs),file.path(out,'budgets.json'),pretty=TRUE,auto_unbox=TRUE)
jsonlite::write_json(list(status='passed',prior_planned_panels=as.list(lengths(prior)),new_full_panels=480L,
  new_normal_control_panels=6000L,new_unique_streams=length(jobs),new_unique_bootstrap_seeds=length(jobs),
  reused_prior_start_states=0L,reused_prior_bootstrap_seeds=0L,caller_rng_preserved=TRUE,
  reserved_measurement_panels_generated=0L,reserved_bootstrap_weight_vectors_generated=0L,
  claim='No reused complete starting state or scalar bootstrap seed against the six recovered plans; not a proof of non-overlap of complete RNG trajectories.'),
  file.path(out,'seed-audit.json'),pretty=TRUE,auto_unbox=TRUE)
cat('S07-D1 metadata reserved; no measurements or resampling weights generated.\n')
print(s07_budget(jobs))
