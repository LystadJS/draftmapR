#!/usr/bin/env python3
"""Freeze/verify exact S07-D1 bytes; never execute a reserved study job."""
import argparse
import datetime
import hashlib
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCK = 'FREEZE.json'

def inventory(root):
    rows=[]
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): raise ValueError(f'Symlink is not allowed: {p}')
        if not p.is_file() or p==root/LOCK: continue
        data=p.read_bytes()
        rows.append(dict(path=p.relative_to(root).as_posix(),size_bytes=len(data),
                         sha256=hashlib.sha256(data).hexdigest(),md5=hashlib.md5(data).hexdigest()))
    return rows

def verify(root, record):
    if record['design']!='S07-D1' or record['status']!='design_frozen': raise ValueError('Wrong freeze identity')
    if inventory(root)!=record['files']: raise ValueError('Missing, extra, or changed frozen file')
    return len(record['files'])

def selftest():
    if (ROOT/LOCK).exists(): raise RuntimeError('Frozen evidence is immutable.')
    n=0
    with tempfile.TemporaryDirectory(prefix='s07-freeze-test-') as d:
        p=Path(d);(p/'a').write_text('one');(p/'b').write_text('two')
        record=dict(design='S07-D1',status='design_frozen',files=inventory(p))
        assert verify(p,record)==2;n+=1
        for mutation in ('modified','missing','extra'):
            if mutation=='modified': (p/'a').write_text('changed')
            if mutation=='missing': (p/'a').unlink()
            if mutation=='extra': (p/'c').write_text('extra')
            try: verify(p,record)
            except ValueError: n+=1
            else: raise AssertionError(mutation)
            (p/'a').write_text('one')
            if (p/'c').exists(): (p/'c').unlink()
        assert verify(p,record)==2;n+=1
    result=dict(status='passed',assertions=n,corruption_controls=['modified','missing','extra'],scope='Temporary fixture only')
    (ROOT/'evidence/freeze-tests.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

def freeze():
    if (ROOT/LOCK).exists(): raise FileExistsError('Refusing to replace an existing freeze')
    evidence={}
    for name in ('design-tests','independent-design-audit','freeze-tests','vendor-verification'):
        evidence[name]=json.loads((ROOT/f'evidence/{name}.json').read_text())
        if evidence[name]['status']!='passed': raise ValueError('Unpassed design gate')
    seed=json.loads((ROOT/'design/seed-audit.json').read_text())
    if seed['status']!='passed' or seed['reserved_measurement_panels_generated']!=0 or seed['reserved_bootstrap_weight_vectors_generated']!=0:
        raise ValueError('Seed reservation gate failed')
    record=dict(design='S07-D1',status='design_frozen',
        frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        implementation_status='not_implemented_or_frozen',execution_status='not_started',
        reserved_measurement_panels_generated=0,reserved_bootstrap_weight_vectors_generated=0,
        budgets=json.loads((ROOT/'design/budgets.json').read_text()),seed_audit=seed,
        evidence=evidence,files=inventory(ROOT))
    with (ROOT/LOCK).open('x') as f: json.dump(record,f,indent=2);f.write('\n')
    print(json.dumps(dict(status='passed',action='frozen',files=verify(ROOT,record),
        freeze_sha256=hashlib.sha256((ROOT/LOCK).read_bytes()).hexdigest())))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('selftest','freeze','verify'));args=parser.parse_args()
    if args.action=='selftest': selftest()
    elif args.action=='freeze': freeze()
    else:
        record=json.loads((ROOT/LOCK).read_text())
        print(json.dumps(dict(status='passed',action='verified',files=verify(ROOT,record),
            freeze_sha256=hashlib.sha256((ROOT/LOCK).read_bytes()).hexdigest())))
