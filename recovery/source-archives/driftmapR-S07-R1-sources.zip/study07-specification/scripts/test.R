#!/usr/bin/env Rscript
root<-normalizePath('study07-specification',mustWork=TRUE)
if(file.exists(file.path(root,'FREEZE.json')))stop('Frozen evidence is immutable; use an isolated engineering copy.')
source(file.path(root,'R/design.R'));source(file.path(root,'R/math-contracts.R'))
checks<-list();ck<-function(ok,label){checks[[length(checks)+1L]]<<-data.frame(check=label,passed=isTRUE(ok));if(!isTRUE(ok))stop(label)}
jobs<-readRDS(file.path(root,'design/seed-plan.rds'));ck(identical(jobs,s07_jobs()),'Saved metadata equals exact complete plan')
b<-s07_budget(jobs)
expected<-c(full_panels=480,normal_control_panels=6000,full_primary_draws=95520,
  full_unique_draws=119520,full_extension_draws=24000,full_observed_occurrences=66080,
  full_inner_occurrences=15549920,full_two_frame_original_unit_deletion_slots=31232000,
  full_unique_budget_region_rows=15600,normal_control_draws=1194000,
  normal_control_draw_occurrences=334320000,normal_control_region_rows=18000)
for(k in names(expected))ck(identical(as.numeric(b[[k]]),expected[[k]]),paste('Exact bounded budget',k))
for(which in c('missing','duplicate','changed_seed','changed_budget')){
  bad<-jobs
  if(which=='missing')bad<-bad[-1L]
  if(which=='duplicate')bad[[2]]<-bad[[1]]
  if(which=='changed_seed')bad[[1]]$bootstrap_seed<-bad[[1]]$bootstrap_seed+1L
  if(which=='changed_budget')bad[[1]]$B_planned<-199L
  ck(tryCatch({s07_validate_jobs(bad);FALSE},error=function(e)TRUE),paste('Invalid plan rejected',which))
}
beforekind<-RNGkind();beforehad<-exists('.Random.seed',.GlobalEnv,inherits=FALSE)
if(beforehad)beforeseed<-get('.Random.seed',.GlobalEnv)
s07_preserve_rng({RNGkind("L'Ecuyer-CMRG",'Inversion','Rejection');set.seed(781L)
  psi<-matrix(stats::rnorm(24),12,2);w<-c(3,0,1,2,0,1,1,2,0,0,1,1)
  z<-s07_linear_covariance(psi,w);expanded<-psi[rep(seq_len(nrow(psi)),w),,drop=FALSE];m<-nrow(expanded)
  dels<-t(vapply(seq_len(m),function(j)colMeans(expanded[-j,,drop=FALSE]),numeric(2)))
  physical<-(m-1)/m*crossprod(sweep(dels,2,colMeans(dels),'-'))
  ck(max(abs(z$jackknife-physical))<1e-12,'Occurrence formula equals every physical deletion')
  ck(max(abs(z$jackknife-stats::cov(expanded)/m))<1e-12,'Occurrence formula equals covariance of sample mean')
  ck(max(abs(z$conditional_bootstrap-z$jackknife*(m-1)/m))<1e-12,'Exact conditional multinomial factor retained')
  ck(max(abs(z$mean-colMeans(expanded)))<1e-12,'Weighted and expanded centers agree')
})
ck(identical(RNGkind(),beforekind)&&identical(exists('.Random.seed',.GlobalEnv,inherits=FALSE),beforehad)&&(!beforehad||identical(beforeseed,get('.Random.seed',.GlobalEnv))),'Engineering fixture preserves caller RNG')
for(m in c(40L,160L,640L)){
  ck(abs(s07_hotelling_cutoff(m)-(m-1)*expm1(-2*log(.05)/(m-2)))<1e-12,paste('p2 F quantile matches closed inverse survival',m))
  ck(abs(s07_hotelling_cutoff(m,1L)-stats::qt(.975,m-1)^2)<1e-12,paste('p1 agrees with Student t squared',m))
}
q<-s07_centered_basis()
ck(max(abs(colSums(q$Q)))<1e-12 && max(abs(crossprod(q$Q)-diag(17)))<1e-12,'Centered contrasts are orthonormal')
ck(length(q$basis)==153L && nrow(q$indices)==153L,'Complete centered symmetric Gram basis')
G<-vapply(q$basis,as.vector,numeric(289));ck(max(abs(crossprod(G)-diag(153)))<1e-12,'Symmetric basis is orthonormal in Frobenius norm')
small<-s07_centered_basis(3)$basis
g<-list(list(diag(c(2,3)),diag(c(.4,.5))),list(diag(c(.4,.5)),diag(c(5,7))))
V<-s07_gaussian_gram_covariance(g,small)
ck(max(abs(V-t(V)))<1e-12,'Paired Gaussian fourth-moment covariance symmetric')
ck(max(abs(diag(V)-c(8,12,18,50,70,98)))<1e-12,'Diagonal and sqrt2 off-diagonal moments agree with scalar formulas')
ck(abs(V[1,4]-2*.4^2)<1e-12 && abs(V[2,5]-2*.4*.5)<1e-12,'Cross-period fourth moments retained')
ck(min(eigen(V,symmetric=TRUE,only.values=TRUE)$values)>0,'Valid paired Gaussian example is SPD')
bad<-g;bad[[2]][[1]][1,1]<-.3
ck(tryCatch({s07_gaussian_gram_covariance(bad,small);FALSE},error=function(e)TRUE),'Mismatched cross-period covariance rejected')
utils::write.csv(do.call(rbind,checks),file.path(root,'evidence/design-tests.csv'),row.names=FALSE)
jsonlite::write_json(list(status='passed',assertions=length(checks),scope='Design, seed guards, exact budgets, deterministic moment identities and engineering-only scalar fixtures; no full runner or reserved evaluation exists.'),file.path(root,'evidence/design-tests.json'),auto_unbox=TRUE,pretty=TRUE)
cat(length(checks),'design/identity assertions passed.\n')
