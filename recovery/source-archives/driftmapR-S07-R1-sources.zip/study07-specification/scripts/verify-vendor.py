#!/usr/bin/env python3
"""Verify the three inherited freeze records without loading executable code."""
from pathlib import Path
import hashlib
import json

root=Path(__file__).resolve().parents[1]
if (root/'FREEZE.json').exists(): raise RuntimeError('Frozen evidence is immutable.')
base=root/'vendor';counts={}
identities={
 'study06-specification/freeze.json':'7d2eae0aace752fb46698adb1f3388f185176106dcfc0eae65f2f9f2a15ed777',
 'study06-execution/implementation-freeze.rds':'38f187ce3056bf26281ec12a9b372d746cf21120388b924cab4753059f24b269',
 'study06-execution/implementation-freeze.json':'2059160ab65ba3f72ff9f2c040f24cb33839bcbaf1ee074bdc2df4e2f04916d2',
 'study06-reporting-recovery/recovery-freeze.json':'4931b45f6e00f6df4dd02137b9166cdfdc5348adfa7c156d6ddb97f2762edde6'}
for p,h in identities.items():
    assert hashlib.sha256((base/p).read_bytes()).hexdigest()==h,p
d=json.loads((base/'study06-specification/freeze.json').read_text())
for p,r in d['files'].items():
    b=(base/'study06-specification'/p).read_bytes()
    assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],p
counts['S06_D1_SHA256_files']=len(d['files'])
i=json.loads((base/'study06-execution/implementation-freeze.json').read_text())
assert len(i['files'])==len(i['md5'])
for p,h in zip(i['files'],i['md5']):
    assert hashlib.md5((base/'study06-execution'/p).read_bytes()).hexdigest()==h,p
counts['S06_I1_MD5_files']=len(i['files'])
r=json.loads((base/'study06-reporting-recovery/recovery-freeze.json').read_text())
for item in r['source_files']:
    b=(base/item['path']).read_bytes()
    assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'],item['path']
counts['S06_R1_SHA256_files']=len(r['source_files'])
result=dict(status='passed',freeze_identities=identities,manifest_files_verified=counts,
    scope='All inherited source manifests and four exact freeze-record files; historical reserved outputs are audited separately.')
(root/'evidence/vendor-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
