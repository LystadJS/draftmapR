# S07-R1 continuation controls 006

The previous execution session ended during validation. Its last running status was stale; both operational locks were free. No foreign PID was signalled. The verified collection boundary remains 276/6,480 panels through chunk 163092.

The new operational driver reuses the exact saved original-input preflight only after the unchanged frozen catalog checker verifies every original file and the source-binding SHA-256 matches the recovered checkpoint. All 6,480 saved preflight rows are checked against job identities and catalog hashes, including the five historical missing-source cases. Tampered binding rejection passed.

Original/recovered draw-plan equality, population-reference equality, and recovered checkpoint validation still run unchanged. Each completed job now records a durable validation cache bound to job, both frozen identities, driver hash, and every payload/sidecar checksum. Changed cached inputs fail closed. This prevents an interruption from discarding completed validation work.

The tested revision 005 collector, compressor routing, scientific methods, runtime, seeds, checkpoints, and final audits remain unchanged. A single owned launcher sequences collection/audits and, only after successful termination, the prepared preservation pipeline. No scientific completion or findings are claimed.

Progress: collection 276/6,480 (4.3%). The complete planned grid remains required. This archive contains new controls and review evidence; Launch-005 and Restart-004 retain its verified dependencies.
