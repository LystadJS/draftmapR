from pathlib import Path
O=Path(__file__).resolve().parent.parent
s=(O/'resume-collection-prefix-005.R').read_text().replace("'driver-binding-005.rds'","'driver-binding-006.rds'")
a='  preflight <- s07r1_preflight(source_out, jobs, ancestor)'
b='''  # Reuse only the exact restored preflight, after the complete original catalog
  # has just passed its frozen grid/size/MD5 verification above.
  source_binding_path <- file.path(out, 'source-binding.rds')
  if (s07ops_sha(source_binding_path) != '6e345a02b8fd2660205ea22ed4dbc69b1c65b3d599361842e7d215a6a3ba0d7c') stop('Saved source preflight binding changed.')
  saved_source <- readRDS(source_binding_path)
  if (!identical(saved_source$source_out, source_out) || !identical(saved_source$original_identity, ancestor)) stop('Saved preflight context changed.')
  preflight <- saved_source$preflight
  catalog <- read.csv(file.path(root, 'study07-recovery/evidence/original-checkpoint-catalog.csv'), stringsAsFactors=FALSE)
  if (s07ops_sha(file.path(root, 'study07-recovery/evidence/original-checkpoint-catalog.csv')) != '64e7b5d059ef95141e1784c39038b46540f59d7c647a3308dc8c10bf3c70960f') stop('Original frozen catalog identity changed.')
  if (nrow(preflight) != length(jobs) || !identical(preflight$case_id, vapply(jobs, `[[`, character(1), 'case_id')) ||
      !identical(as.integer(preflight$dataset_id), vapply(jobs, `[[`, integer(1), 'dataset_id')) ||
      !identical(as.integer(preflight$B), vapply(jobs, `[[`, integer(1), 'B_planned')) ||
      !identical(as.integer(preflight$m), vapply(jobs, `[[`, integer(1), 'm'))) stop('Saved preflight grid differs.')
  for (k in seq_along(jobs)) {
    key <- s07i_key(jobs[[k]]); cr <- preflight[k,]
    if (cr$source_checkpoint != file.path('checkpoints',paste0(key,'.rds'))) stop('Saved preflight checkpoint path differs.')
    ci <- match(cr$source_checkpoint,catalog$path)
    if (cr$mode=='refit_missing') {
      if (!key %in% s07r1_missing_keys() || !is.na(ci) || !is.na(cr$source_checkpoint_md5)) stop('Saved missing-source contract differs.')
    } else if (cr$mode!='migrate_verified' || is.na(ci) || cr$source_checkpoint_md5!=catalog$md5[ci]) stop('Saved source checkpoint hash differs.')
    pi <- match(file.path('draw-plans',paste0(key,'.rds')),catalog$path)
    if (is.na(pi) || cr$plan_md5!=catalog$md5[pi]) stop('Saved source plan hash differs.')
    if (jobs[[k]]$pipeline=='full_estimator') {
      ri <- match(file.path('population',paste0(jobs[[k]]$case_id,'.rds')),catalog$path)
      if (is.na(ri) || cr$reference_md5!=catalog$md5[ri]) stop('Saved source reference hash differs.')
    }
  }
  write_status('ORIGINAL_INPUTS_AND_SAVED_PREFLIGHT_VERIFIED')'''
assert s.count(a)==1;s=s.replace(a,b)
a='  seen_references <- character()';b="  seen_references <- character()\n  verification_dir <- file.path(state_dir,'verification-006');dir.create(verification_dir,showWarnings=FALSE)"
s=s.replace(a,b)
a="    plan_name <- file.path('draw-plans', paste0(s07i_key(job), '.rds'))"
b=a+'''
    vf <- c(file.path(source_out,plan_name),file.path(out,plan_name),paths[i])
    if (job$pipeline=='full_estimator') vf <- c(vf,file.path(source_out,'population',paste0(job$case_id,'.rds')),file.path(out,'population',paste0(job$case_id,'.rds')))
    vf <- c(vf,paste0(vf,'.manifest.rds'))
    validation_bound <- list(job=job,identity=identity,ancestor=ancestor,files=vf,md5=s07ops_md5(vf),driver_sha256=driver_sha)
    if (anyNA(validation_bound$md5)) stop('Missing input in validation cache binding.')
    validation_path <- file.path(verification_dir,paste0(s07i_key(job),'.rds'))
    if (file.exists(validation_path)) {
      if (!identical(readRDS(validation_path),validation_bound)) stop('Previously verified input changed.')
      if (i %% 100L==0L) write_status('VERIFYING_RECOVERED_INPUTS',verified_jobs=i,total_jobs=length(jobs),cached=TRUE)
      next
    }'''
s=s.replace(a,b)
a="    if (!isTRUE(r$recovery$controls_recomputed) || !all(r$control_validation$status == 'passed')) stop('Recovered checkpoint validation failed.')"
b=a+"\n    s07ops_save(validation_bound,validation_path)\n    if (i %% 100L==0L || i==length(jobs)) write_status('VERIFYING_RECOVERED_INPUTS',verified_jobs=i,total_jobs=length(jobs),cached=FALSE)"
s=s.replace(a,b)
(O/'resume-collection-prefix-006.R').write_text(s)
print('Driver 006 generated; frozen scientific files unchanged')
