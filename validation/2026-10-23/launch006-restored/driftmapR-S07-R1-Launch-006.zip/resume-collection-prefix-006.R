# Resume deterministic serialization of existing S07-R1 checkpoints. No generator,
# fit, recovery-work, or draw-construction function is called by this driver.
args <- commandArgs(TRUE)
if (length(args) != 8L || args[1] != 'reserved')
  stop('Usage: resume-collection.R reserved ORIGINAL_OUT RECOVERY_OUT STATE_DIR CHUNK_DIR PUBLICATION_INDEX METADATA_ROOT REVIEW_GATE')
script <- normalizePath(sub('^--file=', '', commandArgs(FALSE)[grepl('^--file=', commandArgs(FALSE))][1]))
ops <- dirname(script); root <- normalizePath(file.path(ops, '..'))
source(file.path(root, 'study07-recovery/R/load.R')); s07r1_load(file.path(root, 'study07-recovery'))
source(file.path(ops, 'resumable-collect-prefix-005.R'))
source_out <- normalizePath(args[2]); out <- normalizePath(args[3])
state_dir <- normalizePath(args[4], mustWork = FALSE)
chunk_dir <- normalizePath(args[5]); publication_index <- normalizePath(args[6]); metadata_root <- normalizePath(args[7])
review_path <- normalizePath(args[8])
dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
status_path <- file.path(state_dir, 'driver-status.json')
write_status <- function(stage, ...) {
  value <- c(list(stage = stage, adapter = 'external_operational_serialization_resume',
    scientific_completion_claimed = stage == 'COMPLETE', time_utc = study05_utc()), list(...))
  temp <- tempfile('.status-', tmpdir = state_dir)
  s07i_json(value, temp); s07ops_worker(temp)
  if (!file.rename(temp, status_path)) stop('Cannot commit operational driver status.')
  s07ops_worker(c(status_path, state_dir)); cat(stage, '\n'); flush.console()
}
inventory <- function(directory) {
  names <- sort(list.files(directory, recursive = TRUE, all.files = TRUE, no.. = TRUE))
  paths <- file.path(directory, names); keep <- !file.info(paths)$isdir
  data.frame(path = names[keep], bytes = unname(file.info(paths[keep])$size), md5 = s07ops_md5(paths[keep]), stringsAsFactors = FALSE)
}
verify_inventory <- function(directory, catalog) {
  if (!identical(inventory(directory), catalog)) stop('Completed operational stage product bytes changed: ', directory)
}

main <- function() {
  guard <- s07ops_guard()
  adapter <- file.path(ops, 'resumable-collect-prefix-005.R')
  adapter_sha <- s07ops_sha(adapter); driver_sha <- s07ops_sha(script)
  review <- jsonlite::read_json(review_path, simplifyVector = FALSE)
  if (!identical(review$status, 'passed') || !identical(review$adapter_sha256, adapter_sha) ||
      !identical(review$driver_sha256, driver_sha) || !isTRUE(review$reserved_launch_authorized))
    stop('Independent passing review bound to exact adapter and driver bytes is required.')
  write_status('VERIFYING_FROZEN_SOURCES_AND_EXISTING_GRID')
  ancestor <- s07i_verify_implementation(); identity <- s07r1_identity(FALSE); jobs <- s07i_jobs()
  if (length(jobs) != 6480L || sum(vapply(jobs, `[[`, integer(1), 'B_planned')) != 1313520L)
    stop('Changed frozen job/draw grid.')
  if (!identical(readRDS(file.path(out, 'execution-identity.rds')), identity) ||
      !identical(readRDS(file.path(out, 'seed-plan.rds')), jobs)) stop('Recovered execution identity or seed plan differs.')
  s07r1_catalog_check(source_out)
  # Reuse only the exact restored preflight, after the complete original catalog
  # has just passed its frozen grid/size/MD5 verification above.
  source_binding_path <- file.path(out, 'source-binding.rds')
  if (s07ops_sha(source_binding_path) != '6e345a02b8fd2660205ea22ed4dbc69b1c65b3d599361842e7d215a6a3ba0d7c') stop('Saved source preflight binding changed.')
  saved_source <- readRDS(source_binding_path)
  if (!identical(saved_source$source_out, source_out) || !identical(saved_source$original_identity, ancestor)) stop('Saved preflight context changed.')
  preflight <- saved_source$preflight
  catalog <- read.csv(file.path(root, 'study07-recovery/evidence/original-checkpoint-catalog.csv'), stringsAsFactors=FALSE)
  if (s07ops_sha(file.path(root, 'study07-recovery/evidence/original-checkpoint-catalog.csv')) != '64e7b5d059ef95141e1784c39038b46540f59d7c647a3308dc8c10bf3c70960f') stop('Original frozen catalog identity changed.')
  if (nrow(preflight) != length(jobs) || !identical(preflight$case_id, vapply(jobs, `[[`, character(1), 'case_id')) ||
      !identical(as.integer(preflight$dataset_id), vapply(jobs, `[[`, integer(1), 'dataset_id')) ||
      !identical(as.integer(preflight$B), vapply(jobs, `[[`, integer(1), 'B_planned')) ||
      !identical(as.integer(preflight$m), vapply(jobs, `[[`, integer(1), 'm'))) stop('Saved preflight grid differs.')
  for (k in seq_along(jobs)) {
    key <- s07i_key(jobs[[k]]); cr <- preflight[k,]
    if (cr$source_checkpoint != file.path('checkpoints',paste0(key,'.rds'))) stop('Saved preflight checkpoint path differs.')
    ci <- match(cr$source_checkpoint,catalog$path)
    if (cr$mode=='refit_missing') {
      if (!key %in% s07r1_missing_keys() || !is.na(ci) || !is.na(cr$source_checkpoint_md5)) stop('Saved missing-source contract differs.')
    } else if (cr$mode!='migrate_verified' || is.na(ci) || cr$source_checkpoint_md5!=catalog$md5[ci]) stop('Saved source checkpoint hash differs.')
    pi <- match(file.path('draw-plans',paste0(key,'.rds')),catalog$path)
    if (is.na(pi) || cr$plan_md5!=catalog$md5[pi]) stop('Saved source plan hash differs.')
    if (jobs[[k]]$pipeline=='full_estimator') {
      ri <- match(file.path('population',paste0(jobs[[k]]$case_id,'.rds')),catalog$path)
      if (is.na(ri) || cr$reference_md5!=catalog$md5[ri]) stop('Saved source reference hash differs.')
    }
  }
  write_status('ORIGINAL_INPUTS_AND_SAVED_PREFLIGHT_VERIFIED')
  expected_binding <- list(source_out = source_out, original_identity = ancestor, preflight = preflight)
  if (!identical(readRDS(file.path(out, 'source-binding.rds')), expected_binding)) stop('Original source provenance binding differs.')
  paths <- file.path(out, 'checkpoints', paste0(vapply(jobs, s07i_key, character(1)), '.rds'))
  seen_references <- character()
  verification_dir <- file.path(state_dir,'verification-006');dir.create(verification_dir,showWarnings=FALSE)
  for (i in seq_along(jobs)) {
    job <- jobs[[i]]
    plan_name <- file.path('draw-plans', paste0(s07i_key(job), '.rds'))
    vf <- c(file.path(source_out,plan_name),file.path(out,plan_name),paths[i])
    if (job$pipeline=='full_estimator') vf <- c(vf,file.path(source_out,'population',paste0(job$case_id,'.rds')),file.path(out,'population',paste0(job$case_id,'.rds')))
    vf <- c(vf,paste0(vf,'.manifest.rds'))
    validation_bound <- list(job=job,identity=identity,ancestor=ancestor,files=vf,md5=s07ops_md5(vf),driver_sha256=driver_sha)
    if (anyNA(validation_bound$md5)) stop('Missing input in validation cache binding.')
    validation_path <- file.path(verification_dir,paste0(s07i_key(job),'.rds'))
    if (file.exists(validation_path)) {
      if (!identical(readRDS(validation_path),validation_bound)) stop('Previously verified input changed.')
      if (i %% 100L==0L) write_status('VERIFYING_RECOVERED_INPUTS',verified_jobs=i,total_jobs=length(jobs),cached=TRUE)
      next
    }
    original_plan <- s07r1_checkpoint_read(file.path(source_out, plan_name), ancestor, job)
    recovered_plan <- s07r1_checkpoint_read(file.path(out, plan_name), identity, job)
    if (!identical(original_plan, recovered_plan)) stop('Recovered draw plan differs from retained original; no replacement is permitted.')
    if (job$pipeline == 'full_estimator' && !job$case_id %in% seen_references) {
      reference_job <- s07i_refjob(s07i_reference_case(s07i_case(job)))
      reference_name <- file.path('population', paste0(job$case_id, '.rds'))
      original_reference <- s07r1_checkpoint_read(file.path(source_out, reference_name), ancestor, reference_job)
      recovered_reference <- s07r1_checkpoint_read(file.path(out, reference_name), identity, reference_job)
      if (!identical(original_reference, recovered_reference)) stop('Recovered population reference differs from retained original.')
      seen_references <- c(seen_references, job$case_id)
    }
    r <- s07r1_checkpoint_read(paths[i], identity, jobs[[i]])
    if (!isTRUE(r$recovery$controls_recomputed) || !all(r$control_validation$status == 'passed')) stop('Recovered checkpoint validation failed.')
    s07ops_save(validation_bound,validation_path)
    if (i %% 100L==0L || i==length(jobs)) write_status('VERIFYING_RECOVERED_INPUTS',verified_jobs=i,total_jobs=length(jobs),cached=FALSE)
  }
  if (!file.exists(file.path(out, 'recovery-provenance.json'))) stop('Prior recovery provenance is missing; do not invent it.')
  # Every reuse catalog is authenticated against its durable publication receipt.
  published <- jsonlite::read_json(publication_index, simplifyVector = FALSE)
  catalogs <- character(); expected <- list()
  for (increment in published$increments) if (startsWith(increment$tag, 'r1-final-raw')) {
    for (artifact in increment$artifacts) if (endsWith(artifact$filename, '-products-catalog.csv')) {
      if (basename(artifact$filename) != artifact$filename || basename(increment$tag) != increment$tag) stop('Unsafe publication identity.')
      p <- normalizePath(file.path(metadata_root, increment$tag, artifact$filename), mustWork = TRUE)
      if (file.info(p)$size != artifact$bytes || s07ops_sha(p) != artifact$sha256) stop('Published catalog artifact identity differs.')
      catalogs <- c(catalogs, p); expected[[p]] <- artifact$sha256
    }
  }
  binding_path <- file.path(state_dir, 'binding.rds')
  if (file.exists(binding_path)) {
    old <- readRDS(binding_path)
    if (!all(old$published_catalogs %in% catalogs)) stop('Previously bound publication catalog disappeared.')
    catalogs <- old$published_catalogs
  }
  bound <- list(adapter_sha256 = adapter_sha, driver_sha256 = driver_sha, identity = identity,
                source_out = source_out, out = out, state_dir = state_dir, chunk_dir = chunk_dir,
                review_gate_sha256 = s07ops_sha(review_path))
  driver_binding <- file.path(state_dir, 'driver-binding-006.rds')
  if (file.exists(driver_binding)) { if (!identical(readRDS(driver_binding), bound)) stop('Changed operational driver binding.') }
  else s07ops_save(bound, driver_binding)
  collected_path <- file.path(state_dir, 'driver-collected.rds')
  if (file.exists(collected_path)) {
    saved <- readRDS(collected_path); verify_inventory(file.path(out, 'tables'), saved$tables)
    chunks <- read.csv(file.path(out, 'tables/csv-chunk-manifest.csv'), stringsAsFactors = FALSE)
    if (!identical(s07ops_md5(file.path(out, chunks$chunk)), chunks$md5)) stop('Completed raw serialization bytes changed.')
    tables <- readRDS(file.path(out, 'tables/analysis-inputs.rds'))
    write_status('VERIFIED_PREVIOUS_COMPLETED_COLLECTION')
  } else {
    write_status('RESUMING_DETERMINISTIC_COLLECTION', checkpoints = length(jobs), catalogs = length(catalogs))
    tables <- s07ops_collect(paths, jobs, identity, file.path(out, 'tables'), state_dir,
                            chunk_dir = chunk_dir, published_catalogs = catalogs)
    s07ops_save(list(tables = inventory(file.path(out, 'tables'))), collected_path)
    write_status('COLLECTION_AND_FROZEN_COMPRESSION_COMPLETE')
  }
  analyzed_path <- file.path(state_dir, 'driver-analyzed.rds')
  if (file.exists(analyzed_path)) verify_inventory(file.path(out, 'analysis'), readRDS(analyzed_path)$analysis)
  else {
    existing <- file.path(out, 'analysis')
    if (dir.exists(existing)) {
      kept <- tempfile('prior-analysis-', tmpdir = state_dir)
      if (!file.rename(existing, kept)) stop('Cannot preserve prior unfinished analysis.')
    }
    write_status('RUNNING_UNCHANGED_FROZEN_ANALYSIS')
    s07i_analyze(tables, existing, FALSE)
    s07ops_save(list(analysis = inventory(existing)), analyzed_path)
  }
  write_status('RUNNING_ALL_FROZEN_INDEPENDENT_AUDITS')
  s07i_inventory(out)
  s07r1_final_audit(out, FALSE)
  if (!identical(identity, s07r1_identity(FALSE)) || !identical(ancestor, s07i_verify_implementation()) ||
      !identical(guard, s07ops_guard()) || s07ops_sha(script) != driver_sha) stop('Source/runtime/orchestration changed during completion.')
  s07r1_status(out, jobs, identity, TRUE)
  # Historical R1 counts describe the already retained recovery. This driver adds zero.
  s07i_json(list(amendment = 'S07-R1', engineering = FALSE, panels = length(jobs),
    draws = sum(vapply(jobs, `[[`, integer(1), 'B_planned')), controls_recomputed_panels = length(jobs),
    migrated_panels = 6475L, full_estimator_refitted_panels = 5L, completed_at = study05_utc(),
    independent_audit_passed = TRUE, reserved_measurement_panels_generated = 5L,
    reserved_bootstrap_weight_vectors_generated = 0L,
    completion_orchestration = 'external_operational_serialization_resume',
    serialization_resume_measurements_generated = 0L, serialization_resume_draws_generated = 0L,
    serialization_resume_fits_generated = 0L, adapter_sha256 = adapter_sha, driver_sha256 = driver_sha),
    file.path(out, 'execution-complete.json'))
  s07ops_worker(c(file.path(out, 'execution-complete.json'), out))
  write_status('COMPLETE', independent_audit_passed = TRUE, panels = length(jobs))
}

tryCatch(main(), error = function(e) {
  try(write_status('BLOCKED_PRESERVE_EVIDENCE', error = conditionMessage(e)), silent = TRUE)
  stop(e)
}, finally = s07ops_worker(close = TRUE))
